# Pastimes Online Shop

A web application for buying and selling branded, high-quality second-hand clothing.

## Table of Contents
- [Project Overview](#project-overview)
- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running in Visual Studio](#running-in-visual-studio)
- [Default Accounts](#default-accounts)
- [Project Structure](#project-structure)
- [Database Schema](#database-schema)
- [Security Features](#security-features)

## Project Overview

Pastimes Online Shop is a complete e-commerce platform designed for the second-hand clothing market. The application provides a secure environment where users can register, become verified sellers, list items for sale, and buyers can browse, purchase, and communicate with sellers.

## Features

### User Features
- **Registration**: New users can create accounts with email validation
- **Login**: Secure authentication with sticky forms (retains input on failure)
- **Profile Management**: Users can update their information

### Buyer Features
- Browse clothing catalog with filters (category, brand, price, size, condition)
- View detailed item pages
- Add items to shopping cart
- Checkout with shipping address and payment method selection
- Send messages to sellers

### Seller Features
- Request seller verification
- Upload clothing items with detailed information
- Manage listed items (edit, delete)
- View orders and sales statistics
- Communicate with buyers

### Admin Features
- Dashboard with statistics overview
- User management (Add/Update/Delete)
- Seller verification approval/rejection
- Clothing item management
- Order management
- System administration

## Requirements

### Software Requirements
- **Web Server**: Apache/Nginx with PHP support
- **PHP**: Version 7.4 or higher
- **MySQL**: Version 5.7 or higher
- **Web Browser**: Chrome, Firefox, Safari, or Edge (modern versions)

### PHP Extensions Required
- mysqli
- session
- json

### Development Environments
- XAMPP (Windows/Mac/Linux)
- WAMP (Windows)
- MAMP (Mac)
- Visual Studio with PHP Tools extension
- Any LAMP/LEMP stack

## Installation

### Step 1: Extract Files
Extract the `PastimesShop.zip` file to your web server's document root:
- **XAMPP**: `C:\xampp\htdocs\PastimesShop\`
- **WAMP**: `C:\wamp\www\PastimesShop\`
- **MAMP**: `/Applications/MAMP/htdocs/PastimesShop/`
- **Linux**: `/var/www/html/PastimesShop/`

### Step 2: Create Database
1. Start your MySQL server
2. Open phpMyAdmin or MySQL command line
3. Import the SQL file:
   ```sql
   source /path/to/PastimesShop/myClothingStore.sql
   ```
   
   Or via phpMyAdmin:
   - Go to "Import" tab
   - Select `myClothingStore.sql`
   - Click "Go"

### Step 3: Configure Database Connection
Edit `includes/DBConn.php` and update the database credentials:

```php
$servername = "localhost";
$username = "root";        // Your MySQL username
$password = "";            // Your MySQL password
$dbname = "ClothingStore";
```

### Step 4: Set Base URL
If not using localhost root, update the base URL in your configuration.

### Step 5: Start the Application
1. Start Apache and MySQL services
2. Open your web browser
3. Navigate to: `http://localhost/PastimesShop/`

## Running in Visual Studio

### Option 1: With PHP Tools Extension
1. Install [PHP Tools for Visual Studio](https://www.devsense.com/en/php-tools)
2. Open Visual Studio
3. File → Open → Web Site → Select the `PastimesShop` folder
4. Configure PHP interpreter in Tools → Options → PHP
5. Right-click project → View in Browser

### Option 2: With IIS Express
1. Install IIS Express and PHP
2. Configure PHP handler in IIS
3. Open project folder in Visual Studio
4. Set up virtual directory pointing to project folder

### Option 3: Using Visual Studio Code
1. Install PHP Server extension
2. Open the `PastimesShop` folder
3. Right-click `index.php` → PHP Server: Serve project

## Default Accounts

### Admin Account
- **Username**: `admin`
- **Password**: `admin123`

### Test User Accounts
| Username | Password | User Type | Status |
|----------|----------|-----------|--------|
| johnsmith | hello | Buyer | Verified |
| emilyj | test | Seller | Verified |
| mikeb | mike123 | Seller | Verified |

**Note**: All passwords in the database are MD5 hashed. Default password for test users varies.

## Project Structure

```
PastimesShop/
├── index.php                 # Landing page
├── login.php                 # User login
├── register.php              # User registration
├── logout.php                # Logout handler
├── myClothingStore.sql       # Database setup script
├── documentation.md          # Database documentation
├── README.md                 # This file
│
├── includes/
│   └── DBConn.php           # Database connection & helpers
│
├── css/
│   └── style.css            # Main stylesheet
│
├── admin/
│   ├── login.php            # Admin login portal
│   ├── dashboard.php        # Admin dashboard
│   ├── users.php            # User management (CRUD)
│   ├── verify-users.php     # Verify new users
│   ├── sellers.php          # Seller management
│   ├── clothing.php         # Clothing management
│   └── orders.php           # Order management
│
├── buyer/
│   ├── catalog.php          # Browse clothing items
│   ├── item.php             # Single item view
│   ├── cart.php             # Shopping cart
│   └── messages.php         # Buyer messages
│
└── seller/
    ├── dashboard.php        # Seller dashboard
    ├── upload.php           # Upload new item
    ├── my-items.php         # Manage listed items
    ├── request-seller.php   # Request seller status
    ├── orders.php           # Seller orders
    └── messages.php         # Seller messages
```

## Database Schema

### Tables
1. **tblUser** - User accounts (buyers, sellers, admins)
2. **tblAdmin** - Administrator details
3. **tblSellerRequest** - Seller verification requests
4. **tblClothes** - Clothing items for sale
5. **tblAorder** - Orders placed by buyers
6. **tblCartItems** - Shopping cart items
7. **tblMessages** - Buyer-seller communications

### Relationships
- `tblAdmin.userID` → `tblUser.userID`
- `tblSellerRequest.userID` → `tblUser.userID`
- `tblClothes.sellerID` → `tblUser.userID`
- `tblAorder.buyerID` → `tblUser.userID`
- `tblAorder.clothingID` → `tblClothes.clothingID`
- `tblCartItems.userID` → `tblUser.userID`
- `tblCartItems.clothingID` → `tblClothes.clothingID`
- `tblMessages.senderID` → `tblUser.userID`
- `tblMessages.receiverID` → `tblUser.userID`
- `tblMessages.clothingID` → `tblClothes.clothingID`

## Security Features

### Password Security
- Passwords are hashed using MD5 algorithm
- Support for SHA256 hashing also implemented
- Minimum password length: 8 characters

### Input Validation
- HTML5 form validation
- Server-side input sanitization
- Prepared statements for SQL injection prevention
- XSS protection through output escaping

### Session Security
- Session-based authentication
- Role-based access control
- Secure logout functionality

### Form Features
- Sticky forms retain user input on validation failure
- Passwords are never retained in sticky forms
- Real-time validation feedback

## Troubleshooting

### Database Connection Error
1. Verify MySQL server is running
2. Check credentials in `DBConn.php`
3. Ensure database `ClothingStore` exists

### Page Not Found
1. Check the URL path
2. Ensure Apache mod_rewrite is enabled
3. Verify files are in correct location

### Login Not Working
1. Check if user exists in database
2. Verify user status is 'verified'
3. Clear browser cookies and try again

## Support

For issues or questions, please refer to the `documentation.md` file for detailed database structure and technical information.

---
**Version**: 1.0.0  
**Created for**: Pastimes Online Shop Project  
**License**: Educational Use