<?php
/**
 * index.php - Homepage
 * Pastimes Online Shop
 */

session_start();
require_once 'includes/DBConn.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['userID']);
$userName = isset($_SESSION['name']) ? $_SESSION['name'] : '';
$userType = isset($_SESSION['userType']) ? $_SESSION['userType'] : '';

// Get featured clothing items
$featuredItems = [];
$clothesResult = $connection->query("SELECT c.*, u.name as sellerName 
    FROM tblClothes c 
    JOIN tblUser u ON c.sellerID = u.userID 
    WHERE c.status = 'available' 
    ORDER BY c.uploadDate DESC 
    LIMIT 8");

if ($clothesResult) {
    while ($row = $clothesResult->fetch_assoc()) {
        $featuredItems[] = $row;
    }
}

// Get categories count
$categoriesCount = [
    'tops' => 0,
    'bottoms' => 0,
    'dresses' => 0,
    'outerwear' => 0,
    'accessories' => 0,
    'footwear' => 0
];

foreach (array_keys($categoriesCount) as $cat) {
    $result = $connection->query("SELECT COUNT(*) as cnt FROM tblClothes WHERE category = '$cat' AND status = 'available'");
    if ($result) {
        $row = $result->fetch_assoc();
        $categoriesCount[$cat] = $row['cnt'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pastimes Online Shop - Quality Second-Hand Clothing</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <h1>Past<span>i</span>mes Shop</h1>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php" class="active">Home</a></li>
                    <li><a href="buyer/catalog.php">Shop</a></li>
                    <li><a href="buyer/catalog.php?category=tops">Categories</a></li>
                    <li><a href="#about">About</a></li>
                </ul>
            </nav>
            <div class="user-nav">
                <?php if ($isLoggedIn): ?>
                    <?php if ($userType === 'admin'): ?>
                        <a href="admin/dashboard.php" class="btn btn-primary btn-sm">Admin Panel</a>
                    <?php elseif ($userType === 'seller'): ?>
                        <a href="seller/dashboard.php" class="btn btn-primary btn-sm">Seller Dashboard</a>
                    <?php endif; ?>
                    <a href="buyer/cart.php" class="btn btn-outline btn-sm">Cart</a>
                    <a href="logout.php" class="btn btn-secondary btn-sm">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-primary btn-sm">Login</a>
                    <a href="register.php" class="btn btn-outline btn-sm">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <h2>Quality Second-Hand Clothing</h2>
            <p>Buy and sell branded, high-quality pre-loved clothing at affordable prices</p>
            <div class="hero-buttons">
                <a href="buyer/catalog.php" class="btn btn-lg" style="background: white; color: var(--primary-color);">Shop Now</a>
                <a href="register.php" class="btn btn-lg btn-outline" style="border-color: white;">Start Selling</a>
            </div>
        </div>
    </section>

    <main>
        <div class="container">
            <?php if ($isLoggedIn): ?>
                <div class="alert alert-success">
                    User <?php echo htmlspecialchars($userName); ?> is logged in
                </div>
            <?php endif; ?>

            <!-- Categories Section -->
            <section class="categories-section mt-4">
                <h2>Shop by Category</h2>
                <div class="grid grid-3">
                    <a href="buyer/catalog.php?category=tops" class="card">
                        <div class="card-body text-center">
                            <h3>Tops</h3>
                            <p><?php echo $categoriesCount['tops']; ?> items</p>
                        </div>
                    </a>
                    <a href="buyer/catalog.php?category=bottoms" class="card">
                        <div class="card-body text-center">
                            <h3>Bottoms</h3>
                            <p><?php echo $categoriesCount['bottoms']; ?> items</p>
                        </div>
                    </a>
                    <a href="buyer/catalog.php?category=dresses" class="card">
                        <div class="card-body text-center">
                            <h3>Dresses</h3>
                            <p><?php echo $categoriesCount['dresses']; ?> items</p>
                        </div>
                    </a>
                    <a href="buyer/catalog.php?category=outerwear" class="card">
                        <div class="card-body text-center">
                            <h3>Outerwear</h3>
                            <p><?php echo $categoriesCount['outerwear']; ?> items</p>
                        </div>
                    </a>
                    <a href="buyer/catalog.php?category=accessories" class="card">
                        <div class="card-body text-center">
                            <h3>Accessories</h3>
                            <p><?php echo $categoriesCount['accessories']; ?> items</p>
                        </div>
                    </a>
                    <a href="buyer/catalog.php?category=footwear" class="card">
                        <div class="card-body text-center">
                            <h3>Footwear</h3>
                            <p><?php echo $categoriesCount['footwear']; ?> items</p>
                        </div>
                    </a>
                </div>
            </section>

            <!-- Featured Items Section -->
            <section class="featured-section mt-4">
                <h2>Featured Items</h2>
                <?php if (count($featuredItems) > 0): ?>
                    <div class="grid grid-4">
                        <?php foreach ($featuredItems as $item): ?>
                            <div class="card">
                                <img src="<?php echo htmlspecialchars($item['imageURL'] ?: 'images/placeholder.jpg'); ?>" 
                                     alt="<?php echo htmlspecialchars($item['title']); ?>" 
                                     class="card-image">
                                <div class="card-body">
                                    <h4 class="card-title"><?php echo htmlspecialchars($item['title']); ?></h4>
                                    <p class="card-text"><?php echo htmlspecialchars($item['brand'] ?: 'Various'); ?></p>
                                    <p class="card-text">Size: <?php echo htmlspecialchars($item['size']); ?></p>
                                    <span class="status-badge status-<?php echo $item['condition_status']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $item['condition_status'])); ?>
                                    </span>
                                </div>
                                <div class="card-footer">
                                    <span class="price">$<?php echo number_format($item['price'], 2); ?></span>
                                    <a href="buyer/item.php?id=<?php echo $item['clothesID']; ?>" class="btn btn-primary btn-sm">View</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        No items available yet. Be the first to <a href="register.php">register as a seller</a>!
                    </div>
                <?php endif; ?>
            </section>

            <!-- About Section -->
            <section id="about" class="about-section mt-4">
                <h2>About Pastimes Shop</h2>
                <div class="card">
                    <div class="card-body">
                        <p>Pastimes Online Shop is your destination for quality second-hand clothing. We connect buyers and sellers of branded, pre-loved fashion items, making sustainable fashion accessible to everyone.</p>
                        <p>Whether you're looking to refresh your wardrobe with affordable designer pieces or want to give your gently-used clothes a new home, Pastimes Shop makes it easy and secure.</p>
                        <div class="grid grid-3 mt-3">
                            <div class="text-center">
                                <h3>Quality Items</h3>
                                <p>All items are verified for quality</p>
                            </div>
                            <div class="text-center">
                                <h3>Secure Trading</h3>
                                <p>Safe and protected transactions</p>
                            </div>
                            <div class="text-center">
                                <h3>Great Prices</h3>
                                <p>Affordable branded clothing</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>Pastimes Shop</h4>
                    <p>Your trusted marketplace for quality second-hand clothing.</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="buyer/catalog.php">Shop</a></li>
                        <li><a href="register.php">Register</a></li>
                        <li><a href="login.php">Login</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>