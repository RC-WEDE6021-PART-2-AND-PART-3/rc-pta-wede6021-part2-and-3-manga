<?php
/**
 * register.php - User Registration Page
 * Pastimes Online Shop
 * 
 * Features:
 * - Registration with name, email, username, and 8-character confirmed password
 * - HTML5 form validation
 * - Password hashing
 * - Status set to 'pending' until admin verification
 */

session_start();
require_once 'includes/DBConn.php';

$errors = [];
$success = '';
$stickyData = [
    'name' => '',
    'email' => '',
    'username' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize input
    $stickyData['name'] = trim($_POST['name'] ?? '');
    $stickyData['email'] = trim($_POST['email'] ?? '');
    $stickyData['username'] = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    
    // Validation
    if (empty($stickyData['name'])) {
        $errors[] = "Name is required";
    } elseif (strlen($stickyData['name']) < 2) {
        $errors[] = "Name must be at least 2 characters";
    }
    
    if (empty($stickyData['email'])) {
        $errors[] = "Email is required";
    } elseif (!filter_var($stickyData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    } else {
        // Check if email already exists
        $emailCheck = $connection->query("SELECT userID FROM tblUser WHERE email = '" . sanitizeInput($stickyData['email']) . "'");
        if ($emailCheck->num_rows > 0) {
            $errors[] = "Email already registered";
        }
    }
    
    if (empty($stickyData['username'])) {
        $errors[] = "Username is required";
    } elseif (strlen($stickyData['username']) < 3) {
        $errors[] = "Username must be at least 3 characters";
    } else {
        // Check if username already exists
        $usernameCheck = $connection->query("SELECT userID FROM tblUser WHERE username = '" . sanitizeInput($stickyData['username']) . "'");
        if ($usernameCheck->num_rows > 0) {
            $errors[] = "Username already taken";
        }
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    } elseif (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }
    
    if (empty($confirmPassword)) {
        $errors[] = "Please confirm your password";
    } elseif ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match";
    }
    
    // If no errors, proceed with registration
    if (empty($errors)) {
        $hashedPassword = hashPassword($password); // MD5 hash
        $name = sanitizeInput($stickyData['name']);
        $email = sanitizeInput($stickyData['email']);
        $username = sanitizeInput($stickyData['username']);
        
        $sql = "INSERT INTO tblUser (name, email, username, password, status, userType) 
                VALUES ('$name', '$email', '$username', '$hashedPassword', 'pending', 'buyer')";
        
        if ($connection->query($sql)) {
            $success = "Registration successful! Your account is pending verification by an administrator. You will receive an email once verified.";
            // Clear sticky data on success
            $stickyData = ['name' => '', 'email' => '', 'username' => ''];
        } else {
            $errors[] = "Registration failed. Please try again. Error: " . $connection->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Pastimes Online Shop</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <div class="user-nav">
                <a href="login.php" class="btn btn-primary btn-sm">Login</a>
            </div>
        </div>
    </header>

    <main>
        <div class="form-container">
            <h2>Create an Account</h2>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul style="margin: 0; padding-left: 20px;">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" novalidate>
                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" 
                           id="name" 
                           name="name" 
                           value="<?php echo htmlspecialchars($stickyData['name']); ?>" 
                           placeholder="Enter your full name"
                           required
                           minlength="2"
                           class="<?php echo !empty($stickyData['name']) ? 'sticky' : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address *</label>
                    <input type="email" 
                           id="email" 
                           name="email" 
                           value="<?php echo htmlspecialchars($stickyData['email']); ?>" 
                           placeholder="Enter your email"
                           required
                           class="<?php echo !empty($stickyData['email']) ? 'sticky' : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="username">Username *</label>
                    <input type="text" 
                           id="username" 
                           name="username" 
                           value="<?php echo htmlspecialchars($stickyData['username']); ?>" 
                           placeholder="Choose a username"
                           required
                           minlength="3"
                           class="<?php echo !empty($stickyData['username']) ? 'sticky' : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password *</label>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           placeholder="Enter password (min 8 characters)"
                           required
                           minlength="8">
                    <span class="helper-text">Password must be at least 8 characters long</span>
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword">Confirm Password *</label>
                    <input type="password" 
                           id="confirmPassword" 
                           name="confirmPassword" 
                           placeholder="Confirm your password"
                           required
                           minlength="8">
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Register</button>
            </form>
            
            <p class="mt-3 text-center">
                Already have an account? <a href="login.php">Login here</a>
            </p>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>