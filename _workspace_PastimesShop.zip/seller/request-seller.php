<?php
/**
 * seller/request-seller.php - Seller Verification Request Page
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header('Location: ../login.php');
    exit();
}

$userID = $_SESSION['userID'];
$userName = $_SESSION['name'];
$userType = $_SESSION['userType'];

// If already a seller, redirect to dashboard
if ($userType === 'seller') {
    header('Location: dashboard.php');
    exit();
}

// Check existing request
$existingRequest = null;
$result = $connection->query("SELECT * FROM tblSellerRequest WHERE userID = $userID ORDER BY requestID DESC LIMIT 1");
if ($result->num_rows > 0) {
    $existingRequest = $result->fetch_assoc();
}

$success = '';
$error = '';

// Handle new request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submitRequest'])) {
    $description = sanitizeInput($_POST['description']);
    
    if (empty($description)) {
        $error = "Please provide a description";
    } else {
        $sql = "INSERT INTO tblSellerRequest (userID, description) VALUES ($userID, '$description')";
        if ($connection->query($sql)) {
            $success = "Your seller request has been submitted. Please wait for admin approval.";
            $existingRequest = ['status' => 'pending', 'description' => $description];
        } else {
            $error = "Failed to submit request";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Become a Seller - Pastimes Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="../index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <div class="user-nav">
                <a href="../logout.php" class="btn btn-secondary btn-sm">Logout</a>
            </div>
        </div>
    </header>

    <main>
        <div class="form-container">
            <h2>Become a Seller</h2>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($existingRequest): ?>
                <div class="card">
                    <div class="card-body">
                        <h3>Your Request Status</h3>
                        <p>
                            <span class="status-badge status-<?php echo $existingRequest['status']; ?>">
                                <?php echo ucfirst($existingRequest['status']); ?>
                            </span>
                        </p>
                        
                        <?php if ($existingRequest['status'] === 'pending'): ?>
                            <p>Your request is being reviewed by our administrators. You will be notified once approved.</p>
                        <?php elseif ($existingRequest['status'] === 'approved'): ?>
                            <div class="alert alert-success">
                                Your seller account has been approved! 
                                <a href="dashboard.php">Go to your Seller Dashboard</a>
                            </div>
                        <?php else: ?>
                            <p>Unfortunately, your request was not approved. You may submit a new request if you believe this was an error.</p>
                            <form method="POST">
                                <button type="submit" name="submitRequest" class="btn btn-primary">Submit New Request</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <p>As a seller on Pastimes Shop, you can:</p>
                <ul style="margin: 1rem 0; padding-left: 20px;">
                    <li>List your quality second-hand clothing for sale</li>
                    <li>Set your own prices</li>
                    <li>Communicate directly with buyers</li>
                    <li>Track your sales and orders</li>
                </ul>
                
                <form method="POST">
                    <div class="form-group">
                        <label>Why do you want to become a seller? *</label>
                        <textarea name="description" rows="5" placeholder="Tell us about yourself and what you plan to sell..." required></textarea>
                    </div>
                    
                    <button type="submit" name="submitRequest" class="btn btn-primary btn-block">
                        Submit Seller Request
                    </button>
                </form>
            <?php endif; ?>
            
            <p class="mt-3 text-center">
                <a href="../index.php">Return to Homepage</a>
            </p>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>