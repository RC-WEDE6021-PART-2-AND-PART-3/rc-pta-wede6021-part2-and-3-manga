<?php
/**
 * seller/dashboard.php - Seller Dashboard
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

// Check if user is logged in as seller
if (!isset($_SESSION['userID'])) {
    header('Location: ../login.php');
    exit();
}

$userID = $_SESSION['userID'];
$userName = $_SESSION['name'];
$userType = $_SESSION['userType'];

// If not a seller, check for seller request or allow to request
if ($userType !== 'seller') {
    // Check if already requested
    $requestResult = $connection->query("SELECT * FROM tblSellerRequest WHERE userID = $userID");
    if ($requestResult->num_rows === 0) {
        header('Location: request-seller.php');
    } else {
        $request = $requestResult->fetch_assoc();
        if ($request['status'] === 'pending') {
            header('Location: request-seller.php?status=pending');
        } else {
            header('Location: request-seller.php?status=' . $request['status']);
        }
    }
    exit();
}

$success = '';
$error = '';

// Get seller statistics
$stats = [
    'totalItems' => 0,
    'availableItems' => 0,
    'soldItems' => 0,
    'totalSales' => 0,
    'pendingOrders' => 0,
    'totalRevenue' => 0
];

$result = $connection->query("SELECT COUNT(*) as cnt FROM tblClothes WHERE sellerID = $userID");
$stats['totalItems'] = $result->fetch_assoc()['cnt'];

$result = $connection->query("SELECT COUNT(*) as cnt FROM tblClothes WHERE sellerID = $userID AND status = 'available'");
$stats['availableItems'] = $result->fetch_assoc()['cnt'];

$result = $connection->query("SELECT COUNT(*) as cnt FROM tblClothes WHERE sellerID = $userID AND status = 'sold'");
$stats['soldItems'] = $result->fetch_assoc()['cnt'];

$result = $connection->query("SELECT SUM(totalAmount) as total FROM tblAorder WHERE sellerID = $userID AND status = 'delivered'");
$stats['totalRevenue'] = $result->fetch_assoc()['total'] ?? 0;

// Get recent items
$recentItems = [];
$result = $connection->query("SELECT * FROM tblClothes WHERE sellerID = $userID ORDER BY uploadDate DESC LIMIT 5");
while ($row = $result->fetch_assoc()) {
    $recentItems[] = $row;
}

// Get orders for seller's items
$orders = [];
$result = $connection->query("SELECT o.*, u.name as buyerName, c.title as itemTitle 
    FROM tblAorder o 
    JOIN tblUser u ON o.buyerID = u.userID 
    JOIN tblClothes c ON o.clothesID = c.clothesID 
    WHERE o.sellerID = $userID 
    ORDER BY o.orderDate DESC LIMIT 10");
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

// Handle item status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updateStatus'])) {
    $clothesID = intval($_POST['clothesID']);
    $status = sanitizeInput($_POST['status']);
    
    // Verify ownership
    $check = $connection->query("SELECT * FROM tblClothes WHERE clothesID = $clothesID AND sellerID = $userID");
    if ($check->num_rows === 1) {
        $connection->query("UPDATE tblClothes SET status = '$status' WHERE clothesID = $clothesID");
        $success = "Item status updated";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Dashboard - Pastimes Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Seller Panel</h3>
            <ul>
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="upload.php">Upload Item</a></li>
                <li><a href="my-items.php">My Items</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="messages.php">Messages</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <div class="dashboard-header">
                <h1>Welcome, <?php echo htmlspecialchars($userName); ?></h1>
                <span class="status-badge status-verified">Verified Seller</span>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['totalItems']; ?></div>
                    <div class="stat-label">Total Items</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['availableItems']; ?></div>
                    <div class="stat-label">Available</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['soldItems']; ?></div>
                    <div class="stat-label">Sold</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" style="color: var(--success-color);">$<?php echo number_format($stats['totalRevenue'], 2); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
            </div>
            
            <!-- Recent Items -->
            <section class="mt-4">
                <div class="dashboard-header">
                    <h2>My Recent Items</h2>
                    <a href="upload.php" class="btn btn-primary btn-sm">Add New Item</a>
                </div>
                
                <?php if (count($recentItems) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Title</th>
                                    <th>Brand</th>
                                    <th>Price</th>
                                    <th>Status</th>
                                    <th>Uploaded</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentItems as $item): ?>
                                    <tr>
                                        <td>
                                            <img src="<?php echo htmlspecialchars($item['imageURL'] ?: '../images/placeholder.jpg'); ?>" 
                                                 style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                                        </td>
                                        <td><?php echo htmlspecialchars($item['title']); ?></td>
                                        <td><?php echo htmlspecialchars($item['brand'] ?? '-'); ?></td>
                                        <td>$<?php echo number_format($item['price'], 2); ?></td>
                                        <td><span class="status-badge status-<?php echo $item['status']; ?>"><?php echo ucfirst($item['status']); ?></span></td>
                                        <td><?php echo date('M j, Y', strtotime($item['uploadDate'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <a href="my-items.php" class="btn btn-secondary btn-sm mt-2">View All Items</a>
                <?php else: ?>
                    <div class="alert alert-info">
                        You haven't listed any items yet. <a href="upload.php">Upload your first item</a>!
                    </div>
                <?php endif; ?>
            </section>
            
            <!-- Recent Orders -->
            <section class="mt-4">
                <h2>Orders for My Items</h2>
                
                <?php if (count($orders) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Buyer</th>
                                    <th>Item</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>#<?php echo $order['orderID']; ?></td>
                                        <td><?php echo htmlspecialchars($order['buyerName']); ?></td>
                                        <td><?php echo htmlspecialchars($order['itemTitle']); ?></td>
                                        <td>$<?php echo number_format($order['totalAmount'], 2); ?></td>
                                        <td><span class="status-badge status-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                                        <td><?php echo date('M j, Y', strtotime($order['orderDate'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">No orders yet</div>
                <?php endif; ?>
            </section>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>