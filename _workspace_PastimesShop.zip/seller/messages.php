<?php
/**
 * seller/messages.php - Seller Messaging System
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'seller') {
    header('Location: request-seller.php');
    exit();
}

$userID = $_SESSION['userID'];
$success = '';

// Handle send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sendMessage'])) {
    $receiverID = intval($_POST['receiverID']);
    $message = sanitizeInput($_POST['message']);
    
    if (!empty($message) && $receiverID > 0) {
        $sql = "INSERT INTO tblMessages (senderID, receiverID, message) VALUES ($userID, $receiverID, '$message')";
        if ($connection->query($sql)) {
            $success = "Message sent!";
        }
    }
}

// Get conversations
$conversations = [];
$result = $connection->query("SELECT DISTINCT 
    CASE WHEN senderID = $userID THEN receiverID ELSE senderID END as otherUserID,
    u.name, u.email,
    (SELECT message FROM tblMessages m2 WHERE 
        (m2.senderID = $userID AND m2.receiverID = u.userID) OR 
        (m2.senderID = u.userID AND m2.receiverID = $userID) 
     ORDER BY m2.sentDate DESC LIMIT 1) as lastMessage,
    (SELECT sentDate FROM tblMessages m2 WHERE 
        (m2.senderID = $userID AND m2.receiverID = u.userID) OR 
        (m2.senderID = u.userID AND m2.receiverID = $userID) 
     ORDER BY m2.sentDate DESC LIMIT 1) as lastDate
    FROM tblMessages m
    JOIN tblUser u ON (m.senderID = u.userID OR m.receiverID = u.userID)
    WHERE (m.senderID = $userID OR m.receiverID = $userID) AND u.userID != $userID
    ORDER BY lastDate DESC");
while ($row = $result->fetch_assoc()) {
    $conversations[] = $row;
}

$selectedUser = intval($_GET['user'] ?? 0);
$messages = [];
$chatPartner = null;

if ($selectedUser > 0) {
    $result = $connection->query("SELECT * FROM tblUser WHERE userID = $selectedUser");
    if ($result->num_rows === 1) {
        $chatPartner = $result->fetch_assoc();
    }
    
    $result = $connection->query("SELECT * FROM tblMessages 
        WHERE (senderID = $userID AND receiverID = $selectedUser) 
           OR (senderID = $selectedUser AND receiverID = $userID) 
        ORDER BY sentDate ASC");
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    
    $connection->query("UPDATE tblMessages SET isRead = 1 WHERE senderID = $selectedUser AND receiverID = $userID");
}

$unreadCount = $connection->query("SELECT COUNT(*) as cnt FROM tblMessages WHERE receiverID = $userID AND isRead = 0")->fetch_assoc()['cnt'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - Seller Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Seller Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="upload.php">Upload Item</a></li>
                <li><a href="my-items.php">My Items</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="messages.php" class="active">Messages</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <h1>Messages</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="messages-container">
                <div class="conversations-list">
                    <h3 style="padding: 1rem; border-bottom: 1px solid #ddd;">Conversations</h3>
                    
                    <?php if (count($conversations) > 0): ?>
                        <?php foreach ($conversations as $conv): ?>
                            <a href="?user=<?php echo $conv['otherUserID']; ?>" 
                               class="conversation-item <?php echo $selectedUser == $conv['otherUserID'] ? 'active' : ''; ?>">
                                <strong><?php echo htmlspecialchars($conv['name']); ?></strong>
                                <p style="font-size: 0.85rem; color: var(--text-light); margin: 0.25rem 0;">
                                    <?php echo htmlspecialchars(substr($conv['lastMessage'], 0, 50)); ?>...
                                </p>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="padding: 1rem; color: var(--text-light);">No conversations yet</p>
                    <?php endif; ?>
                </div>
                
                <div class="chat-area">
                    <?php if ($chatPartner): ?>
                        <div class="chat-header">
                            <h3><?php echo htmlspecialchars($chatPartner['name']); ?></h3>
                        </div>
                        
                        <div class="chat-messages">
                            <?php foreach ($messages as $msg): ?>
                                <div class="message <?php echo $msg['senderID'] == $userID ? 'sent' : 'received'; ?>">
                                    <div class="message-content">
                                        <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                    </div>
                                    <div class="message-time">
                                        <?php echo date('M j, Y H:i', strtotime($msg['sentDate'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <form method="POST" class="chat-input">
                            <input type="hidden" name="receiverID" value="<?php echo $chatPartner['userID']; ?>">
                            <input type="text" name="message" placeholder="Type your message..." required>
                            <button type="submit" name="sendMessage" class="btn btn-primary">Send</button>
                        </form>
                    <?php else: ?>
                        <div class="flex-center" style="height: 100%;">
                            <div class="text-center">
                                <h3>Select a conversation</h3>
                                <p style="color: var(--text-light);">Choose a conversation to start messaging</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>