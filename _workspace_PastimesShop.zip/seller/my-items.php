<?php
/**
 * seller/my-items.php - Seller's Items Management
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'seller') {
    header('Location: request-seller.php');
    exit();
}

$userID = $_SESSION['userID'];
$success = '';
$error = '';

// Handle delete
if (isset($_GET['delete'])) {
    $itemID = intval($_GET['delete']);
    $check = $connection->query("SELECT * FROM tblClothes WHERE clothesID = $itemID AND sellerID = $userID");
    if ($check->num_rows === 1) {
        $item = $check->fetch_assoc();
        if ($item['status'] !== 'sold') {
            if ($connection->query("DELETE FROM tblClothes WHERE clothesID = $itemID")) {
                $success = "Item deleted successfully";
            }
        } else {
            $error = "Cannot delete sold items";
        }
    }
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updateItem'])) {
    $itemID = intval($_POST['clothesID']);
    $title = sanitizeInput($_POST['title']);
    $description = sanitizeInput($_POST['description'] ?? '');
    $brand = sanitizeInput($_POST['brand'] ?? '');
    $price = floatval($_POST['price']);
    $status = sanitizeInput($_POST['status']);
    
    $sql = "UPDATE tblClothes SET title='$title', description='$description', brand='$brand', price=$price, status='$status' WHERE clothesID = $itemID AND sellerID = $userID";
    if ($connection->query($sql)) {
        $success = "Item updated successfully";
    }
}

// Get seller's items
$items = [];
$filter = sanitizeInput($_GET['filter'] ?? 'all');
$whereClause = "sellerID = $userID";
if ($filter !== 'all') {
    $whereClause .= " AND status = '$filter'";
}

$result = $connection->query("SELECT * FROM tblClothes WHERE $whereClause ORDER BY uploadDate DESC");
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

// Edit item
$editItem = null;
if (isset($_GET['edit'])) {
    $itemID = intval($_GET['edit']);
    $result = $connection->query("SELECT * FROM tblClothes WHERE clothesID = $itemID AND sellerID = $userID");
    if ($result->num_rows === 1) {
        $editItem = $result->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Items - Seller Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Seller Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="upload.php">Upload Item</a></li>
                <li><a href="my-items.php" class="active">My Items</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="messages.php">Messages</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <div class="dashboard-header">
                <h1>My Items</h1>
                <a href="upload.php" class="btn btn-primary">Add New Item</a>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <!-- Filter -->
            <div class="mb-3">
                <a href="?filter=all" class="btn <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">All</a>
                <a href="?filter=available" class="btn <?php echo $filter === 'available' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Available</a>
                <a href="?filter=sold" class="btn <?php echo $filter === 'sold' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Sold</a>
                <a href="?filter=reserved" class="btn <?php echo $filter === 'reserved' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Reserved</a>
            </div>
            
            <?php if ($editItem): ?>
                <!-- Edit Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h3>Edit Item</h3>
                        <form method="POST">
                            <input type="hidden" name="clothesID" value="<?php echo $editItem['clothesID']; ?>">
                            
                            <div class="grid grid-2">
                                <div class="form-group">
                                    <label>Title</label>
                                    <input type="text" name="title" value="<?php echo htmlspecialchars($editItem['title']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Brand</label>
                                    <input type="text" name="brand" value="<?php echo htmlspecialchars($editItem['brand'] ?? ''); ?>">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" rows="3"><?php echo htmlspecialchars($editItem['description'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="grid grid-2">
                                <div class="form-group">
                                    <label>Price ($)</label>
                                    <input type="number" name="price" value="<?php echo $editItem['price']; ?>" min="0" step="0.01" required>
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status">
                                        <option value="available" <?php echo $editItem['status'] === 'available' ? 'selected' : ''; ?>>Available</option>
                                        <option value="reserved" <?php echo $editItem['status'] === 'reserved' ? 'selected' : ''; ?>>Reserved</option>
                                    </select>
                                </div>
                            </div>
                            
                            <button type="submit" name="updateItem" class="btn btn-primary">Update Item</button>
                            <a href="my-items.php" class="btn btn-secondary">Cancel</a>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Items Grid -->
            <?php if (count($items) > 0): ?>
                <div class="grid grid-3">
                    <?php foreach ($items as $item): ?>
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($item['imageURL'] ?: '../images/placeholder.jpg'); ?>" 
                                 alt="<?php echo htmlspecialchars($item['title']); ?>" 
                                 class="card-image">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo htmlspecialchars($item['title']); ?></h4>
                                <p class="card-text"><?php echo htmlspecialchars($item['brand'] ?? 'Various'); ?></p>
                                <p class="card-text">Size: <?php echo htmlspecialchars($item['size']); ?></p>
                                <span class="status-badge status-<?php echo $item['status']; ?>">
                                    <?php echo ucfirst($item['status']); ?>
                                </span>
                            </div>
                            <div class="card-footer">
                                <span class="price">$<?php echo number_format($item['price'], 2); ?></span>
                                <div style="display: flex; gap: 0.5rem;">
                                    <a href="?edit=<?php echo $item['clothesID']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <?php if ($item['status'] !== 'sold'): ?>
                                        <a href="?delete=<?php echo $item['clothesID']; ?>" 
                                           class="btn btn-danger btn-sm" 
                                           onclick="return confirm('Delete this item?')">Delete</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    No items found. <a href="upload.php">Upload your first item</a>!
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>