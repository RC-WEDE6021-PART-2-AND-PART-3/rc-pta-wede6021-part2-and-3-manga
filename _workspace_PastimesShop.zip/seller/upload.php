<?php
/**
 * seller/upload.php - Upload Clothing Item
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'seller') {
    header('Location: request-seller.php');
    exit();
}

$userID = $_SESSION['userID'];
$userName = $_SESSION['name'];
$success = '';
$error = '';

// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title']);
    $description = sanitizeInput($_POST['description'] ?? '');
    $brand = sanitizeInput($_POST['brand'] ?? '');
    $category = sanitizeInput($_POST['category']);
    $size = sanitizeInput($_POST['size'] ?? '');
    $color = sanitizeInput($_POST['color'] ?? '');
    $condition = sanitizeInput($_POST['condition']);
    $price = floatval($_POST['price']);
    $imageURL = sanitizeInput($_POST['imageURL'] ?? '');
    
    // Validation
    if (empty($title) || empty($category) || empty($condition) || $price <= 0) {
        $error = "Please fill in all required fields";
    } else {
        $sql = "INSERT INTO tblClothes (sellerID, title, description, brand, category, size, color, condition_status, price, imageURL) 
                VALUES ($userID, '$title', '$description', '$brand', '$category', '$size', '$color', '$condition', $price, '$imageURL')";
        
        if ($connection->query($sql)) {
            $success = "Item uploaded successfully! It is now available for sale.";
            // Clear form
            $_POST = [];
        } else {
            $error = "Failed to upload item: " . $connection->error;
        }
    }
}

// Get categories
$categories = ['tops', 'bottoms', 'dresses', 'outerwear', 'accessories', 'footwear', 'other'];
$conditions = ['new', 'like_new', 'good', 'fair'];
$sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One Size'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Item - Seller Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Seller Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="upload.php" class="active">Upload Item</a></li>
                <li><a href="my-items.php">My Items</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="messages.php">Messages</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <h1>Upload New Item</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="grid grid-2">
                            <div class="form-group">
                                <label>Title *</label>
                                <input type="text" name="title" value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>" required placeholder="e.g., Vintage Levi's Denim Jacket">
                            </div>
                            
                            <div class="form-group">
                                <label>Brand</label>
                                <input type="text" name="brand" value="<?php echo htmlspecialchars($_POST['brand'] ?? ''); ?>" placeholder="e.g., Levi's, Nike, Zara">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" rows="4" placeholder="Describe the item's condition, style, and any notable features..."><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="grid grid-3">
                            <div class="form-group">
                                <label>Category *</label>
                                <select name="category" required>
                                    <option value="">Select Category</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?php echo $cat; ?>" <?php echo ($_POST['category'] ?? '') === $cat ? 'selected' : ''; ?>>
                                            <?php echo ucfirst($cat); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Size</label>
                                <select name="size">
                                    <option value="">Select Size</option>
                                    <?php foreach ($sizes as $s): ?>
                                        <option value="<?php echo $s; ?>" <?php echo ($_POST['size'] ?? '') === $s ? 'selected' : ''; ?>>
                                            <?php echo $s; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Condition *</label>
                                <select name="condition" required>
                                    <option value="">Select Condition</option>
                                    <?php foreach ($conditions as $cond): ?>
                                        <option value="<?php echo $cond; ?>" <?php echo ($_POST['condition'] ?? '') === $cond ? 'selected' : ''; ?>>
                                            <?php echo ucfirst(str_replace('_', ' ', $cond)); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="grid grid-2">
                            <div class="form-group">
                                <label>Color</label>
                                <input type="text" name="color" value="<?php echo htmlspecialchars($_POST['color'] ?? ''); ?>" placeholder="e.g., Blue, Black, Red">
                            </div>
                            
                            <div class="form-group">
                                <label>Price ($) *</label>
                                <input type="number" name="price" value="<?php echo $_POST['price'] ?? ''; ?>" min="0" step="0.01" required placeholder="0.00">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Image URL</label>
                            <input type="url" name="imageURL" value="<?php echo htmlspecialchars($_POST['imageURL'] ?? ''); ?>" placeholder="https://example.com/image.jpg">
                            <span class="helper-text">Provide a URL to an image of your item (use Imgur, Google Photos, etc.)</span>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg">Upload Item</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>