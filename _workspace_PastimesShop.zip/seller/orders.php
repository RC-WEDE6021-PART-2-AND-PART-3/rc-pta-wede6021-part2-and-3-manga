<?php
/**
 * seller/orders.php - Seller's Orders Management
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'seller') {
    header('Location: request-seller.php');
    exit();
}

$userID = $_SESSION['userID'];
$success = '';

// Handle order actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderID = intval($_POST['orderID'] ?? 0);
    $action = $_POST['action'] ?? '';
    
    if ($orderID > 0) {
        // Verify order belongs to seller
        $check = $connection->query("SELECT * FROM tblAorder WHERE orderID = $orderID AND sellerID = $userID");
        if ($check->num_rows === 1) {
            switch ($action) {
                case 'confirm':
                    $connection->query("UPDATE tblAorder SET status = 'confirmed' WHERE orderID = $orderID");
                    $success = "Order confirmed";
                    break;
                case 'ship':
                    $tracking = sanitizeInput($_POST['trackingNumber'] ?? '');
                    $connection->query("UPDATE tblAorder SET status = 'shipped', trackingNumber = '$tracking' WHERE orderID = $orderID");
                    $success = "Order marked as shipped";
                    break;
            }
        }
    }
}

// Get orders
$orders = [];
$filter = sanitizeInput($_GET['filter'] ?? 'all');
$whereClause = "o.sellerID = $userID";
if ($filter !== 'all') {
    $whereClause .= " AND o.status = '$filter'";
}

$result = $connection->query("SELECT o.*, u.name as buyerName, u.email as buyerEmail, c.title as itemTitle 
    FROM tblAorder o 
    JOIN tblUser u ON o.buyerID = u.userID 
    JOIN tblClothes c ON o.clothesID = c.clothesID 
    WHERE $whereClause 
    ORDER BY o.orderDate DESC");
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Seller Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Seller Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="upload.php">Upload Item</a></li>
                <li><a href="my-items.php">My Items</a></li>
                <li><a href="orders.php" class="active">Orders</a></li>
                <li><a href="messages.php">Messages</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <h1>Orders</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Filter -->
            <div class="mb-3">
                <a href="?filter=all" class="btn <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">All</a>
                <a href="?filter=pending" class="btn <?php echo $filter === 'pending' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Pending</a>
                <a href="?filter=confirmed" class="btn <?php echo $filter === 'confirmed' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Confirmed</a>
                <a href="?filter=shipped" class="btn <?php echo $filter === 'shipped' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Shipped</a>
                <a href="?filter=delivered" class="btn <?php echo $filter === 'delivered' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Delivered</a>
            </div>
            
            <?php if (count($orders) > 0): ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Buyer</th>
                                <th>Item</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td>#<?php echo $order['orderID']; ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($order['buyerName']); ?><br>
                                        <small><?php echo htmlspecialchars($order['buyerEmail']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($order['itemTitle']); ?></td>
                                    <td>$<?php echo number_format($order['totalAmount'], 2); ?></td>
                                    <td><span class="status-badge status-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                                    <td><?php echo date('M j, Y', strtotime($order['orderDate'])); ?></td>
                                    <td>
                                        <?php if ($order['status'] === 'pending'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="orderID" value="<?php echo $order['orderID']; ?>">
                                                <input type="hidden" name="action" value="confirm">
                                                <button type="submit" class="btn btn-success btn-sm">Confirm</button>
                                            </form>
                                        <?php elseif ($order['status'] === 'confirmed'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="orderID" value="<?php echo $order['orderID']; ?>">
                                                <input type="hidden" name="action" value="ship">
                                                <input type="text" name="trackingNumber" placeholder="Tracking #" style="width: 80px; padding: 4px;">
                                                <button type="submit" class="btn btn-primary btn-sm">Ship</button>
                                            </form>
                                        <?php elseif ($order['status'] === 'shipped'): ?>
                                            <small>Tracking: <?php echo htmlspecialchars($order['trackingNumber'] ?? 'N/A'); ?></small>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">No orders yet</div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>