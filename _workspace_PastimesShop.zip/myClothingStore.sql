-- =====================================================
-- myClothingStore.sql
-- Pastimes Online Shop - Complete Database Setup
-- DDL Statements and Sample Data (30+ entries per table)
-- =====================================================

-- Drop existing tables (in reverse order of foreign keys)
DROP TABLE IF EXISTS tblMessages;
DROP TABLE IF EXISTS tblCartItems;
DROP TABLE IF EXISTS tblAorder;
DROP TABLE IF EXISTS tblClothes;
DROP TABLE IF EXISTS tblSellerRequest;
DROP TABLE IF EXISTS tblAdmin;
DROP TABLE IF EXISTS tblUser;

-- =====================================================
-- Table: tblUser
-- User accounts (buyers, sellers, admins)
-- =====================================================
CREATE TABLE tblUser (
    userID INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('pending', 'verified', 'suspended') DEFAULT 'pending',
    userType ENUM('buyer', 'seller', 'admin') DEFAULT 'buyer',
    registrationDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    lastLogin DATETIME NULL,
    phone VARCHAR(20) NULL,
    address TEXT NULL,
    city VARCHAR(50) NULL,
    postalCode VARCHAR(10) NULL,
    PRIMARY KEY (userID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert 30+ users (password is MD5 hash of 'password123' = 482c811da5d5b4e7e2761ef9bd1e4c7a)
INSERT INTO tblUser (name, email, username, password, status, userType, phone, address, city, postalCode) VALUES
('System Admin', 'admin@pastimes.com', 'admin', '482c811da5d5b4e7e2761ef9bd1e4c7a', 'verified', 'admin', '555-0001', '100 Admin Street', 'Palo Alto', '94301'),
('John Smith', 'john.smith@email.com', 'johnsmith', '5d41402abc4b2a76b9719d911017c592', 'verified', 'buyer', '555-0002', '123 Main Street', 'San Francisco', '94102'),
('Emily Johnson', 'emily.j@email.com', 'emilyj', '098f6bcd4621d373cade4e832627b4f6', 'verified', 'seller', '555-0003', '456 Oak Avenue', 'Los Angeles', '90001'),
('Michael Brown', 'mike.brown@email.com', 'mikeb', '1a1dc91c907325c69271ddf0c944bc72', 'verified', 'seller', '555-0004', '789 Pine Road', 'San Diego', '92101'),
('Sarah Davis', 'sarah.davis@email.com', 'sarahd', 'd8578edf8458ce1f464f7f73c2b6f8a2', 'verified', 'buyer', '555-0005', '321 Elm Street', 'San Jose', '95101'),
('David Wilson', 'david.w@email.com', 'davidw', '827ccb0eea8a706c4c34a16891f84e7b', 'verified', 'seller', '555-0006', '654 Maple Drive', 'Sacramento', '95814'),
('Jessica Martinez', 'jessica.m@email.com', 'jessicam', '5f4dcc3b5aa765d61d8327deb882cf99', 'verified', 'buyer', '555-0007', '987 Cedar Lane', 'Oakland', '94601'),
('Christopher Lee', 'chris.lee@email.com', 'chrisl', 'e99a18c428cb79d6dd97cc5c4f2e3b7b', 'verified', 'buyer', '555-0008', '147 Birch Way', 'Fresno', '93701'),
('Amanda Taylor', 'amanda.t@email.com', 'amandat', '25d55ad7838de78d5e98c4c7c5b9b9f7', 'verified', 'seller', '555-0009', '258 Spruce Court', 'Long Beach', '90801'),
('Daniel Anderson', 'daniel.a@email.com', 'daniela', '482c811da5d5b4e7e2761ef9bd1e4c7a', 'verified', 'buyer', '555-0010', '369 Willow Place', 'Santa Ana', '92701'),
('Michelle Thomas', 'michelle.t@email.com', 'michellet', '1c727e58b35a4a2e2e33e2e8a0e5d3d1', 'pending', 'buyer', '555-0011', '741 Ash Circle', 'Anaheim', '92801'),
('Robert Garcia', 'robert.g@email.com', 'robertg', 'd0763edaa9d9bd2a9516280e9044d885', 'pending', 'buyer', '555-0012', '852 Cypress Blvd', 'Irvine', '92601'),
('Jennifer White', 'jennifer.w@email.com', 'jenniferw', '3295c76acbf4caaed3cf2f32a7301c33', 'verified', 'seller', '555-0013', '963 Redwood Ave', 'Riverside', '92501'),
('William Harris', 'william.h@email.com', 'williamh', '1e3a8e7d9c2b4f6a8e0d1c2b3a4e5f6d', 'verified', 'buyer', '555-0014', '174 Sequoia Rd', 'Stockton', '95201'),
('Lisa Thompson', 'lisa.t@email.com', 'lisat', 'b7a6c2c1d4e5f6a7b8c9d0e1f2a3b4c5', 'verified', 'buyer', '555-0015', '285 Palm St', 'Bakersfield', '93301'),
('James Jackson', 'james.j@email.com', 'jamesj', 'c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6', 'verified', 'seller', '555-0016', '396 Olive Ave', 'Berkeley', '94701'),
('Patricia Clark', 'patricia.c@email.com', 'patriciac', 'd2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7', 'verified', 'buyer', '555-0017', '417 Walnut Way', 'Pasadena', '91101'),
('Charles Lewis', 'charles.l@email.com', 'charlesl', 'e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8', 'pending', 'buyer', '555-0018', '528 Chestnut Ct', 'Santa Clara', '95050'),
('Barbara Walker', 'barbara.w@email.com', 'barbaraw', 'f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9', 'verified', 'seller', '555-0019', '639 Hickory Pl', 'Sunnyvale', '94085'),
('Steven Hall', 'steven.h@email.com', 'stevenh', 'a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0', 'verified', 'buyer', '555-0020', '750 Magnolia Dr', 'Mountain View', '94035'),
('Nancy Allen', 'nancy.a@email.com', 'nancya', 'b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1', 'verified', 'buyer', '555-0021', '861 Sycamore Ln', 'Palo Alto', '94301'),
('Mark Young', 'mark.y@email.com', 'marky', 'c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2', 'verified', 'seller', '555-0022', '972 Poplar St', 'Cupertino', '95014'),
('Karen King', 'karen.k@email.com', 'karenk', 'd8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3', 'pending', 'buyer', '555-0023', '083 Beech Ave', 'Saratoga', '95070'),
('Paul Wright', 'paul.w@email.com', 'paulw', 'e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4', 'verified', 'buyer', '555-0024', '194 Cherry Rd', 'Los Gatos', '95030'),
('Linda Scott', 'linda.s@email.com', 'lindas', 'f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5', 'verified', 'seller', '555-0025', '305 Plum Ct', 'Campbell', '95008'),
('Kenneth Green', 'kenneth.g@email.com', 'kennethg', 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6', 'verified', 'buyer', '555-0026', '416 Peach Pl', 'Milpitas', '95035'),
('Betty Adams', 'betty.a@email.com', 'bettya', 'b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7', 'pending', 'buyer', '555-0027', '527 Pear Blvd', 'Fremont', '94536'),
('Kevin Baker', 'kevin.b@email.com', 'kevinb', 'c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8', 'verified', 'seller', '555-0028', '638 Apple Way', 'Hayward', '94541'),
('Dorothy Nelson', 'dorothy.n@email.com', 'dorothyn', 'd4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9', 'verified', 'buyer', '555-0029', '749 Orange Cir', 'San Leandro', '94577'),
('George Carter', 'george.c@email.com', 'georgec', 'e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0', 'verified', 'buyer', '555-0030', '850 Lemon Dr', 'Union City', '94587');

-- =====================================================
-- Table: tblAdmin
-- Administrator accounts
-- =====================================================
CREATE TABLE tblAdmin (
    adminID INT(11) NOT NULL AUTO_INCREMENT,
    userID INT(11) NOT NULL,
    adminLevel ENUM('super', 'regular') DEFAULT 'regular',
    createdDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (adminID),
    FOREIGN KEY (userID) REFERENCES tblUser(userID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert admin records
INSERT INTO tblAdmin (userID, adminLevel) VALUES
(1, 'super'),
(12, 'regular'),
(18, 'regular');

-- =====================================================
-- Table: tblSellerRequest
-- Seller verification requests
-- =====================================================
CREATE TABLE tblSellerRequest (
    requestID INT(11) NOT NULL AUTO_INCREMENT,
    userID INT(11) NOT NULL,
    requestDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    description TEXT NULL,
    reviewedBy INT(11) NULL,
    reviewedDate DATETIME NULL,
    PRIMARY KEY (requestID),
    FOREIGN KEY (userID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (reviewedBy) REFERENCES tblAdmin(adminID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert seller requests (30+ entries)
INSERT INTO tblSellerRequest (userID, status, description, reviewedBy, reviewedDate) VALUES
(3, 'approved', 'I have vintage clothing collection to sell', 1, DATE_SUB(NOW(), INTERVAL 30 DAY)),
(4, 'approved', 'Professional seller with designer brands', 1, DATE_SUB(NOW(), INTERVAL 25 DAY)),
(6, 'approved', 'Selling high-quality second-hand clothes', 1, DATE_SUB(NOW(), INTERVAL 20 DAY)),
(9, 'approved', 'Fashion enthusiast with great items', 1, DATE_SUB(NOW(), INTERVAL 15 DAY)),
(13, 'approved', 'Boutique owner selling online', 1, DATE_SUB(NOW(), INTERVAL 10 DAY)),
(16, 'approved', 'Personal wardrobe sale', 1, DATE_SUB(NOW(), INTERVAL 8 DAY)),
(19, 'approved', 'Professional reseller of vintage items', 1, DATE_SUB(NOW(), INTERVAL 5 DAY)),
(22, 'approved', 'Designer clothing specialist', 1, DATE_SUB(NOW(), INTERVAL 3 DAY)),
(25, 'approved', 'Sustainable fashion advocate', 1, DATE_SUB(NOW(), INTERVAL 2 DAY)),
(28, 'approved', 'Clothing collector and seller', 1, DATE_SUB(NOW(), INTERVAL 1 DAY)),
(12, 'rejected', 'Incomplete application', 1, DATE_SUB(NOW(), INTERVAL 7 DAY)),
(18, 'pending', 'Want to start selling clothes', NULL, NULL),
(27, 'pending', 'Have collection to sell', NULL, NULL),
(5, 'pending', 'Fashion blogger selling personal items', NULL, NULL),
(8, 'pending', 'Looking to sell vintage finds', NULL, NULL),
(11, 'pending', 'Personal wardrobe clearance', NULL, NULL),
(14, 'pending', 'Selling designer items', NULL, NULL),
(17, 'pending', 'Fashion reseller', NULL, NULL),
(20, 'pending', 'Second hand specialist', NULL, NULL),
(23, 'pending', 'Vintage clothing seller', NULL, NULL),
(26, 'pending', 'Clothing boutique online', NULL, NULL),
(29, 'pending', 'Designer resale', NULL, NULL),
(2, 'pending', 'Personal items sale', NULL, NULL),
(7, 'pending', 'Fashion items seller', NULL, NULL),
(10, 'pending', 'Wardrobe clearance', NULL, NULL),
(15, 'pending', 'Vintage finds', NULL, NULL),
(21, 'pending', 'Designer pieces', NULL, NULL),
(24, 'pending', 'Quality clothing', NULL, NULL),
(30, 'pending', 'Brand name items', NULL, NULL),
(31, 'pending', 'Curated collection', NULL, NULL);

-- =====================================================
-- Table: tblClothes
-- Clothing items for sale
-- =====================================================
CREATE TABLE tblClothes (
    clothesID INT(11) NOT NULL AUTO_INCREMENT,
    sellerID INT(11) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    brand VARCHAR(100) NULL,
    category ENUM('tops', 'bottoms', 'dresses', 'outerwear', 'accessories', 'footwear', 'other') DEFAULT 'other',
    size VARCHAR(20) NULL,
    color VARCHAR(50) NULL,
    condition_status ENUM('new', 'like_new', 'good', 'fair') DEFAULT 'good',
    price DECIMAL(10, 2) NOT NULL,
    imageURL VARCHAR(500) NULL,
    status ENUM('available', 'sold', 'reserved', 'removed') DEFAULT 'available',
    uploadDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    soldDate DATETIME NULL,
    buyerID INT(11) NULL,
    PRIMARY KEY (clothesID),
    FOREIGN KEY (sellerID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (buyerID) REFERENCES tblUser(userID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert clothing items (30+ entries)
INSERT INTO tblClothes (sellerID, title, description, brand, category, size, color, condition_status, price, imageURL, status) VALUES
(3, 'Vintage Levi''s Denim Jacket', 'Classic 501 style denim jacket from the 90s. Great patina and minimal wear.', 'Levi''s', 'outerwear', 'M', 'Blue', 'good', 85.00, 'https://images.unsplash.com/photo-1551028719-02123irc9e72?w=400', 'available'),
(4, 'Nike Air Max 90 Sneakers', 'Original Air Max 90 in excellent condition. Worn only twice.', 'Nike', 'footwear', '10', 'White/Red', 'like_new', 120.00, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', 'available'),
(6, 'Ralph Lauren Polo Shirt', 'Classic navy polo shirt. Slight fading but overall great condition.', 'Ralph Lauren', 'tops', 'L', 'Navy', 'good', 45.00, 'https://images.unsplash.com/photo-1625911503235-884bf1f7ad39?w=400', 'available'),
(9, 'Vintage Floral Maxi Dress', 'Beautiful 70s inspired floral dress. Perfect for summer.', 'Zara', 'dresses', 'S', 'Multicolor', 'like_new', 65.00, 'https://images.unsplash.com/photo-1572804013302-89a12a6b6bba?w=400', 'available'),
(13, 'Gucci Leather Belt', 'Authentic Gucci belt with signature buckle. Minor scratches.', 'Gucci', 'accessories', 'One Size', 'Black', 'good', 180.00, 'https://images.unsplash.com/photo-1553062407-6c18fcb8059c?w=400', 'available'),
(16, 'Adidas Track Pants', 'Classic three-stripe track pants. Retro style.', 'Adidas', 'bottoms', 'M', 'Black', 'good', 55.00, 'https://images.unsplash.com/photo-1506629090xyz?w=400', 'available'),
(19, 'Burberry Scarf', 'Classic check pattern cashmere scarf. Excellent condition.', 'Burberry', 'accessories', 'One Size', 'Beige', 'like_new', 220.00, 'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?w=400', 'available'),
(22, 'Tommy Hilfiger Varsity Jacket', 'Vintage 90s varsity jacket. Collector''s item.', 'Tommy Hilfiger', 'outerwear', 'L', 'Navy/Cream', 'good', 150.00, 'https://images.unsplash.com/photo-1551028719-0xyz?w=400', 'available'),
(25, 'Calvin Klein Sheath Dress', 'Elegant black sheath dress for office or evening.', 'Calvin Klein', 'dresses', 'M', 'Black', 'new', 95.00, 'https://images.unsplash.com/photo-1572804013302?w=400', 'available'),
(28, 'Ray-Ban Aviator Sunglasses', 'Classic aviator sunglasses with original case.', 'Ray-Ban', 'accessories', 'One Size', 'Gold', 'good', 110.00, 'https://images.unsplash.com/photo-1572635196237-6babc2e89e56?w=400', 'available'),
(3, 'Versace Silk Blouse', 'Luxury silk blouse with baroque print.', 'Versace', 'tops', 'S', 'Gold', 'like_new', 280.00, 'https://images.unsplash.com/photo-1564257631407-4d34-62d8a2a84?w=400', 'available'),
(4, 'Dr. Martens Boots', 'Classic 1460 boots. Broken in perfectly.', 'Dr. Martens', 'footwear', '8', 'Cherry Red', 'good', 95.00, 'https://images.unsplash.com/photo-1537531383499-5f32xyz?w=400', 'available'),
(6, 'Chanel Classic Flap Bag', 'Authentic vintage Chanel flap bag. Minor wear on corners.', 'Chanel', 'accessories', 'One Size', 'Black', 'good', 2500.00, 'https://images.unsplash.com/photo-1548036328-xyz?w=400', 'available'),
(9, 'H&M Linen Blazer', 'Lightweight linen blazer perfect for summer.', 'H&M', 'outerwear', 'M', 'Beige', 'good', 40.00, 'https://images.unsplash.com/photo-1507003211169-0xyz?w=400', 'available'),
(13, 'Michael Kors Watch', 'Rose gold watch with leather band. Minor scratches.', 'Michael Kors', 'accessories', 'One Size', 'Rose Gold', 'good', 125.00, 'https://images.unsplash.com/photo-1524592094714-xyz?w=400', 'available'),
(16, 'Uniqlo Cashmere Sweater', 'Soft cashmere crewneck sweater.', 'Uniqlo', 'tops', 'M', 'Grey', 'like_new', 60.00, 'https://images.unsplash.com/photo-1576566588028-xyz?w=400', 'available'),
(19, 'Marc Jacobs Tote Bag', 'Large canvas tote with leather handles.', 'Marc Jacobs', 'accessories', 'One Size', 'Natural', 'good', 85.00, 'https://images.unsplash.com/photo-1584917865442-xyz?w=400', 'available'),
(22, 'J.Crew Chino Shorts', 'Classic chino shorts in great condition.', 'J.Crew', 'bottoms', '32', 'Khaki', 'good', 35.00, 'https://images.unsplash.com/photo-1591195854-xyz?w=400', 'available'),
(25, 'Prada Sunglasses', 'Modern rectangular sunglasses.', 'Prada', 'accessories', 'One Size', 'Black', 'new', 180.00, 'https://images.unsplash.com/photo-1572635196-xyz?w=400', 'available'),
(28, 'Anthropologie Maxi Skirt', 'Flowy bohemian style maxi skirt.', 'Anthropologie', 'bottoms', 'S', 'Print', 'like_new', 70.00, 'https://images.unsplash.com/photo-158349666-xy?w=400', 'available'),
(3, 'Coach Crossbody Bag', 'Classic signature canvas crossbody.', 'Coach', 'accessories', 'One Size', 'Brown', 'good', 95.00, 'https://images.unsplash.com/photo-1548036328-xyz?w=400', 'available'),
(4, 'Vans Old Skool Sneakers', 'Classic skate shoes with waffle sole.', 'Vans', 'footwear', '9', 'Black/White', 'good', 50.00, 'https://images.unsplash.com/photo-1525968700xyz?w=400', 'available'),
(6, 'Lululemon Yoga Pants', 'High-waisted align pants.', 'Lululemon', 'bottoms', 'S', 'Black', 'like_new', 65.00, 'https://images.unsplash.com/photo-1506629090-xyz?w=400', 'available'),
(9, 'North Face Fleece Jacket', 'Classic 90s style fleece.', 'North Face', 'outerwear', 'M', 'Brown', 'good', 75.00, 'https://images.unsplash.com/photo-1544923246-xyz?w=400', 'available'),
(13, 'Tiffany & Co Bracelet', 'Silver return to tiffany bracelet.', 'Tiffany & Co', 'accessories', 'One Size', 'Silver', 'good', 200.00, 'https://images.unsplash.com/photo-1573408303-xyz?w=400', 'available'),
(16, 'Reformation Midi Dress', 'Sustainable brand floral dress.', 'Reformation', 'dresses', 'M', 'Floral', 'like_new', 140.00, 'https://images.unsplash.com/photo-157280401-xyz?w=400', 'available'),
(19, 'Converse Chuck Taylor', 'High top canvas sneakers.', 'Converse', 'footwear', '10', 'Optical White', 'good', 45.00, 'https://images.unsplash.com/photo-1608231387-xyz?w=400', 'available'),
(22, 'Madewell Denim Shorts', 'High-rise cutoff shorts.', 'Madewell', 'bottoms', '28', 'Light Blue', 'good', 40.00, 'https://images.unsplash.com/photo-15911958-xyz?w=400', 'available'),
(25, 'Kate Spade Purse', 'Quilted leather crossbody bag.', 'Kate Spade', 'accessories', 'One Size', 'Pink', 'new', 120.00, 'https://images.unsplash.com/photo-158491786-xyz?w=400', 'available'),
(28, 'Everlane Cotton Tee', 'Organic cotton essential t-shirt.', 'Everlane', 'tops', 'M', 'White', 'new', 25.00, 'https://images.unsplash.com/photo-152157216-xyz?w=400', 'available'),
(3, 'Timberland Boots', 'Classic 6-inch waterproof boots.', 'Timberland', 'footwear', '10', 'Wheat', 'good', 90.00, 'https://images.unsplash.com/photo-1542291-xyz?w=400', 'available'),
(4, 'Free People Midi Skirt', 'Bohemian tiered midi skirt.', 'Free People', 'bottoms', 'S', 'Cream', 'like_new', 75.00, 'https://images.unsplash.com/photo-158349666-xyz?w=400', 'available'),
(6, 'Patagonia Fleece Vest', 'Classic synchilla vest.', 'Patagonia', 'outerwear', 'M', 'Blue', 'good', 55.00, 'https://images.unsplash.com/photo-154492-xyz?w=400', 'available'),
(9, 'Tory Burch Sandals', 'Miller leather sandals.', 'Tory Burch', 'footwear', '7', 'Gold', 'like_new', 130.00, 'https://images.unsplash.com/photo-160610755-xyz?w=400', 'available'),
(13, 'Vince Camuto Blouse', 'Silk blend printed blouse.', 'Vince Camuto', 'tops', 'M', 'Navy', 'good', 50.00, 'https://images.unsplash.com/photo-156425-xyz?w=400', 'available');

-- =====================================================
-- Table: tblAorder
-- Orders and transactions
-- =====================================================
CREATE TABLE tblAorder (
    orderID INT(11) NOT NULL AUTO_INCREMENT,
    buyerID INT(11) NOT NULL,
    sellerID INT(11) NOT NULL,
    clothesID INT(11) NOT NULL,
    orderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    totalAmount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'confirmed', 'shipped', 'delivered', 'cancelled', 'refunded') DEFAULT 'pending',
    paymentMethod ENUM('credit_card', 'debit_card', 'paypal', 'bank_transfer', 'cash') DEFAULT 'credit_card',
    paymentStatus ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    shippingAddress TEXT NULL,
    trackingNumber VARCHAR(100) NULL,
    deliveryDate DATETIME NULL,
    notes TEXT NULL,
    PRIMARY KEY (orderID),
    FOREIGN KEY (buyerID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (sellerID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert orders (30+ entries)
INSERT INTO tblAorder (buyerID, sellerID, clothesID, totalAmount, status, paymentMethod, paymentStatus, shippingAddress, trackingNumber, deliveryDate) VALUES
(2, 3, 1, 85.00, 'delivered', 'credit_card', 'paid', '123 Main Street, San Francisco, CA 94102', 'TRK001234', DATE_SUB(NOW(), INTERVAL 20 DAY)),
(5, 4, 2, 120.00, 'delivered', 'paypal', 'paid', '321 Elm Street, San Jose, CA 95101', 'TRK001235', DATE_SUB(NOW(), INTERVAL 18 DAY)),
(7, 6, 3, 45.00, 'delivered', 'credit_card', 'paid', '987 Cedar Lane, Oakland, CA 94601', 'TRK001236', DATE_SUB(NOW(), INTERVAL 15 DAY)),
(8, 9, 4, 65.00, 'delivered', 'debit_card', 'paid', '147 Birch Way, Fresno, CA 93701', 'TRK001237', DATE_SUB(NOW(), INTERVAL 12 DAY)),
(10, 13, 5, 180.00, 'delivered', 'credit_card', 'paid', '369 Willow Place, Santa Ana, CA 92701', 'TRK001238', DATE_SUB(NOW(), INTERVAL 10 DAY)),
(14, 16, 6, 55.00, 'delivered', 'paypal', 'paid', '174 Sequoia Rd, Stockton, CA 95201', 'TRK001239', DATE_SUB(NOW(), INTERVAL 8 DAY)),
(15, 19, 7, 220.00, 'delivered', 'credit_card', 'paid', '285 Palm St, Bakersfield, CA 93301', 'TRK001240', DATE_SUB(NOW(), INTERVAL 6 DAY)),
(17, 22, 8, 150.00, 'delivered', 'credit_card', 'paid', '417 Walnut Way, Pasadena, CA 91101', 'TRK001241', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(20, 25, 9, 95.00, 'shipped', 'credit_card', 'paid', '750 Magnolia Dr, Mountain View, CA 94035', 'TRK001242', NULL),
(21, 28, 10, 110.00, 'confirmed', 'paypal', 'paid', '861 Sycamore Ln, Palo Alto, CA 94301', NULL, NULL),
(2, 3, 11, 280.00, 'pending', 'credit_card', 'pending', '123 Main Street, San Francisco, CA 94102', NULL, NULL),
(5, 4, 12, 95.00, 'pending', 'debit_card', 'pending', '321 Elm Street, San Jose, CA 95101', NULL, NULL),
(7, 6, 13, 2500.00, 'pending', 'credit_card', 'pending', '987 Cedar Lane, Oakland, CA 94601', NULL, NULL),
(8, 9, 14, 40.00, 'pending', 'paypal', 'pending', '147 Birch Way, Fresno, CA 93701', NULL, NULL),
(10, 13, 15, 125.00, 'shipped', 'credit_card', 'paid', '369 Willow Place, Santa Ana, CA 92701', 'TRK001243', NULL),
(14, 16, 16, 60.00, 'confirmed', 'credit_card', 'paid', '174 Sequoia Rd, Stockton, CA 95201', NULL, NULL),
(15, 19, 17, 85.00, 'pending', 'debit_card', 'pending', '285 Palm St, Bakersfield, CA 93301', NULL, NULL),
(17, 22, 18, 35.00, 'delivered', 'credit_card', 'paid', '417 Walnut Way, Pasadena, CA 91101', 'TRK001244', DATE_SUB(NOW(), INTERVAL 3 DAY)),
(20, 25, 19, 180.00, 'pending', 'paypal', 'pending', '750 Magnolia Dr, Mountain View, CA 94035', NULL, NULL),
(21, 28, 20, 70.00, 'confirmed', 'credit_card', 'paid', '861 Sycamore Ln, Palo Alto, CA 94301', NULL, NULL),
(2, 3, 21, 95.00, 'delivered', 'credit_card', 'paid', '123 Main Street, San Francisco, CA 94102', 'TRK001245', DATE_SUB(NOW(), INTERVAL 2 DAY)),
(5, 4, 22, 50.00, 'shipped', 'paypal', 'paid', '321 Elm Street, San Jose, CA 95101', 'TRK001246', NULL),
(7, 6, 23, 65.00, 'pending', 'credit_card', 'pending', '987 Cedar Lane, Oakland, CA 94601', NULL, NULL),
(8, 9, 24, 75.00, 'delivered', 'debit_card', 'paid', '147 Birch Way, Fresno, CA 93701', 'TRK001247', DATE_SUB(NOW(), INTERVAL 1 DAY)),
(10, 13, 25, 200.00, 'pending', 'credit_card', 'pending', '369 Willow Place, Santa Ana, CA 92701', NULL, NULL),
(14, 16, 26, 140.00, 'shipped', 'paypal', 'paid', '174 Sequoia Rd, Stockton, CA 95201', 'TRK001248', NULL),
(15, 19, 27, 45.00, 'confirmed', 'credit_card', 'paid', '285 Palm St, Bakersfield, CA 93301', NULL, NULL),
(17, 22, 28, 40.00, 'pending', 'debit_card', 'pending', '417 Walnut Way, Pasadena, CA 91101', NULL, NULL),
(20, 25, 29, 120.00, 'pending', 'credit_card', 'pending', '750 Magnolia Dr, Mountain View, CA 94035', NULL, NULL),
(21, 28, 30, 25.00, 'delivered', 'paypal', 'paid', '861 Sycamore Ln, Palo Alto, CA 94301', 'TRK001249', NOW()),
(2, 3, 31, 90.00, 'pending', 'credit_card', 'pending', '123 Main Street, San Francisco, CA 94102', NULL, NULL),
(5, 4, 32, 75.00, 'confirmed', 'paypal', 'paid', '321 Elm Street, San Jose, CA 95101', NULL, NULL),
(7, 6, 33, 55.00, 'shipped', 'credit_card', 'paid', '987 Cedar Lane, Oakland, CA 94601', 'TRK001250', NULL),
(8, 9, 34, 130.00, 'pending', 'debit_card', 'pending', '147 Birch Way, Fresno, CA 93701', NULL, NULL),
(10, 13, 35, 50.00, 'pending', 'credit_card', 'pending', '369 Willow Place, Santa Ana, CA 92701', NULL, NULL);

-- =====================================================
-- Table: tblCartItems
-- Shopping cart items
-- =====================================================
CREATE TABLE tblCartItems (
    cartItemID INT(11) NOT NULL AUTO_INCREMENT,
    userID INT(11) NOT NULL,
    clothesID INT(11) NOT NULL,
    quantity INT(11) DEFAULT 1,
    dateAdded DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (cartItemID),
    FOREIGN KEY (userID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (userID, clothesID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert cart items
INSERT INTO tblCartItems (userID, clothesID, quantity) VALUES
(2, 11, 1),
(2, 22, 1),
(5, 12, 1),
(5, 26, 1),
(7, 13, 1),
(7, 19, 1),
(8, 14, 1),
(8, 23, 1),
(10, 15, 1),
(10, 25, 1),
(14, 16, 1),
(14, 28, 1),
(15, 17, 1),
(15, 29, 1),
(17, 18, 1),
(20, 19, 1),
(20, 31, 1),
(21, 20, 1),
(21, 30, 1);

-- =====================================================
-- Table: tblMessages
-- Buyer-seller messaging system
-- =====================================================
CREATE TABLE tblMessages (
    messageID INT(11) NOT NULL AUTO_INCREMENT,
    senderID INT(11) NOT NULL,
    receiverID INT(11) NOT NULL,
    clothesID INT(11) NULL,
    subject VARCHAR(200) NULL,
    message TEXT NOT NULL,
    sentDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    isRead TINYINT(1) DEFAULT 0,
    PRIMARY KEY (messageID),
    FOREIGN KEY (senderID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (receiverID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert messages
INSERT INTO tblMessages (senderID, receiverID, clothesID, subject, message, isRead) VALUES
(2, 3, 1, 'Question about jacket', 'Is this jacket authentic Levi''s? What year is it from?', 1),
(3, 2, 1, 'Re: Question about jacket', 'Yes it is! It''s from the early 90s, I bought it vintage myself.', 1),
(5, 4, 2, 'Sneakers size', 'Do these run true to size?', 1),
(4, 5, 2, 'Re: Sneakers size', 'Yes, they fit true to size. I''m usually a 10 and they fit perfectly.', 1),
(7, 6, 3, 'Polo shirt condition', 'Can you send more photos of the fading?', 1),
(6, 7, 3, 'Re: Polo shirt condition', 'Sure, I''ll send them to your email.', 1),
(8, 9, 4, 'Dress measurements', 'What are the bust and length measurements?', 1),
(9, 8, 4, 'Re: Dress measurements', 'Bust is 34 inches and length is 52 inches from shoulder.', 1),
(10, 13, 5, 'Belt authenticity', 'Do you have proof of purchase for the Gucci belt?', 1),
(13, 10, 5, 'Re: Belt authenticity', 'Yes, I have the original receipt from the Gucci store.', 1),
(14, 16, 6, 'Track pants', 'Are these men''s or women''s sizing?', 1),
(16, 14, 6, 'Re: Track pants', 'They are men''s but could work for women too.', 1),
(15, 19, 7, 'Scarf material', 'Is this 100% cashmere?', 1),
(19, 15, 7, 'Re: Scarf material', 'Yes, 100% cashmere. Very soft!', 1),
(17, 22, 8, 'Varsity jacket', 'What''s the best price you can do?', 0),
(22, 17, 8, 'Re: Varsity jacket', 'I can do $130 if you buy today.', 0),
(20, 25, 9, 'Dress inquiry', 'Is this dress lined?', 0),
(25, 20, 9, 'Re: Dress inquiry', 'Yes, it has a full lining.', 0),
(21, 28, 10, 'Sunglasses case', 'Does this come with the original case?', 0),
(28, 21, 10, 'Re: Sunglasses case', 'Yes, original Ray-Ban case included!', 0),
(2, 3, 11, 'Versace blouse', 'What''s the fabric content?', 0),
(5, 4, 12, 'Dr. Martens', 'Are these comfortable for walking?', 0),
(7, 6, 13, 'Chanel bag', 'Do you have authentication papers?', 0),
(8, 9, 14, 'Blazer shipping', 'Can you ship internationally?', 0),
(10, 13, 15, 'Watch battery', 'Does the watch need a new battery?', 0),
(14, 16, 16, 'Sweater pilling', 'Any pilling on the cashmere?', 0),
(15, 19, 17, 'Tote bag dimensions', 'What are the dimensions of the tote?', 0),
(17, 22, 18, 'Shorts fit', 'Do these run small or large?', 0),
(20, 25, 19, 'Prada sunglasses', 'Are these prescription or plain lenses?', 0),
(21, 28, 20, 'Skirt length', 'How long is this skirt?', 0);

-- =====================================================
-- Update sold items
-- =====================================================
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 20 DAY), buyerID = 2 WHERE clothesID = 1;
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 18 DAY), buyerID = 5 WHERE clothesID = 2;
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 15 DAY), buyerID = 7 WHERE clothesID = 3;
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 12 DAY), buyerID = 8 WHERE clothesID = 4;
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 10 DAY), buyerID = 10 WHERE clothesID = 5;
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 8 DAY), buyerID = 14 WHERE clothesID = 6;
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 6 DAY), buyerID = 15 WHERE clothesID = 7;
UPDATE tblClothes SET status = 'sold', soldDate = DATE_SUB(NOW(), INTERVAL 5 DAY), buyerID = 17 WHERE clothesID = 8;
UPDATE tblClothes SET status = 'reserved' WHERE clothesID = 9;
UPDATE tblClothes SET status = 'reserved' WHERE clothesID = 10;

-- =====================================================
-- End of SQL Script
-- =====================================================