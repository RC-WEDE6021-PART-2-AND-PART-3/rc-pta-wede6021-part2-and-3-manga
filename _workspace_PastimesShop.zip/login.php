<?php
/**
 * login.php - User Login Page
 * Pastimes Online Shop
 * 
 * Features:
 * - Login with username and email
 * - MD5/SHA password validation
 * - HTML5 form validation
 * - Sticky forms (retain entered data except password on failure)
 * - Display "User [Name] is logged in" on success
 */

session_start();
require_once 'includes/DBConn.php';

// Redirect if already logged in
if (isset($_SESSION['userID'])) {
    header('Location: index.php');
    exit();
}

$errors = [];
$stickyData = [
    'username' => '',
    'email' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stickyData['username'] = trim($_POST['username'] ?? '');
    $stickyData['email'] = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Validation
    if (empty($stickyData['username'])) {
        $errors[] = "Username is required";
    }
    
    if (empty($stickyData['email'])) {
        $errors[] = "Email is required";
    } elseif (!filter_var($stickyData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    }
    
    // If no validation errors, attempt login
    if (empty($errors)) {
        $username = sanitizeInput($stickyData['username']);
        $email = sanitizeInput($stickyData['email']);
        $hashedPassword = hashPassword($password); // MD5 hash
        $hashedPasswordSHA = hashPasswordSHA($password); // SHA256 hash
        
        // Check credentials against database
        $sql = "SELECT * FROM tblUser WHERE username = '$username' AND email = '$email'";
        $result = $connection->query($sql);
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Check password (support both MD5 and SHA256 hashes)
            if ($user['password'] === $hashedPassword || $user['password'] === $hashedPasswordSHA) {
                // Check if user is verified
                if ($user['status'] === 'pending') {
                    $errors[] = "Your account is pending verification. Please wait for administrator approval.";
                } elseif ($user['status'] === 'suspended') {
                    $errors[] = "Your account has been suspended. Please contact support.";
                } else {
                    // Login successful - set session variables
                    $_SESSION['userID'] = $user['userID'];
                    $_SESSION['name'] = $user['name'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['userType'] = $user['userType'];
                    $_SESSION['isLoggedIn'] = true;
                    
                    // Update last login time
                    $connection->query("UPDATE tblUser SET lastLogin = NOW() WHERE userID = " . $user['userID']);
                    
                    // Redirect based on user type
                    if ($user['userType'] === 'admin') {
                        header('Location: admin/dashboard.php');
                    } elseif ($user['userType'] === 'seller') {
                        header('Location: seller/dashboard.php');
                    } else {
                        header('Location: index.php');
                    }
                    exit();
                }
            } else {
                $errors[] = "Invalid password. Please try again.";
            }
        } else {
            $errors[] = "Invalid username or email combination.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Pastimes Online Shop</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <div class="user-nav">
                <a href="register.php" class="btn btn-outline btn-sm">Register</a>
            </div>
        </div>
    </header>

    <main>
        <div class="form-container">
            <h2>Login to Your Account</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul style="margin: 0; padding-left: 20px;">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" novalidate>
                <div class="form-group">
                    <label for="username">Username *</label>
                    <input type="text" 
                           id="username" 
                           name="username" 
                           value="<?php echo htmlspecialchars($stickyData['username']); ?>" 
                           placeholder="Enter your username"
                           required
                           class="<?php echo !empty($stickyData['username']) ? 'sticky' : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address *</label>
                    <input type="email" 
                           id="email" 
                           name="email" 
                           value="<?php echo htmlspecialchars($stickyData['email']); ?>" 
                           placeholder="Enter your email"
                           required
                           class="<?php echo !empty($stickyData['email']) ? 'sticky' : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password *</label>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           placeholder="Enter your password"
                           required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
            
            <div class="mt-3 text-center">
                <p>Don't have an account? <a href="register.php">Register here</a></p>
                <p><a href="admin/login.php">Admin Login</a></p>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>