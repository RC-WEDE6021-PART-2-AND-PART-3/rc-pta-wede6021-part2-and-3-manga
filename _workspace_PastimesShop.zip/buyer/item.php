<?php
/**
 * buyer/item.php - Item Detail Page
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

$isLoggedIn = isset($_SESSION['userID']);
$userID = $isLoggedIn ? $_SESSION['userID'] : 0;
$userName = $isLoggedIn ? $_SESSION['name'] : '';

// Get item ID
$itemID = intval($_GET['id'] ?? 0);

if ($itemID === 0) {
    header('Location: catalog.php');
    exit();
}

// Get item details
$item = null;
$result = $connection->query("SELECT c.*, u.name as sellerName, u.email as sellerEmail, u.userID as sellerID 
    FROM tblClothes c 
    JOIN tblUser u ON c.sellerID = u.userID 
    WHERE c.clothesID = $itemID");

if ($result->num_rows === 1) {
    $item = $result->fetch_assoc();
} else {
    header('Location: catalog.php');
    exit();
}

$success = '';
$error = '';

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addToCart']) && $isLoggedIn) {
    // Check if item already in cart
    $existingResult = $connection->query("SELECT * FROM tblCartItems WHERE userID = $userID AND clothesID = $itemID");
    
    if ($existingResult->num_rows > 0) {
        $error = "Item already in your cart";
    } else {
        if ($connection->query("INSERT INTO tblCartItems (userID, clothesID) VALUES ($userID, $itemID)")) {
            $success = "Item added to cart!";
        } else {
            $error = "Failed to add to cart";
        }
    }
}

// Handle send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sendMessage']) && $isLoggedIn) {
    $message = sanitizeInput($_POST['message']);
    $receiverID = $item['sellerID'];
    
    if (!empty($message)) {
        $sql = "INSERT INTO tblMessages (senderID, receiverID, clothesID, message) 
                VALUES ($userID, $receiverID, $itemID, '$message')";
        if ($connection->query($sql)) {
            $success = "Message sent to seller!";
        }
    }
}

// Handle purchase (create order)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buyNow']) && $isLoggedIn) {
    $shippingAddress = sanitizeInput($_POST['shippingAddress']);
    $paymentMethod = sanitizeInput($_POST['paymentMethod']);
    
    $connection->begin_transaction();
    try {
        // Create order
        $sql = "INSERT INTO tblAorder (buyerID, sellerID, clothesID, totalAmount, paymentMethod, shippingAddress) 
                VALUES ($userID, {$item['sellerID']}, $itemID, {$item['price']}, '$paymentMethod', '$shippingAddress')";
        $connection->query($sql);
        
        // Mark item as reserved
        $connection->query("UPDATE tblClothes SET status = 'reserved' WHERE clothesID = $itemID");
        
        // Remove from cart if exists
        $connection->query("DELETE FROM tblCartItems WHERE userID = $userID AND clothesID = $itemID");
        
        $connection->commit();
        $success = "Order placed successfully! Order ID: #" . $connection->insert_id;
    } catch (Exception $e) {
        $connection->rollback();
        $error = "Failed to place order. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($item['title']); ?> - Pastimes Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="../index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <nav>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="catalog.php" class="active">Shop</a></li>
                </ul>
            </nav>
            <div class="user-nav">
                <?php if ($isLoggedIn): ?>
                    <a href="cart.php" class="btn btn-primary btn-sm">Cart</a>
                    <a href="messages.php" class="btn btn-outline btn-sm">Messages</a>
                    <a href="../logout.php" class="btn btn-secondary btn-sm">Logout</a>
                <?php else: ?>
                    <a href="../login.php" class="btn btn-primary btn-sm">Login</a>
                    <a href="../register.php" class="btn btn-outline btn-sm">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="flex gap-3 mt-4" style="align-items: flex-start;">
                <!-- Item Image -->
                <div style="flex: 1;">
                    <img src="<?php echo htmlspecialchars($item['imageURL'] ?: '../images/placeholder.jpg'); ?>" 
                         alt="<?php echo htmlspecialchars($item['title']); ?>" 
                         style="width: 100%; border-radius: var(--border-radius); box-shadow: var(--shadow);">
                </div>
                
                <!-- Item Details -->
                <div style="flex: 1;">
                    <h1><?php echo htmlspecialchars($item['title']); ?></h1>
                    
                    <span class="status-badge status-<?php echo $item['status']; ?>" style="font-size: 1rem; margin-bottom: 1rem; display: inline-block;">
                        <?php echo ucfirst($item['status']); ?>
                    </span>
                    
                    <p class="price" style="font-size: 2rem; margin: 1rem 0;">
                        $<?php echo number_format($item['price'], 2); ?>
                    </p>
                    
                    <div class="card" style="margin: 1rem 0;">
                        <div class="card-body">
                            <h3>Item Details</h3>
                            <p><strong>Brand:</strong> <?php echo htmlspecialchars($item['brand'] ?? 'Not specified'); ?></p>
                            <p><strong>Category:</strong> <?php echo ucfirst($item['category']); ?></p>
                            <p><strong>Size:</strong> <?php echo htmlspecialchars($item['size'] ?? 'Not specified'); ?></p>
                            <p><strong>Color:</strong> <?php echo htmlspecialchars($item['color'] ?? 'Not specified'); ?></p>
                            <p><strong>Condition:</strong> 
                                <span class="status-badge status-<?php echo $item['condition_status']; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $item['condition_status'])); ?>
                                </span>
                            </p>
                        </div>
                    </div>
                    
                    <div class="card" style="margin: 1rem 0;">
                        <div class="card-body">
                            <h3>Description</h3>
                            <p><?php echo nl2br(htmlspecialchars($item['description'] ?? 'No description available')); ?></p>
                        </div>
                    </div>
                    
                    <div class="card" style="margin: 1rem 0;">
                        <div class="card-body">
                            <h3>Seller Information</h3>
                            <p><strong>Seller:</strong> <?php echo htmlspecialchars($item['sellerName']); ?></p>
                            <p><strong>Listed:</strong> <?php echo date('F j, Y', strtotime($item['uploadDate'])); ?></p>
                        </div>
                    </div>
                    
                    <?php if ($isLoggedIn && $item['status'] === 'available'): ?>
                        <!-- Add to Cart Form -->
                        <form method="POST" style="margin-bottom: 1rem;">
                            <button type="submit" name="addToCart" class="btn btn-primary btn-lg btn-block">
                                Add to Cart
                            </button>
                        </form>
                        
                        <!-- Buy Now Form -->
                        <button class="btn btn-success btn-lg btn-block" onclick="showBuyForm()">
                            Buy Now
                        </button>
                        
                        <div id="buyForm" class="card mt-3" style="display: none;">
                            <div class="card-body">
                                <h3>Complete Purchase</h3>
                                <form method="POST">
                                    <div class="form-group">
                                        <label>Shipping Address *</label>
                                        <textarea name="shippingAddress" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Payment Method *</label>
                                        <select name="paymentMethod" required>
                                            <option value="credit_card">Credit Card</option>
                                            <option value="debit_card">Debit Card</option>
                                            <option value="paypal">PayPal</option>
                                            <option value="bank_transfer">Bank Transfer</option>
                                        </select>
                                    </div>
                                    <button type="submit" name="buyNow" class="btn btn-success btn-block">
                                        Confirm Purchase - $<?php echo number_format($item['price'], 2); ?>
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <!-- Message Seller Form -->
                        <div class="card mt-3">
                            <div class="card-body">
                                <h3>Message Seller</h3>
                                <form method="POST">
                                    <div class="form-group">
                                        <textarea name="message" placeholder="Ask the seller a question..." rows="3" required></textarea>
                                    </div>
                                    <button type="submit" name="sendMessage" class="btn btn-outline btn-block">
                                        Send Message
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php elseif (!$isLoggedIn): ?>
                        <div class="alert alert-warning">
                            Please <a href="../login.php">login</a> to purchase or message the seller.
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            This item is currently <?php echo $item['status']; ?> and not available for purchase.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script>
        function showBuyForm() {
            document.getElementById('buyForm').style.display = 'block';
        }
    </script>
</body>
</html>
<?php $connection->close(); ?>