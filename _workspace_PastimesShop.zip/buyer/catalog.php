<?php
/**
 * buyer/catalog.php - Clothing Catalog for Buyers
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

$isLoggedIn = isset($_SESSION['userID']);
$userName = $isLoggedIn ? $_SESSION['name'] : '';
$userType = $isLoggedIn ? $_SESSION['userType'] : '';

// Get filter parameters
$category = sanitizeInput($_GET['category'] ?? '');
$brand = sanitizeInput($_GET['brand'] ?? '');
$minPrice = floatval($_GET['minPrice'] ?? 0);
$maxPrice = floatval($_GET['maxPrice'] ?? 999999);
$size = sanitizeInput($_GET['size'] ?? '');
$condition = sanitizeInput($_GET['condition'] ?? '');
$sort = sanitizeInput($_GET['sort'] ?? 'newest');
$search = sanitizeInput($_GET['search'] ?? '');

// Build query
$whereClause = "WHERE c.status = 'available'";
if (!empty($category)) {
    $whereClause .= " AND c.category = '$category'";
}
if (!empty($brand)) {
    $whereClause .= " AND c.brand LIKE '%$brand%'";
}
if ($minPrice > 0 || $maxPrice < 999999) {
    $whereClause .= " AND c.price BETWEEN $minPrice AND $maxPrice";
}
if (!empty($size)) {
    $whereClause .= " AND c.size = '$size'";
}
if (!empty($condition)) {
    $whereClause .= " AND c.condition_status = '$condition'";
}
if (!empty($search)) {
    $whereClause .= " AND (c.title LIKE '%$search%' OR c.brand LIKE '%$search%' OR c.description LIKE '%$search%')";
}

// Sort order
$orderBy = "c.uploadDate DESC";
switch ($sort) {
    case 'price_low':
        $orderBy = "c.price ASC";
        break;
    case 'price_high':
        $orderBy = "c.price DESC";
        break;
    case 'oldest':
        $orderBy = "c.uploadDate ASC";
        break;
}

// Get items
$items = [];
$result = $connection->query("SELECT c.*, u.name as sellerName 
    FROM tblClothes c 
    JOIN tblUser u ON c.sellerID = u.userID 
    $whereClause 
    ORDER BY $orderBy");
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

// Get available brands for filter
$brands = [];
$result = $connection->query("SELECT DISTINCT brand FROM tblClothes WHERE brand IS NOT NULL AND brand != '' ORDER BY brand");
while ($row = $result->fetch_assoc()) {
    $brands[] = $row['brand'];
}

// Get categories with counts
$categories = ['tops' => 0, 'bottoms' => 0, 'dresses' => 0, 'outerwear' => 0, 'accessories' => 0, 'footwear' => 0];
foreach (array_keys($categories) as $cat) {
    $result = $connection->query("SELECT COUNT(*) as cnt FROM tblClothes WHERE category = '$cat' AND status = 'available'");
    $categories[$cat] = $result->fetch_assoc()['cnt'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop Catalog - Pastimes Online Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="../index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <nav>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="catalog.php" class="active">Shop</a></li>
                </ul>
            </nav>
            <div class="user-nav">
                <?php if ($isLoggedIn): ?>
                    <a href="cart.php" class="btn btn-primary btn-sm">Cart</a>
                    <a href="messages.php" class="btn btn-outline btn-sm">Messages</a>
                    <a href="../logout.php" class="btn btn-secondary btn-sm">Logout</a>
                <?php else: ?>
                    <a href="../login.php" class="btn btn-primary btn-sm">Login</a>
                    <a href="../register.php" class="btn btn-outline btn-sm">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="dashboard-header">
                <h1>Shop Catalog</h1>
                <p><?php echo count($items); ?> items found</p>
            </div>
            
            <div class="flex gap-3" style="align-items: flex-start;">
                <!-- Filters Sidebar -->
                <aside style="width: 250px; flex-shrink: 0;">
                    <div class="card">
                        <div class="card-body">
                            <h3>Filters</h3>
                            <form method="GET">
                                <div class="form-group">
                                    <label>Search</label>
                                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search items...">
                                </div>
                                
                                <div class="form-group">
                                    <label>Category</label>
                                    <select name="category">
                                        <option value="">All Categories</option>
                                        <?php foreach ($categories as $cat => $count): ?>
                                            <option value="<?php echo $cat; ?>" <?php echo $category === $cat ? 'selected' : ''; ?>>
                                                <?php echo ucfirst($cat); ?> (<?php echo $count; ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label>Brand</label>
                                    <select name="brand">
                                        <option value="">All Brands</option>
                                        <?php foreach ($brands as $b): ?>
                                            <option value="<?php echo htmlspecialchars($b); ?>" <?php echo $brand === $b ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($b); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label>Price Range</label>
                                    <div class="flex gap-1">
                                        <input type="number" name="minPrice" value="<?php echo $minPrice ?: ''; ?>" placeholder="Min" style="width: 50%;">
                                        <input type="number" name="maxPrice" value="<?php echo $maxPrice < 999999 ? $maxPrice : ''; ?>" placeholder="Max" style="width: 50%;">
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Size</label>
                                    <select name="size">
                                        <option value="">All Sizes</option>
                                        <option value="XS" <?php echo $size === 'XS' ? 'selected' : ''; ?>>XS</option>
                                        <option value="S" <?php echo $size === 'S' ? 'selected' : ''; ?>>S</option>
                                        <option value="M" <?php echo $size === 'M' ? 'selected' : ''; ?>>M</option>
                                        <option value="L" <?php echo $size === 'L' ? 'selected' : ''; ?>>L</option>
                                        <option value="XL" <?php echo $size === 'XL' ? 'selected' : ''; ?>>XL</option>
                                        <option value="XXL" <?php echo $size === 'XXL' ? 'selected' : ''; ?>>XXL</option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label>Condition</label>
                                    <select name="condition">
                                        <option value="">All Conditions</option>
                                        <option value="new" <?php echo $condition === 'new' ? 'selected' : ''; ?>>New</option>
                                        <option value="like_new" <?php echo $condition === 'like_new' ? 'selected' : ''; ?>>Like New</option>
                                        <option value="good" <?php echo $condition === 'good' ? 'selected' : ''; ?>>Good</option>
                                        <option value="fair" <?php echo $condition === 'fair' ? 'selected' : ''; ?>>Fair</option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label>Sort By</label>
                                    <select name="sort">
                                        <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest First</option>
                                        <option value="oldest" <?php echo $sort === 'oldest' ? 'selected' : ''; ?>>Oldest First</option>
                                        <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                                        <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                                    </select>
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-block">Apply Filters</button>
                                <a href="catalog.php" class="btn btn-secondary btn-block mt-2">Clear Filters</a>
                            </form>
                        </div>
                    </div>
                </aside>
                
                <!-- Items Grid -->
                <div style="flex: 1;">
                    <?php if (count($items) > 0): ?>
                        <div class="grid grid-4">
                            <?php foreach ($items as $item): ?>
                                <div class="card">
                                    <img src="<?php echo htmlspecialchars($item['imageURL'] ?: '../images/placeholder.jpg'); ?>" 
                                         alt="<?php echo htmlspecialchars($item['title']); ?>" 
                                         class="card-image">
                                    <div class="card-body">
                                        <h4 class="card-title"><?php echo htmlspecialchars($item['title']); ?></h4>
                                        <p class="card-text"><?php echo htmlspecialchars($item['brand'] ?? 'Various'); ?></p>
                                        <p class="card-text">Size: <?php echo htmlspecialchars($item['size']); ?></p>
                                        <span class="status-badge status-<?php echo $item['condition_status']; ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $item['condition_status'])); ?>
                                        </span>
                                    </div>
                                    <div class="card-footer">
                                        <span class="price">$<?php echo number_format($item['price'], 2); ?></span>
                                        <a href="item.php?id=<?php echo $item['clothesID']; ?>" class="btn btn-primary btn-sm">View</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No items found matching your criteria. <a href="catalog.php">Clear filters</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>