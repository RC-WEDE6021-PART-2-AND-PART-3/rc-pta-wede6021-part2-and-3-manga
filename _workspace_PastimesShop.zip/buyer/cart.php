<?php
/**
 * buyer/cart.php - Shopping Cart Page
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

// Check login
if (!isset($_SESSION['userID'])) {
    header('Location: ../login.php');
    exit();
}

$userID = $_SESSION['userID'];
$userName = $_SESSION['name'];
$success = '';
$error = '';

// Handle remove from cart
if (isset($_GET['remove'])) {
    $itemID = intval($_GET['remove']);
    if ($connection->query("DELETE FROM tblCartItems WHERE userID = $userID AND clothesID = $itemID")) {
        $success = "Item removed from cart";
    }
}

// Handle update quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updateQuantity'])) {
    $itemID = intval($_POST['clothesID']);
    $quantity = intval($_POST['quantity']);
    if ($quantity > 0) {
        $connection->query("UPDATE tblCartItems SET quantity = $quantity WHERE userID = $userID AND clothesID = $itemID");
        $success = "Cart updated";
    }
}

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $shippingAddress = sanitizeInput($_POST['shippingAddress']);
    $paymentMethod = sanitizeInput($_POST['paymentMethod']);
    
    // Get all cart items
    $cartItems = $connection->query("SELECT ci.*, c.price, c.sellerID, c.title 
        FROM tblCartItems ci 
        JOIN tblClothes c ON ci.clothesID = c.clothesID 
        WHERE ci.userID = $userID AND c.status = 'available'");
    
    if ($cartItems->num_rows > 0) {
        $connection->begin_transaction();
        try {
            while ($item = $cartItems->fetch_assoc()) {
                // Create order for each item
                $totalAmount = $item['price'] * $item['quantity'];
                $sql = "INSERT INTO tblAorder (buyerID, sellerID, clothesID, totalAmount, paymentMethod, shippingAddress) 
                        VALUES ($userID, {$item['sellerID']}, {$item['clothesID']}, $totalAmount, '$paymentMethod', '$shippingAddress')";
                $connection->query($sql);
                
                // Mark item as reserved
                $connection->query("UPDATE tblClothes SET status = 'reserved' WHERE clothesID = {$item['clothesID']}");
            }
            
            // Clear cart
            $connection->query("DELETE FROM tblCartItems WHERE userID = $userID");
            
            $connection->commit();
            $success = "Checkout successful! Your orders have been placed.";
        } catch (Exception $e) {
            $connection->rollback();
            $error = "Checkout failed. Please try again.";
        }
    }
}

// Get cart items
$cartItems = [];
$totalAmount = 0;
$result = $connection->query("SELECT ci.*, c.title, c.brand, c.price, c.imageURL, c.size, c.condition_status, 
    u.name as sellerName 
    FROM tblCartItems ci 
    JOIN tblClothes c ON ci.clothesID = c.clothesID 
    JOIN tblUser u ON c.sellerID = u.userID 
    WHERE ci.userID = $userID AND c.status = 'available'");
while ($row = $result->fetch_assoc()) {
    $cartItems[] = $row;
    $totalAmount += $row['price'] * $row['quantity'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Pastimes Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="../index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <nav>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="catalog.php">Shop</a></li>
                </ul>
            </nav>
            <div class="user-nav">
                <a href="cart.php" class="btn btn-primary btn-sm">Cart (<?php echo count($cartItems); ?>)</a>
                <a href="messages.php" class="btn btn-outline btn-sm">Messages</a>
                <a href="../logout.php" class="btn btn-secondary btn-sm">Logout</a>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <h1>Shopping Cart</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (count($cartItems) > 0): ?>
                <div class="cart-container">
                    <div class="cart-items">
                        <?php foreach ($cartItems as $item): ?>
                            <div class="cart-item">
                                <img src="<?php echo htmlspecialchars($item['imageURL'] ?: '../images/placeholder.jpg'); ?>" 
                                     alt="<?php echo htmlspecialchars($item['title']); ?>" 
                                     class="cart-item-image">
                                <div class="cart-item-details">
                                    <h4><a href="item.php?id=<?php echo $item['clothesID']; ?>"><?php echo htmlspecialchars($item['title']); ?></a></h4>
                                    <p>Brand: <?php echo htmlspecialchars($item['brand'] ?? 'N/A'); ?></p>
                                    <p>Size: <?php echo htmlspecialchars($item['size']); ?> | <?php echo ucfirst($item['condition_status']); ?></p>
                                    <p>Seller: <?php echo htmlspecialchars($item['sellerName']); ?></p>
                                    <strong>$<?php echo number_format($item['price'], 2); ?></strong>
                                </div>
                                <div class="cart-item-actions">
                                    <form method="POST" style="display: flex; gap: 0.5rem; align-items: center;">
                                        <input type="hidden" name="clothesID" value="<?php echo $item['clothesID']; ?>">
                                        <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" style="width: 60px;">
                                        <button type="submit" name="updateQuantity" class="btn btn-sm btn-secondary">Update</button>
                                    </form>
                                    <a href="?remove=<?php echo $item['clothesID']; ?>" 
                                       class="btn btn-danger btn-sm" 
                                       onclick="return confirm('Remove this item?')">Remove</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="cart-summary">
                        <h3>Order Summary</h3>
                        <div style="border-bottom: 1px solid #ddd; padding: 1rem 0;">
                            <p>Subtotal: $<?php echo number_format($totalAmount, 2); ?></p>
                            <p>Shipping: FREE</p>
                        </div>
                        <div style="padding: 1rem 0;">
                            <strong style="font-size: 1.25rem;">Total: $<?php echo number_format($totalAmount, 2); ?></strong>
                        </div>
                        
                        <form method="POST">
                            <div class="form-group">
                                <label>Shipping Address *</label>
                                <textarea name="shippingAddress" required placeholder="Enter your full shipping address"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Payment Method *</label>
                                <select name="paymentMethod" required>
                                    <option value="credit_card">Credit Card</option>
                                    <option value="debit_card">Debit Card</option>
                                    <option value="paypal">PayPal</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                </select>
                            </div>
                            <button type="submit" name="checkout" class="btn btn-success btn-block btn-lg">
                                Proceed to Checkout
                            </button>
                        </form>
                        
                        <a href="catalog.php" class="btn btn-outline btn-block mt-2">Continue Shopping</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    Your cart is empty. <a href="catalog.php">Start shopping</a>!
                </div>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>