<?php
/**
 * buyer/messages.php - Messaging System for Buyers
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header('Location: ../login.php');
    exit();
}

$userID = $_SESSION['userID'];
$success = '';
$error = '';

// Handle send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sendMessage'])) {
    $receiverID = intval($_POST['receiverID']);
    $clothesID = intval($_POST['clothesID'] ?? 0);
    $subject = sanitizeInput($_POST['subject'] ?? '');
    $message = sanitizeInput($_POST['message']);
    
    if (!empty($message) && $receiverID > 0) {
        $sql = "INSERT INTO tblMessages (senderID, receiverID, clothesID, subject, message) 
                VALUES ($userID, $receiverID, " . ($clothesID > 0 ? $clothesID : 'NULL') . ", '$subject', '$message')";
        if ($connection->query($sql)) {
            $success = "Message sent!";
        }
    }
}

// Get conversations (unique users)
$conversations = [];
$result = $connection->query("SELECT DISTINCT 
    CASE WHEN senderID = $userID THEN receiverID ELSE senderID END as otherUserID,
    u.name, u.email, u.userType,
    (SELECT message FROM tblMessages m2 WHERE 
        (m2.senderID = $userID AND m2.receiverID = u.userID) OR 
        (m2.senderID = u.userID AND m2.receiverID = $userID) 
     ORDER BY m2.sentDate DESC LIMIT 1) as lastMessage,
    (SELECT sentDate FROM tblMessages m2 WHERE 
        (m2.senderID = $userID AND m2.receiverID = u.userID) OR 
        (m2.senderID = u.userID AND m2.receiverID = $userID) 
     ORDER BY m2.sentDate DESC LIMIT 1) as lastDate
    FROM tblMessages m
    JOIN tblUser u ON (m.senderID = u.userID OR m.receiverID = u.userID)
    WHERE (m.senderID = $userID OR m.receiverID = $userID) AND u.userID != $userID
    ORDER BY lastDate DESC");
while ($row = $result->fetch_assoc()) {
    $conversations[] = $row;
}

// Get selected conversation
$selectedUser = intval($_GET['user'] ?? 0);
$messages = [];
$chatPartner = null;

if ($selectedUser > 0) {
    // Get chat partner info
    $result = $connection->query("SELECT * FROM tblUser WHERE userID = $selectedUser");
    if ($result->num_rows === 1) {
        $chatPartner = $result->fetch_assoc();
    }
    
    // Get messages
    $result = $connection->query("SELECT m.*, c.title as itemTitle 
        FROM tblMessages m 
        LEFT JOIN tblClothes c ON m.clothesID = c.clothesID
        WHERE (m.senderID = $userID AND m.receiverID = $selectedUser) 
           OR (m.senderID = $selectedUser AND m.receiverID = $userID) 
        ORDER BY m.sentDate ASC");
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    
    // Mark messages as read
    $connection->query("UPDATE tblMessages SET isRead = 1 WHERE senderID = $selectedUser AND receiverID = $userID");
}

// Get unread count
$unreadCount = $connection->query("SELECT COUNT(*) as cnt FROM tblMessages WHERE receiverID = $userID AND isRead = 0")->fetch_assoc()['cnt'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - Pastimes Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="../index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <div class="user-nav">
                <a href="cart.php" class="btn btn-primary btn-sm">Cart</a>
                <a href="messages.php" class="btn btn-outline btn-sm">Messages (<?php echo $unreadCount; ?>)</a>
                <a href="../logout.php" class="btn btn-secondary btn-sm">Logout</a>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <h1>Messages</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="messages-container">
                <!-- Conversations List -->
                <div class="conversations-list">
                    <h3 style="padding: 1rem; border-bottom: 1px solid #ddd;">Conversations</h3>
                    
                    <?php if (count($conversations) > 0): ?>
                        <?php foreach ($conversations as $conv): ?>
                            <a href="?user=<?php echo $conv['otherUserID']; ?>" 
                               class="conversation-item <?php echo $selectedUser == $conv['otherUserID'] ? 'active' : ''; ?>">
                                <strong><?php echo htmlspecialchars($conv['name']); ?></strong>
                                <p style="font-size: 0.85rem; color: var(--text-light); margin: 0.25rem 0;">
                                    <?php echo htmlspecialchars(substr($conv['lastMessage'], 0, 50)); ?>...
                                </p>
                                <small style="color: var(--text-light);">
                                    <?php echo date('M j', strtotime($conv['lastDate'])); ?>
                                </small>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="padding: 1rem; color: var(--text-light);">No conversations yet</p>
                    <?php endif; ?>
                </div>
                
                <!-- Chat Area -->
                <div class="chat-area">
                    <?php if ($chatPartner): ?>
                        <div class="chat-header">
                            <h3><?php echo htmlspecialchars($chatPartner['name']); ?></h3>
                            <small><?php echo ucfirst($chatPartner['userType']); ?></small>
                        </div>
                        
                        <div class="chat-messages">
                            <?php foreach ($messages as $msg): ?>
                                <div class="message <?php echo $msg['senderID'] == $userID ? 'sent' : 'received'; ?>">
                                    <div class="message-content">
                                        <?php if ($msg['itemTitle']): ?>
                                            <small style="opacity: 0.7;">Re: <?php echo htmlspecialchars($msg['itemTitle']); ?></small><br>
                                        <?php endif; ?>
                                        <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                    </div>
                                    <div class="message-time">
                                        <?php echo date('M j, Y H:i', strtotime($msg['sentDate'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <form method="POST" class="chat-input">
                            <input type="hidden" name="receiverID" value="<?php echo $chatPartner['userID']; ?>">
                            <input type="text" name="subject" placeholder="Subject (optional)" style="margin-bottom: 0.5rem;">
                            <input type="text" name="message" placeholder="Type your message..." required>
                            <button type="submit" name="sendMessage" class="btn btn-primary">Send</button>
                        </form>
                    <?php else: ?>
                        <div class="flex-center" style="height: 100%;">
                            <div class="text-center">
                                <h3>Select a conversation</h3>
                                <p style="color: var(--text-light);">Choose a conversation from the list to start messaging</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>