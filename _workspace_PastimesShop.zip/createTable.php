<?php
/**
 * createTable.php - Recreate tblUser and Load Data from userData.txt
 * Pastimes Online Shop
 * 
 * This script:
 * 1. Includes DBConn.php
 * 2. Checks if tblUser exists, drops it if it does
 * 3. Recreates the tblUser table
 * 4. Loads data from userData.txt into the table
 */

require_once 'includes/DBConn.php';

$results = array();

/**
 * Execute SQL query and track results
 */
function executeQuery($sql, $description) {
    global $connection, $results;
    if ($connection->query($sql) === TRUE) {
        $results[] = array('success' => true, 'message' => $description . " - SUCCESS");
        return true;
    } else {
        $results[] = array('success' => false, 'message' => $description . " - ERROR: " . $connection->error);
        return false;
    }
}

// Step 1: Check if tblUser exists and drop it
$checkTable = $connection->query("SHOW TABLES LIKE 'tblUser'");
if ($checkTable->num_rows > 0) {
    executeQuery("DROP TABLE tblUser", "Dropping existing tblUser table");
}

// Step 2: Recreate tblUser table
$sqlUser = "CREATE TABLE tblUser (
    userID INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('pending', 'verified', 'suspended') DEFAULT 'pending',
    userType ENUM('buyer', 'seller', 'admin') DEFAULT 'buyer',
    registrationDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    lastLogin DATETIME NULL,
    phone VARCHAR(20) NULL,
    address TEXT NULL,
    city VARCHAR(50) NULL,
    postalCode VARCHAR(10) NULL,
    PRIMARY KEY (userID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlUser, "Creating tblUser table");

// Step 3: Load data from userData.txt
$filePath = 'userData.txt';
$loadedCount = 0;
$errorCount = 0;

if (file_exists($filePath)) {
    $file = fopen($filePath, 'r');
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $line = trim($line);
            if (!empty($line)) {
                $parts = explode(',', $line);
                if (count($parts) >= 4) {
                    $name = sanitizeInput($parts[0]);
                    $email = sanitizeInput($parts[1]);
                    $username = sanitizeInput($parts[2]);
                    $password = sanitizeInput($parts[3]); // Already hashed in file
                    
                    $sqlInsert = "INSERT INTO tblUser (name, email, username, password, status, userType) 
                                  VALUES ('$name', '$email', '$username', '$password', 'pending', 'buyer')";
                    
                    if ($connection->query($sqlInsert)) {
                        $loadedCount++;
                    } else {
                        $errorCount++;
                        $results[] = array('success' => false, 'message' => "Error loading user: $name - " . $connection->error);
                    }
                }
            }
        }
        fclose($file);
        $results[] = array('success' => true, 'message' => "Loaded $loadedCount users from userData.txt");
        if ($errorCount > 0) {
            $results[] = array('success' => false, 'message' => "Failed to load $errorCount users");
        }
    } else {
        $results[] = array('success' => false, 'message' => "Could not open userData.txt file");
    }
} else {
    $results[] = array('success' => false, 'message' => "userData.txt file not found at: $filePath");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Table & Load Data - Pastimes Online Shop</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="setup-container">
        <h1>Pastimes Online Shop - Table Creation</h1>
        <h2>tblUser Recreation & Data Loading</h2>
        
        <div class="results-container">
            <?php foreach ($results as $result): ?>
                <div class="result-item <?php echo $result['success'] ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($result['message']); ?>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if ($loadedCount > 0): ?>
        <div class="loaded-users">
            <h3>Loaded Users:</h3>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $users = $connection->query("SELECT userID, name, email, username, status FROM tblUser ORDER BY userID");
                    while ($user = $users->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo $user['userID']; ?></td>
                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><span class="status-badge status-<?php echo $user['status']; ?>"><?php echo $user['status']; ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        
        <div class="actions">
            <a href="index.php" class="btn btn-primary">Go to Homepage</a>
            <a href="loadClothingStore.php" class="btn btn-secondary">Recreate All Tables</a>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>