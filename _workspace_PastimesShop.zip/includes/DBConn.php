<?php
/**
 * DBConn.php - Database Connection File
 * Pastimes Online Shop - ClothingStore Database
 * 
 * This file establishes the connection to the ClothingStore MySQL database
 * using MySQLi (Improved MySQLi) extension.
 */

// Database configuration
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'ClothingStore');

// Create database connection
$connection = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($connection->connect_error) {
    // If database doesn't exist, try to create it
    if ($connection->connect_error === "Unknown database '" . DB_NAME . "'") {
        $tempConn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD);
        $tempConn->query("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
        $tempConn->close();
        $connection = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    }
    
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }
}

// Set charset to utf8mb4 for proper character handling
$connection->set_charset("utf8mb4");

/**
 * Helper function to sanitize user input
 * @param string $data - The data to sanitize
 * @return string - Sanitized data
 */
function sanitizeInput($data) {
    global $connection;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $connection->real_escape_string($data);
}

/**
 * Helper function to hash password using MD5 (as per requirements)
 * Note: In production, use password_hash() instead
 * @param string $password - Plain text password
 * @return string - Hashed password
 */
function hashPassword($password) {
    return md5($password);
}

/**
 * Helper function to generate SHA hash
 * @param string $password - Plain text password
 * @return string - SHA256 hashed password
 */
function hashPasswordSHA($password) {
    return hash('sha256', $password);
}
?>