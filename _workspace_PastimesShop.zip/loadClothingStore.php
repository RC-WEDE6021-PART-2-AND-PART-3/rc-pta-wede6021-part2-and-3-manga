<?php
/**
 * loadClothingStore.php - Database Tables Creation Script
 * Pastimes Online Shop
 * 
 * This script creates all necessary tables within the ClothingStore database.
 * All tables are dropped before creation to allow for a clean state each time it runs.
 */

require_once 'includes/DBConn.php';

// Array to track execution results
$results = array();

/**
 * Execute SQL query and track results
 * @param string $sql - SQL query to execute
 * @param string $description - Description of the operation
 * @return bool - Success status
 */
function executeQuery($sql, $description) {
    global $connection, $results;
    if ($connection->query($sql) === TRUE) {
        $results[] = array('success' => true, 'message' => $description . " - SUCCESS");
        return true;
    } else {
        $results[] = array('success' => false, 'message' => $description . " - ERROR: " . $connection->error);
        return false;
    }
}

// Drop all tables if they exist (in reverse order of foreign key dependencies)
executeQuery("DROP TABLE IF EXISTS tblMessages", "Dropping tblMessages");
executeQuery("DROP TABLE IF EXISTS tblCartItems", "Dropping tblCartItems");
executeQuery("DROP TABLE IF EXISTS tblAorder", "Dropping tblAorder");
executeQuery("DROP TABLE IF EXISTS tblClothes", "Dropping tblClothes");
executeQuery("DROP TABLE IF EXISTS tblSellerRequest", "Dropping tblSellerRequest");
executeQuery("DROP TABLE IF EXISTS tblAdmin", "Dropping tblAdmin");
executeQuery("DROP TABLE IF EXISTS tblUser", "Dropping tblUser");

// Create tblUser - User accounts table
$sqlUser = "CREATE TABLE tblUser (
    userID INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('pending', 'verified', 'suspended') DEFAULT 'pending',
    userType ENUM('buyer', 'seller', 'admin') DEFAULT 'buyer',
    registrationDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    lastLogin DATETIME NULL,
    phone VARCHAR(20) NULL,
    address TEXT NULL,
    city VARCHAR(50) NULL,
    postalCode VARCHAR(10) NULL,
    PRIMARY KEY (userID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlUser, "Creating tblUser");

// Create tblAdmin - Administrator accounts
$sqlAdmin = "CREATE TABLE tblAdmin (
    adminID INT(11) NOT NULL AUTO_INCREMENT,
    userID INT(11) NOT NULL,
    adminLevel ENUM('super', 'regular') DEFAULT 'regular',
    createdDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (adminID),
    FOREIGN KEY (userID) REFERENCES tblUser(userID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlAdmin, "Creating tblAdmin");

// Create tblSellerRequest - Seller verification requests
$sqlSellerRequest = "CREATE TABLE tblSellerRequest (
    requestID INT(11) NOT NULL AUTO_INCREMENT,
    userID INT(11) NOT NULL,
    requestDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    description TEXT NULL,
    reviewedBy INT(11) NULL,
    reviewedDate DATETIME NULL,
    PRIMARY KEY (requestID),
    FOREIGN KEY (userID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (reviewedBy) REFERENCES tblAdmin(adminID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlSellerRequest, "Creating tblSellerRequest");

// Create tblClothes - Clothing items table
$sqlClothes = "CREATE TABLE tblClothes (
    clothesID INT(11) NOT NULL AUTO_INCREMENT,
    sellerID INT(11) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    brand VARCHAR(100) NULL,
    category ENUM('tops', 'bottoms', 'dresses', 'outerwear', 'accessories', 'footwear', 'other') DEFAULT 'other',
    size VARCHAR(20) NULL,
    color VARCHAR(50) NULL,
    condition_status ENUM('new', 'like_new', 'good', 'fair') DEFAULT 'good',
    price DECIMAL(10, 2) NOT NULL,
    imageURL VARCHAR(500) NULL,
    status ENUM('available', 'sold', 'reserved', 'removed') DEFAULT 'available',
    uploadDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    soldDate DATETIME NULL,
    buyerID INT(11) NULL,
    PRIMARY KEY (clothesID),
    FOREIGN KEY (sellerID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (buyerID) REFERENCES tblUser(userID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlClothes, "Creating tblClothes");

// Create tblAorder - Order/Transaction table
$sqlAorder = "CREATE TABLE tblAorder (
    orderID INT(11) NOT NULL AUTO_INCREMENT,
    buyerID INT(11) NOT NULL,
    sellerID INT(11) NOT NULL,
    clothesID INT(11) NOT NULL,
    orderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    totalAmount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'confirmed', 'shipped', 'delivered', 'cancelled', 'refunded') DEFAULT 'pending',
    paymentMethod ENUM('credit_card', 'debit_card', 'paypal', 'bank_transfer', 'cash') DEFAULT 'credit_card',
    paymentStatus ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    shippingAddress TEXT NULL,
    trackingNumber VARCHAR(100) NULL,
    deliveryDate DATETIME NULL,
    notes TEXT NULL,
    PRIMARY KEY (orderID),
    FOREIGN KEY (buyerID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (sellerID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlAorder, "Creating tblAorder");

// Create tblCartItems - Shopping cart items
$sqlCartItems = "CREATE TABLE tblCartItems (
    cartItemID INT(11) NOT NULL AUTO_INCREMENT,
    userID INT(11) NOT NULL,
    clothesID INT(11) NOT NULL,
    quantity INT(11) DEFAULT 1,
    dateAdded DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (cartItemID),
    FOREIGN KEY (userID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (userID, clothesID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlCartItems, "Creating tblCartItems");

// Create tblMessages - Messaging system for buyer-seller communication
$sqlMessages = "CREATE TABLE tblMessages (
    messageID INT(11) NOT NULL AUTO_INCREMENT,
    senderID INT(11) NOT NULL,
    receiverID INT(11) NOT NULL,
    clothesID INT(11) NULL,
    subject VARCHAR(200) NULL,
    message TEXT NOT NULL,
    sentDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    isRead TINYINT(1) DEFAULT 0,
    PRIMARY KEY (messageID),
    FOREIGN KEY (senderID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (receiverID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
executeQuery($sqlMessages, "Creating tblMessages");

// Insert default admin user (password: admin123 -> MD5 hash)
$adminPassword = md5('admin123');
$sqlDefaultAdmin = "INSERT INTO tblUser (name, email, username, password, status, userType) 
                     VALUES ('System Admin', 'admin@pastimes.com', 'admin', '$adminPassword', 'verified', 'admin')";
executeQuery($sqlDefaultAdmin, "Inserting default admin user");

// Get the admin's userID and create admin record
$adminID = $connection->insert_id;
$sqlAdminRecord = "INSERT INTO tblAdmin (userID, adminLevel) VALUES ($adminID, 'super')";
executeQuery($sqlAdminRecord, "Creating super admin record");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup - Pastimes Online Shop</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="setup-container">
        <h1>Pastimes Online Shop - Database Setup</h1>
        <h2>ClothingStore Database Tables Creation</h2>
        
        <div class="results-container">
            <?php foreach ($results as $result): ?>
                <div class="result-item <?php echo $result['success'] ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($result['message']); ?>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="setup-info">
            <h3>Tables Created:</h3>
            <ul>
                <li><strong>tblUser</strong> - User accounts (buyers, sellers, admins)</li>
                <li><strong>tblAdmin</strong> - Administrator details</li>
                <li><strong>tblSellerRequest</strong> - Seller verification requests</li>
                <li><strong>tblClothes</strong> - Clothing items for sale</li>
                <li><strong>tblAorder</strong> - Orders and transactions</li>
                <li><strong>tblCartItems</strong> - Shopping cart items</li>
                <li><strong>tblMessages</strong> - Buyer-seller messaging</li>
            </ul>
            
            <h3>Default Admin Account:</h3>
            <p><strong>Username:</strong> admin</p>
            <p><strong>Password:</strong> admin123</p>
            <p><strong>Email:</strong> admin@pastimes.com</p>
        </div>
        
        <div class="actions">
            <a href="index.php" class="btn btn-primary">Go to Homepage</a>
            <a href="createTable.php" class="btn btn-secondary">Load User Data</a>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>