# Pastimes Online Shop - Database Documentation

## Project Overview
Pastimes Online Shop is a web application for buying and selling branded, high-quality second-hand clothing. The application facilitates online trading with user registration, seller verification, shopping cart, messaging, and administrative functions.

## Database Structure

### Database Name
**ClothingStore**

---

## Table Structures

### 1. tblUser
User accounts including buyers, sellers, and administrators.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| userID | INT(11) | PRIMARY KEY, AUTO_INCREMENT | Unique user identifier |
| name | VARCHAR(100) | NOT NULL | User's full name |
| email | VARCHAR(100) | NOT NULL, UNIQUE | Email address |
| username | VARCHAR(50) | NOT NULL, UNIQUE | Username for login |
| password | VARCHAR(255) | NOT NULL | MD5/SHA hashed password |
| status | ENUM | DEFAULT 'pending' | Account status: pending, verified, suspended |
| userType | ENUM | DEFAULT 'buyer' | User type: buyer, seller, admin |
| registrationDate | DATETIME | DEFAULT CURRENT_TIMESTAMP | Account creation date |
| lastLogin | DATETIME | NULL | Last login timestamp |
| phone | VARCHAR(20) | NULL | Phone number |
| address | TEXT | NULL | Street address |
| city | VARCHAR(50) | NULL | City |
| postalCode | VARCHAR(10) | NULL | Postal/ZIP code |

**Primary Key:** userID

---

### 2. tblAdmin
Administrator account details.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| adminID | INT(11) | PRIMARY KEY, AUTO_INCREMENT | Admin record ID |
| userID | INT(11) | FOREIGN KEY, NOT NULL | Reference to tblUser |
| adminLevel | ENUM | DEFAULT 'regular' | Admin level: super, regular |
| createdDate | DATETIME | DEFAULT CURRENT_TIMESTAMP | Admin account creation date |

**Primary Key:** adminID
**Foreign Key:** userID → tblUser(userID)

---

### 3. tblSellerRequest
Seller verification requests.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| requestID | INT(11) | PRIMARY KEY, AUTO_INCREMENT | Request ID |
| userID | INT(11) | FOREIGN KEY, NOT NULL | User requesting seller status |
| requestDate | DATETIME | DEFAULT CURRENT_TIMESTAMP | Request submission date |
| status | ENUM | DEFAULT 'pending' | Request status: pending, approved, rejected |
| description | TEXT | NULL | User's description/reason for request |
| reviewedBy | INT(11) | FOREIGN KEY, NULL | Admin who reviewed the request |
| reviewedDate | DATETIME | NULL | Date request was reviewed |

**Primary Key:** requestID
**Foreign Keys:** 
- userID → tblUser(userID)
- reviewedBy → tblAdmin(adminID)

---

### 4. tblClothes
Clothing items for sale.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| clothesID | INT(11) | PRIMARY KEY, AUTO_INCREMENT | Item ID |
| sellerID | INT(11) | FOREIGN KEY, NOT NULL | Seller who listed the item |
| title | VARCHAR(200) | NOT NULL | Item title |
| description | TEXT | NULL | Item description |
| brand | VARCHAR(100) | NULL | Brand name |
| category | ENUM | DEFAULT 'other' | Category: tops, bottoms, dresses, outerwear, accessories, footwear, other |
| size | VARCHAR(20) | NULL | Size (XS, S, M, L, XL, XXL, etc.) |
| color | VARCHAR(50) | NULL | Color |
| condition_status | ENUM | DEFAULT 'good' | Condition: new, like_new, good, fair |
| price | DECIMAL(10,2) | NOT NULL | Price in USD |
| imageURL | VARCHAR(500) | NULL | URL to item image |
| status | ENUM | DEFAULT 'available' | Status: available, sold, reserved, removed |
| uploadDate | DATETIME | DEFAULT CURRENT_TIMESTAMP | Date item was listed |
| soldDate | DATETIME | NULL | Date item was sold |
| buyerID | INT(11) | FOREIGN KEY, NULL | User who purchased the item |

**Primary Key:** clothesID
**Foreign Keys:**
- sellerID → tblUser(userID)
- buyerID → tblUser(userID)

---

### 5. tblAorder
Orders and transactions.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| orderID | INT(11) | PRIMARY KEY, AUTO_INCREMENT | Order ID |
| buyerID | INT(11) | FOREIGN KEY, NOT NULL | Buyer who placed the order |
| sellerID | INT(11) | FOREIGN KEY, NOT NULL | Seller of the item |
| clothesID | INT(11) | FOREIGN KEY, NOT NULL | Item purchased |
| orderDate | DATETIME | DEFAULT CURRENT_TIMESTAMP | Order date |
| totalAmount | DECIMAL(10,2) | NOT NULL | Total order amount |
| status | ENUM | DEFAULT 'pending' | Order status: pending, confirmed, shipped, delivered, cancelled, refunded |
| paymentMethod | ENUM | DEFAULT 'credit_card' | Payment method |
| paymentStatus | ENUM | DEFAULT 'pending' | Payment status: pending, paid, failed, refunded |
| shippingAddress | TEXT | NULL | Shipping address |
| trackingNumber | VARCHAR(100) | NULL | Shipping tracking number |
| deliveryDate | DATETIME | NULL | Delivery date |
| notes | TEXT | NULL | Order notes |

**Primary Key:** orderID
**Foreign Keys:**
- buyerID → tblUser(userID)
- sellerID → tblUser(userID)
- clothesID → tblClothes(clothesID)

---

### 6. tblCartItems
Shopping cart items.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| cartItemID | INT(11) | PRIMARY KEY, AUTO_INCREMENT | Cart item ID |
| userID | INT(11) | FOREIGN KEY, NOT NULL | User who owns the cart |
| clothesID | INT(11) | FOREIGN KEY, NOT NULL | Item in cart |
| quantity | INT(11) | DEFAULT 1 | Quantity |
| dateAdded | DATETIME | DEFAULT CURRENT_TIMESTAMP | Date item added to cart |

**Primary Key:** cartItemID
**Foreign Keys:**
- userID → tblUser(userID)
- clothesID → tblClothes(clothesID)
**Unique Constraint:** (userID, clothesID)

---

### 7. tblMessages
Buyer-seller messaging system.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| messageID | INT(11) | PRIMARY KEY, AUTO_INCREMENT | Message ID |
| senderID | INT(11) | FOREIGN KEY, NOT NULL | User who sent the message |
| receiverID | INT(11) | FOREIGN KEY, NOT NULL | User who receives the message |
| clothesID | INT(11) | FOREIGN KEY, NULL | Related item (optional) |
| subject | VARCHAR(200) | NULL | Message subject |
| message | TEXT | NOT NULL | Message content |
| sentDate | DATETIME | DEFAULT CURRENT_TIMESTAMP | Send timestamp |
| isRead | TINYINT(1) | DEFAULT 0 | Read status (0=unread, 1=read) |

**Primary Key:** messageID
**Foreign Keys:**
- senderID → tblUser(userID)
- receiverID → tblUser(userID)
- clothesID → tblClothes(clothesID)

---

## Entity Relationship Diagram (ERD)

```
┌─────────────┐       ┌─────────────┐       ┌─────────────────┐
│   tblUser   │       │  tblAdmin   │       │tblSellerRequest │
├─────────────┤       ├─────────────┤       ├─────────────────┤
│ userID (PK) │◄──────│ userID (FK) │       │ requestID (PK)  │
│ name        │       │ adminID(PK) │       │ userID (FK)     │
│ email       │       │ adminLevel  │       │ status          │
│ username    │       └─────────────┘       │ reviewedBy(FK)  │
│ password    │                             └─────────────────┘
│ status      │                             │
│ userType    │                             │
└─────────────┘                             │
      │                                     │
      │ 1:N                                 │
      ▼                                     │
┌─────────────┐       ┌─────────────┐       │
│ tblClothes  │       │  tblAorder  │       │
├─────────────┤       ├─────────────┤       │
│clothesID(PK)│◄──────│ orderID(PK) │       │
│ sellerID(FK)│       │ buyerID(FK) │───────┼───► tblUser
│ title       │       │ sellerID(FK)│───────┼───► tblUser
│ brand       │       │ clothesID(FK)│      │
│ price       │       │ status      │       │
│ status      │       └─────────────┘       │
└─────────────┘                             │
      │                                     │
      │ 1:N                                 │
      ▼                                     │
┌─────────────┐                             │
│tblCartItems │                             │
├─────────────┤                             │
│cartItemID(PK)│                            │
│ userID (FK) │──────► tblUser              │
│clothesID(FK)│                             │
└─────────────┘                             │
                                            │
┌─────────────┐                             │
│ tblMessages │                             │
├─────────────┤                             │
│messageID(PK)│                             │
│ senderID(FK)│──────► tblUser              │
│receiverID(FK)│─────► tblUser              │
│clothesID(FK)│──────► tblClothes           │
└─────────────┘
```

---

## Sample Data Statistics

| Table | Records |
|-------|---------|
| tblUser | 30 |
| tblAdmin | 3 |
| tblSellerRequest | 30 |
| tblClothes | 35 |
| tblAorder | 35 |
| tblCartItems | 19 |
| tblMessages | 30 |

---

## File Structure

```
PastimesShop/
├── index.php                 # Homepage
├── login.php                 # User login
├── register.php              # User registration
├── logout.php                # Logout script
├── loadClothingStore.php     # Database setup script
├── createTable.php           # Table recreation script
├── userData.txt              # Sample user data
├── myClothingStore.sql       # Complete SQL script
├── documentation.md          # This documentation
├── README.md                 # Setup instructions
│
├── includes/
│   └── DBConn.php            # Database connection
│
├── css/
│   └── style.css             # Main stylesheet
│
├── admin/
│   ├── login.php             # Admin login
│   ├── dashboard.php         # Admin dashboard
│   ├── users.php             # User management
│   ├── verify-users.php      # User verification
│   ├── sellers.php           # Seller requests
│   ├── clothing.php          # Clothing management
│   └── orders.php            # Order management
│
├── buyer/
│   ├── catalog.php           # Shopping catalog
│   ├── item.php              # Item details
│   ├── cart.php              # Shopping cart
│   └── messages.php          # Messaging system
│
├── seller/
│   ├── dashboard.php         # Seller dashboard
│   ├── request-seller.php    # Seller request
│   ├── upload.php            # Upload items
│   ├── my-items.php          # Item management
│   ├── orders.php            # Order management
│   └── messages.php          # Messaging system
│
└── images/
    └── placeholder.jpg       # Placeholder image
```

---

## Security Features

1. **Password Hashing**: MD5 and SHA256 support
2. **SQL Injection Prevention**: mysqli_real_escape_string for all inputs
3. **Session Management**: Secure session handling with proper logout
4. **Access Control**: Role-based access for buyer, seller, and admin
5. **Form Validation**: HTML5 and server-side validation

---

## Credits

Developed for the Pastimes Online Shop project.