<?php
/**
 * admin/clothing.php - Clothing Management Page
 * Pastimes Online Shop
 * 
 * Admin can:
 * - View all clothing items
 * - Remove sold items from database
 * - Manage clothing listings
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$success = '';
$error = '';

// Handle clothing actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $clothesID = intval($_POST['clothesID'] ?? 0);
    
    switch ($action) {
        case 'remove':
            if ($connection->query("DELETE FROM tblClothes WHERE clothesID = $clothesID")) {
                $success = "Clothing item removed successfully";
            } else {
                $error = "Failed to remove item";
            }
            break;
        case 'markSold':
            if ($connection->query("UPDATE tblClothes SET status = 'sold', soldDate = NOW() WHERE clothesID = $clothesID")) {
                $success = "Item marked as sold";
            }
            break;
        case 'restore':
            if ($connection->query("UPDATE tblClothes SET status = 'available' WHERE clothesID = $clothesID")) {
                $success = "Item restored to available";
            }
            break;
    }
}

// Get all clothing items
$clothes = [];
$filter = sanitizeInput($_GET['filter'] ?? 'all');
$statusWhere = '';
if ($filter !== 'all') {
    $statusWhere = "WHERE c.status = '$filter'";
}

$result = $connection->query("SELECT c.*, u.name as sellerName, u.email as sellerEmail 
    FROM tblClothes c 
    JOIN tblUser u ON c.sellerID = u.userID 
    $statusWhere
    ORDER BY c.uploadDate DESC");
while ($row = $result->fetch_assoc()) {
    $clothes[] = $row;
}

// Get statistics
$stats = [
    'total' => 0,
    'available' => 0,
    'sold' => 0,
    'reserved' => 0
];
$result = $connection->query("SELECT status, COUNT(*) as cnt FROM tblClothes GROUP BY status");
while ($row = $result->fetch_assoc()) {
    $stats[$row['status']] = $row['cnt'];
    $stats['total'] += $row['cnt'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Clothing - Pastimes Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php">Manage Users</a></li>
                <li><a href="verify-users.php">Verify Users</a></li>
                <li><a href="sellers.php">Seller Requests</a></li>
                <li><a href="clothing.php" class="active">Manage Clothing</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <div class="dashboard-header">
                <h1>Clothing Management</h1>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['total']; ?></div>
                    <div class="stat-label">Total Items</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['available']; ?></div>
                    <div class="stat-label">Available</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['sold']; ?></div>
                    <div class="stat-label">Sold</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['reserved']; ?></div>
                    <div class="stat-label">Reserved</div>
                </div>
            </div>
            
            <!-- Filter -->
            <div class="mb-3">
                <a href="?filter=all" class="btn <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">All</a>
                <a href="?filter=available" class="btn <?php echo $filter === 'available' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Available</a>
                <a href="?filter=sold" class="btn <?php echo $filter === 'sold' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Sold</a>
                <a href="?filter=reserved" class="btn <?php echo $filter === 'reserved' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Reserved</a>
            </div>
            
            <!-- Clothing Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Brand</th>
                            <th>Price</th>
                            <th>Seller</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clothes as $item): ?>
                            <tr>
                                <td><?php echo $item['clothesID']; ?></td>
                                <td>
                                    <img src="<?php echo htmlspecialchars($item['imageURL'] ?: '../images/placeholder.jpg'); ?>" 
                                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                                </td>
                                <td><?php echo htmlspecialchars($item['title']); ?></td>
                                <td><?php echo htmlspecialchars($item['brand'] ?? '-'); ?></td>
                                <td>$<?php echo number_format($item['price'], 2); ?></td>
                                <td><?php echo htmlspecialchars($item['sellerName']); ?></td>
                                <td><span class="status-badge status-<?php echo $item['status']; ?>"><?php echo ucfirst($item['status']); ?></span></td>
                                <td>
                                    <?php if ($item['status'] === 'sold'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="clothesID" value="<?php echo $item['clothesID']; ?>">
                                            <input type="hidden" name="action" value="remove">
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Remove from database?')">Remove</button>
                                        </form>
                                    <?php elseif ($item['status'] === 'available'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="clothesID" value="<?php echo $item['clothesID']; ?>">
                                            <input type="hidden" name="action" value="markSold">
                                            <button type="submit" class="btn btn-warning btn-sm">Mark Sold</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="clothesID" value="<?php echo $item['clothesID']; ?>">
                                            <input type="hidden" name="action" value="restore">
                                            <button type="submit" class="btn btn-success btn-sm">Restore</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (count($clothes) === 0): ?>
                <div class="alert alert-info mt-3">No clothing items found</div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>