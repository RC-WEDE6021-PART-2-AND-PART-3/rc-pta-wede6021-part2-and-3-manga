<?php
/**
 * admin/sellers.php - Seller Requests Management
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$success = '';
$error = '';

// Handle seller request actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $requestID = intval($_POST['requestID'] ?? 0);
    $userID = intval($_POST['userID'] ?? 0);
    
    switch ($action) {
        case 'approve':
            $connection->begin_transaction();
            try {
                $connection->query("UPDATE tblUser SET userType = 'seller' WHERE userID = $userID");
                $connection->query("UPDATE tblSellerRequest SET status = 'approved', reviewedBy = {$_SESSION['userID']}, reviewedDate = NOW() WHERE requestID = $requestID");
                $connection->commit();
                $success = "Seller approved successfully";
            } catch (Exception $e) {
                $connection->rollback();
                $error = "Failed to approve seller";
            }
            break;
        case 'reject':
            if ($connection->query("UPDATE tblSellerRequest SET status = 'rejected', reviewedBy = {$_SESSION['userID']}, reviewedDate = NOW() WHERE requestID = $requestID")) {
                $success = "Seller request rejected";
            }
            break;
    }
}

// Get pending seller requests
$pendingRequests = [];
$result = $connection->query("SELECT sr.*, u.name, u.email, u.username 
    FROM tblSellerRequest sr 
    JOIN tblUser u ON sr.userID = u.userID 
    WHERE sr.status = 'pending' 
    ORDER BY sr.requestDate DESC");
while ($row = $result->fetch_assoc()) {
    $pendingRequests[] = $row;
}

// Get processed requests
$processedRequests = [];
$result = $connection->query("SELECT sr.*, u.name, u.email, u.username, a.userID as reviewerID
    FROM tblSellerRequest sr 
    JOIN tblUser u ON sr.userID = u.userID 
    LEFT JOIN tblAdmin a ON sr.reviewedBy = a.adminID
    WHERE sr.status != 'pending' 
    ORDER BY sr.reviewedDate DESC LIMIT 10");
while ($row = $result->fetch_assoc()) {
    $processedRequests[] = $row;
}

// Get all sellers
$sellers = [];
$result = $connection->query("SELECT u.*, COUNT(c.clothesID) as itemCount 
    FROM tblUser u 
    LEFT JOIN tblClothes c ON u.userID = c.sellerID 
    WHERE u.userType = 'seller' 
    GROUP BY u.userID");
while ($row = $result->fetch_assoc()) {
    $sellers[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Requests - Pastimes Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php">Manage Users</a></li>
                <li><a href="verify-users.php">Verify Users</a></li>
                <li><a href="sellers.php" class="active">Seller Requests</a></li>
                <li><a href="clothing.php">Manage Clothing</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <h1>Seller Requests Management</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <!-- Pending Seller Requests -->
            <section class="mt-3">
                <h2>Pending Seller Requests (<?php echo count($pendingRequests); ?>)</h2>
                
                <?php if (count($pendingRequests) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Email</th>
                                    <th>Description</th>
                                    <th>Requested</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendingRequests as $req): ?>
                                    <tr>
                                        <td><?php echo $req['requestID']; ?></td>
                                        <td><?php echo htmlspecialchars($req['name']); ?> (@<?php echo $req['username']; ?>)</td>
                                        <td><?php echo htmlspecialchars($req['email']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($req['description'] ?? 'No description', 0, 50)); ?>...</td>
                                        <td><?php echo date('M j, Y', strtotime($req['requestDate'])); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="requestID" value="<?php echo $req['requestID']; ?>">
                                                <input type="hidden" name="userID" value="<?php echo $req['userID']; ?>">
                                                <input type="hidden" name="action" value="approve">
                                                <button type="submit" class="btn btn-success btn-sm">Approve</button>
                                            </form>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="requestID" value="<?php echo $req['requestID']; ?>">
                                                <input type="hidden" name="action" value="reject">
                                                <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success">No pending seller requests</div>
                <?php endif; ?>
            </section>
            
            <!-- Active Sellers -->
            <section class="mt-4">
                <h2>Active Sellers</h2>
                
                <?php if (count($sellers) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Items Listed</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sellers as $seller): ?>
                                    <tr>
                                        <td><?php echo $seller['userID']; ?></td>
                                        <td><?php echo htmlspecialchars($seller['name']); ?></td>
                                        <td><?php echo htmlspecialchars($seller['email']); ?></td>
                                        <td><?php echo $seller['itemCount']; ?></td>
                                        <td><span class="status-badge status-<?php echo $seller['status']; ?>"><?php echo ucfirst($seller['status']); ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">No sellers yet</div>
                <?php endif; ?>
            </section>
            
            <!-- Processed Requests -->
            <section class="mt-4">
                <h2>Recent Processed Requests</h2>
                
                <?php if (count($processedRequests) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Status</th>
                                    <th>Processed Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($processedRequests as $req): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($req['name']); ?></td>
                                        <td><span class="status-badge status-<?php echo $req['status']; ?>"><?php echo ucfirst($req['status']); ?></span></td>
                                        <td><?php echo $req['reviewedDate'] ? date('M j, Y H:i', strtotime($req['reviewedDate'])) : '-'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">No processed requests yet</div>
                <?php endif; ?>
            </section>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>