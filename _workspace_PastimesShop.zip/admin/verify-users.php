<?php
/**
 * admin/verify-users.php - User Verification Page
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$success = '';

// Handle verification actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userID = intval($_POST['userID'] ?? 0);
    
    switch ($action) {
        case 'verify':
            if ($connection->query("UPDATE tblUser SET status = 'verified' WHERE userID = $userID")) {
                $success = "User verified successfully";
            }
            break;
        case 'suspend':
            if ($connection->query("UPDATE tblUser SET status = 'suspended' WHERE userID = $userID")) {
                $success = "User suspended successfully";
            }
            break;
        case 'delete':
            if ($connection->query("DELETE FROM tblUser WHERE userID = $userID")) {
                $success = "User deleted successfully";
            }
            break;
    }
}

// Get pending users
$pendingUsers = [];
$result = $connection->query("SELECT * FROM tblUser WHERE status = 'pending' ORDER BY registrationDate DESC");
while ($row = $result->fetch_assoc()) {
    $pendingUsers[] = $row;
}

// Get recently verified users
$verifiedUsers = [];
$result = $connection->query("SELECT * FROM tblUser WHERE status = 'verified' ORDER BY lastLogin DESC LIMIT 10");
while ($row = $result->fetch_assoc()) {
    $verifiedUsers[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Users - Pastimes Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php">Manage Users</a></li>
                <li><a href="verify-users.php" class="active">Verify Users</a></li>
                <li><a href="sellers.php">Seller Requests</a></li>
                <li><a href="clothing.php">Manage Clothing</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <h1>User Verification</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Pending Users -->
            <section class="mt-3">
                <h2>Pending Verification (<?php echo count($pendingUsers); ?>)</h2>
                
                <?php if (count($pendingUsers) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Username</th>
                                    <th>Registered</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendingUsers as $user): ?>
                                    <tr>
                                        <td><?php echo $user['userID']; ?></td>
                                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo date('M j, Y H:i', strtotime($user['registrationDate'])); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="userID" value="<?php echo $user['userID']; ?>">
                                                <input type="hidden" name="action" value="verify">
                                                <button type="submit" class="btn btn-success btn-sm">Verify</button>
                                            </form>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this user?')">
                                                <input type="hidden" name="userID" value="<?php echo $user['userID']; ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success">No pending users to verify!</div>
                <?php endif; ?>
            </section>
            
            <!-- Verified Users -->
            <section class="mt-4">
                <h2>Recently Verified Users</h2>
                
                <?php if (count($verifiedUsers) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Type</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($verifiedUsers as $user): ?>
                                    <tr>
                                        <td><?php echo $user['userID']; ?></td>
                                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo ucfirst($user['userType']); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="userID" value="<?php echo $user['userID']; ?>">
                                                <input type="hidden" name="action" value="suspend">
                                                <button type="submit" class="btn btn-warning btn-sm">Suspend</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">No verified users yet</div>
                <?php endif; ?>
            </section>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>