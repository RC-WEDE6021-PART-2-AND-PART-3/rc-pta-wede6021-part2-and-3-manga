<?php
/**
 * admin/dashboard.php - Administrator Dashboard
 * Pastimes Online Shop
 * 
 * Features:
 * - Verify new registrations
 * - Manage customer accounts (Add/Update/Delete)
 * - Load clothing details
 * - Remove sold items
 * - View statistics
 */

session_start();
require_once '../includes/DBConn.php';

// Check if user is logged in as admin
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$adminName = $_SESSION['name'];
$adminLevel = $_SESSION['adminLevel'] ?? 'regular';

// Get statistics
$stats = [
    'totalUsers' => 0,
    'pendingUsers' => 0,
    'verifiedUsers' => 0,
    'totalClothes' => 0,
    'availableClothes' => 0,
    'soldClothes' => 0,
    'totalOrders' => 0,
    'pendingOrders' => 0,
    'totalSellers' => 0,
    'pendingSellers' => 0
];

// Count users
$result = $connection->query("SELECT status, COUNT(*) as cnt FROM tblUser GROUP BY status");
while ($row = $result->fetch_assoc()) {
    if ($row['status'] === 'pending') $stats['pendingUsers'] = $row['cnt'];
    elseif ($row['status'] === 'verified') $stats['verifiedUsers'] = $row['cnt'];
}
$stats['totalUsers'] = $stats['pendingUsers'] + $stats['verifiedUsers'];

// Count clothes
$result = $connection->query("SELECT status, COUNT(*) as cnt FROM tblClothes GROUP BY status");
while ($row = $result->fetch_assoc()) {
    if ($row['status'] === 'available') $stats['availableClothes'] = $row['cnt'];
    elseif ($row['status'] === 'sold') $stats['soldClothes'] = $row['cnt'];
}
$stats['totalClothes'] = $stats['availableClothes'] + $stats['soldClothes'];

// Count orders
$result = $connection->query("SELECT COUNT(*) as cnt FROM tblAorder");
$stats['totalOrders'] = $result->fetch_assoc()['cnt'];

$result = $connection->query("SELECT COUNT(*) as cnt FROM tblAorder WHERE status = 'pending'");
$stats['pendingOrders'] = $result->fetch_assoc()['cnt'];

// Count sellers
$result = $connection->query("SELECT COUNT(*) as cnt FROM tblUser WHERE userType = 'seller'");
$stats['totalSellers'] = $result->fetch_assoc()['cnt'];

$result = $connection->query("SELECT COUNT(*) as cnt FROM tblSellerRequest WHERE status = 'pending'");
$stats['pendingSellers'] = $result->fetch_assoc()['cnt'];

// Get pending users for verification
$pendingUsers = [];
$result = $connection->query("SELECT * FROM tblUser WHERE status = 'pending' ORDER BY registrationDate DESC LIMIT 10");
while ($row = $result->fetch_assoc()) {
    $pendingUsers[] = $row;
}

// Get recent orders
$recentOrders = [];
$result = $connection->query("SELECT o.*, u.name as buyerName, c.title as itemTitle 
    FROM tblAorder o 
    JOIN tblUser u ON o.buyerID = u.userID 
    JOIN tblClothes c ON o.clothesID = c.clothesID 
    ORDER BY o.orderDate DESC LIMIT 5");
while ($row = $result->fetch_assoc()) {
    $recentOrders[] = $row;
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => ''];
    
    switch ($_POST['action']) {
        case 'verifyUser':
            $userID = intval($_POST['userID']);
            if ($connection->query("UPDATE tblUser SET status = 'verified' WHERE userID = $userID")) {
                $response = ['success' => true, 'message' => 'User verified successfully'];
            }
            break;
            
        case 'suspendUser':
            $userID = intval($_POST['userID']);
            if ($connection->query("UPDATE tblUser SET status = 'suspended' WHERE userID = $userID")) {
                $response = ['success' => true, 'message' => 'User suspended successfully'];
            }
            break;
            
        case 'deleteUser':
            $userID = intval($_POST['userID']);
            if ($connection->query("DELETE FROM tblUser WHERE userID = $userID")) {
                $response = ['success' => true, 'message' => 'User deleted successfully'];
            }
            break;
            
        case 'approveSeller':
            $requestID = intval($_POST['requestID']);
            $userID = intval($_POST['userID']);
            $connection->begin_transaction();
            try {
                $connection->query("UPDATE tblUser SET userType = 'seller' WHERE userID = $userID");
                $connection->query("UPDATE tblSellerRequest SET status = 'approved', reviewedBy = {$_SESSION['userID']}, reviewedDate = NOW() WHERE requestID = $requestID");
                $connection->commit();
                $response = ['success' => true, 'message' => 'Seller approved successfully'];
            } catch (Exception $e) {
                $connection->rollback();
                $response = ['success' => false, 'message' => 'Failed to approve seller'];
            }
            break;
            
        case 'rejectSeller':
            $requestID = intval($_POST['requestID']);
            if ($connection->query("UPDATE tblSellerRequest SET status = 'rejected', reviewedBy = {$_SESSION['userID']}, reviewedDate = NOW() WHERE requestID = $requestID")) {
                $response = ['success' => true, 'message' => 'Seller request rejected'];
            }
            break;
    }
    
    echo json_encode($response);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Pastimes Online Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul>
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="users.php">Manage Users</a></li>
                <li><a href="verify-users.php">Verify Users</a></li>
                <li><a href="sellers.php">Seller Requests</a></li>
                <li><a href="clothing.php">Manage Clothing</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <div class="dashboard-content">
            <div class="dashboard-header">
                <h1>Welcome, <?php echo htmlspecialchars($adminName); ?></h1>
                <span class="status-badge status-verified"><?php echo ucfirst($adminLevel); ?> Admin</span>
            </div>
            
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value"><?php echo $stats['totalUsers']; ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-value"><?php echo $stats['pendingUsers']; ?></div>
                    <div class="stat-label">Pending Verifications</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">👕</div>
                    <div class="stat-value"><?php echo $stats['totalClothes']; ?></div>
                    <div class="stat-label">Clothing Items</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🛒</div>
                    <div class="stat-value"><?php echo $stats['totalOrders']; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
            </div>
            
            <!-- Pending Users Section -->
            <section class="mt-4">
                <div class="dashboard-header">
                    <h2>Pending User Verifications</h2>
                    <a href="verify-users.php" class="btn btn-primary btn-sm">View All</a>
                </div>
                
                <?php if (count($pendingUsers) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Username</th>
                                    <th>Registered</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendingUsers as $user): ?>
                                    <tr>
                                        <td><?php echo $user['userID']; ?></td>
                                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($user['registrationDate'])); ?></td>
                                        <td>
                                            <button class="btn btn-success btn-sm" onclick="verifyUser(<?php echo $user['userID']; ?>)">Verify</button>
                                            <button class="btn btn-danger btn-sm" onclick="deleteUser(<?php echo $user['userID']; ?>)">Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success">No pending users to verify</div>
                <?php endif; ?>
            </section>
            
            <!-- Recent Orders Section -->
            <section class="mt-4">
                <div class="dashboard-header">
                    <h2>Recent Orders</h2>
                    <a href="orders.php" class="btn btn-primary btn-sm">View All</a>
                </div>
                
                <?php if (count($recentOrders) > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Buyer</th>
                                    <th>Item</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentOrders as $order): ?>
                                    <tr>
                                        <td>#<?php echo $order['orderID']; ?></td>
                                        <td><?php echo htmlspecialchars($order['buyerName']); ?></td>
                                        <td><?php echo htmlspecialchars($order['itemTitle']); ?></td>
                                        <td>$<?php echo number_format($order['totalAmount'], 2); ?></td>
                                        <td><span class="status-badge status-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                                        <td><?php echo date('M j, Y', strtotime($order['orderDate'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">No orders yet</div>
                <?php endif; ?>
            </section>
        </div>
    </div>
    
    <script>
        function verifyUser(userID) {
            if (confirm('Are you sure you want to verify this user?')) {
                fetch('dashboard.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=verifyUser&userID=' + userID
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.success) location.reload();
                });
            }
        }
        
        function deleteUser(userID) {
            if (confirm('Are you sure you want to delete this user? This cannot be undone.')) {
                fetch('dashboard.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=deleteUser&userID=' + userID
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.success) location.reload();
                });
            }
        }
    </script>
</body>
</html>
<?php $connection->close(); ?>