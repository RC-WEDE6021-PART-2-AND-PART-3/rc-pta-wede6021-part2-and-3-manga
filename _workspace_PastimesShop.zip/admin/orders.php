<?php
/**
 * admin/orders.php - Orders Management Page
 * Pastimes Online Shop
 */

session_start();
require_once '../includes/DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$success = '';
$error = '';

// Handle order status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $orderID = intval($_POST['orderID'] ?? 0);
    
    switch ($action) {
        case 'confirm':
            if ($connection->query("UPDATE tblAorder SET status = 'confirmed' WHERE orderID = $orderID")) {
                $success = "Order confirmed";
            }
            break;
        case 'ship':
            $trackingNumber = sanitizeInput($_POST['trackingNumber'] ?? '');
            if ($connection->query("UPDATE tblAorder SET status = 'shipped', trackingNumber = '$trackingNumber' WHERE orderID = $orderID")) {
                $success = "Order marked as shipped";
            }
            break;
        case 'deliver':
            if ($connection->query("UPDATE tblAorder SET status = 'delivered', deliveryDate = NOW() WHERE orderID = $orderID")) {
                $success = "Order marked as delivered";
                // Also update clothes status
                $clothesResult = $connection->query("SELECT clothesID FROM tblAorder WHERE orderID = $orderID");
                if ($clothesResult->num_rows === 1) {
                    $clothesID = $clothesResult->fetch_assoc()['clothesID'];
                    $connection->query("UPDATE tblClothes SET status = 'sold', soldDate = NOW() WHERE clothesID = $clothesID");
                }
            }
            break;
        case 'cancel':
            if ($connection->query("UPDATE tblAorder SET status = 'cancelled' WHERE orderID = $orderID")) {
                $success = "Order cancelled";
            }
            break;
    }
}

// Get orders
$orders = [];
$filter = sanitizeInput($_GET['filter'] ?? 'all');
$statusWhere = '';
if ($filter !== 'all') {
    $statusWhere = "WHERE o.status = '$filter'";
}

$result = $connection->query("SELECT o.*, 
    buyer.name as buyerName, buyer.email as buyerEmail,
    seller.name as sellerName, seller.email as sellerEmail,
    c.title as itemTitle, c.brand as itemBrand
    FROM tblAorder o 
    JOIN tblUser buyer ON o.buyerID = buyer.userID 
    JOIN tblUser seller ON o.sellerID = seller.userID 
    JOIN tblClothes c ON o.clothesID = c.clothesID 
    $statusWhere
    ORDER BY o.orderDate DESC");
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

// Get statistics
$stats = ['total' => 0, 'pending' => 0, 'confirmed' => 0, 'shipped' => 0, 'delivered' => 0];
$result = $connection->query("SELECT status, COUNT(*) as cnt FROM tblAorder GROUP BY status");
while ($row = $result->fetch_assoc()) {
    if (isset($stats[$row['status']])) {
        $stats[$row['status']] = $row['cnt'];
    }
    $stats['total'] += $row['cnt'];
}

// Calculate total revenue
$revenueResult = $connection->query("SELECT SUM(totalAmount) as total FROM tblAorder WHERE status = 'delivered'");
$totalRevenue = $revenueResult->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Pastimes Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php">Manage Users</a></li>
                <li><a href="verify-users.php">Verify Users</a></li>
                <li><a href="sellers.php">Seller Requests</a></li>
                <li><a href="clothing.php">Manage Clothing</a></li>
                <li><a href="orders.php" class="active">Orders</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <div class="dashboard-header">
                <h1>Orders Management</h1>
                <div>Total Revenue: <strong style="color: var(--success-color);">$<?php echo number_format($totalRevenue, 2); ?></strong></div>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['total']; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['pending']; ?></div>
                    <div class="stat-label">Pending</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['shipped']; ?></div>
                    <div class="stat-label">Shipped</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['delivered']; ?></div>
                    <div class="stat-label">Delivered</div>
                </div>
            </div>
            
            <!-- Filter -->
            <div class="mb-3">
                <a href="?filter=all" class="btn <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">All</a>
                <a href="?filter=pending" class="btn <?php echo $filter === 'pending' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Pending</a>
                <a href="?filter=confirmed" class="btn <?php echo $filter === 'confirmed' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Confirmed</a>
                <a href="?filter=shipped" class="btn <?php echo $filter === 'shipped' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Shipped</a>
                <a href="?filter=delivered" class="btn <?php echo $filter === 'delivered' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Delivered</a>
            </div>
            
            <!-- Orders Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Buyer</th>
                            <th>Seller</th>
                            <th>Item</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>#<?php echo $order['orderID']; ?></td>
                                <td>
                                    <?php echo htmlspecialchars($order['buyerName']); ?><br>
                                    <small><?php echo htmlspecialchars($order['buyerEmail']); ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($order['sellerName']); ?><br>
                                    <small><?php echo htmlspecialchars($order['sellerEmail']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($order['itemTitle']); ?></td>
                                <td>$<?php echo number_format($order['totalAmount'], 2); ?></td>
                                <td><span class="status-badge status-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                                <td><?php echo date('M j, Y', strtotime($order['orderDate'])); ?></td>
                                <td>
                                    <?php if ($order['status'] === 'pending'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="orderID" value="<?php echo $order['orderID']; ?>">
                                            <input type="hidden" name="action" value="confirm">
                                            <button type="submit" class="btn btn-success btn-sm">Confirm</button>
                                        </form>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="orderID" value="<?php echo $order['orderID']; ?>">
                                            <input type="hidden" name="action" value="cancel">
                                            <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                                        </form>
                                    <?php elseif ($order['status'] === 'confirmed'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="orderID" value="<?php echo $order['orderID']; ?>">
                                            <input type="hidden" name="action" value="ship">
                                            <input type="text" name="trackingNumber" placeholder="Tracking #" style="width: 100px; padding: 4px;">
                                            <button type="submit" class="btn btn-primary btn-sm">Ship</button>
                                        </form>
                                    <?php elseif ($order['status'] === 'shipped'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="orderID" value="<?php echo $order['orderID']; ?>">
                                            <input type="hidden" name="action" value="deliver">
                                            <button type="submit" class="btn btn-success btn-sm">Mark Delivered</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-light">No actions</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (count($orders) === 0): ?>
                <div class="alert alert-info mt-3">No orders found</div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php $connection->close(); ?>