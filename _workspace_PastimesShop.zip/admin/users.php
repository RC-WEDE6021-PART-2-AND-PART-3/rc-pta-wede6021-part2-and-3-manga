<?php
/**
 * admin/users.php - User Management Page
 * Pastimes Online Shop
 * 
 * Admin can Add, Update, and Delete customer records
 */

session_start();
require_once '../includes/DBConn.php';

// Check admin login
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$success = '';
$error = '';
$editUser = null;

// Handle Add/Update User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['saveUser'])) {
    $userID = intval($_POST['userID'] ?? 0);
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $username = sanitizeInput($_POST['username']);
    $phone = sanitizeInput($_POST['phone'] ?? '');
    $address = sanitizeInput($_POST['address'] ?? '');
    $city = sanitizeInput($_POST['city'] ?? '');
    $postalCode = sanitizeInput($_POST['postalCode'] ?? '');
    $status = sanitizeInput($_POST['status']);
    $userType = sanitizeInput($_POST['userType']);
    $newPassword = $_POST['newPassword'] ?? '';
    
    if ($userID > 0) {
        // Update existing user
        $sql = "UPDATE tblUser SET name='$name', email='$email', username='$username', 
                phone='$phone', address='$address', city='$city', postalCode='$postalCode', 
                status='$status', userType='$userType'";
        
        if (!empty($newPassword)) {
            $hashedPassword = hashPassword($newPassword);
            $sql .= ", password='$hashedPassword'";
        }
        
        $sql .= " WHERE userID=$userID";
        
        if ($connection->query($sql)) {
            $success = "User updated successfully";
        } else {
            $error = "Failed to update user: " . $connection->error;
        }
    } else {
        // Add new user
        if (empty($newPassword)) {
            $error = "Password is required for new users";
        } else {
            $hashedPassword = hashPassword($newPassword);
            $sql = "INSERT INTO tblUser (name, email, username, password, phone, address, city, postalCode, status, userType) 
                    VALUES ('$name', '$email', '$username', '$hashedPassword', '$phone', '$address', '$city', '$postalCode', '$status', '$userType')";
            
            if ($connection->query($sql)) {
                $success = "User added successfully";
            } else {
                $error = "Failed to add user: " . $connection->error;
            }
        }
    }
}

// Handle Delete User
if (isset($_GET['delete'])) {
    $userID = intval($_GET['delete']);
    if ($connection->query("DELETE FROM tblUser WHERE userID = $userID")) {
        $success = "User deleted successfully";
    } else {
        $error = "Failed to delete user";
    }
}

// Handle Edit User
if (isset($_GET['edit'])) {
    $userID = intval($_GET['edit']);
    $result = $connection->query("SELECT * FROM tblUser WHERE userID = $userID");
    if ($result->num_rows === 1) {
        $editUser = $result->fetch_assoc();
    }
}

// Get all users with pagination
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$totalUsers = $connection->query("SELECT COUNT(*) as cnt FROM tblUser")->fetch_assoc()['cnt'];
$totalPages = ceil($totalUsers / $perPage);

$search = sanitizeInput($_GET['search'] ?? '');
$whereClause = '';
if (!empty($search)) {
    $whereClause = " WHERE name LIKE '%$search%' OR email LIKE '%$search%' OR username LIKE '%$search%'";
}

$users = [];
$result = $connection->query("SELECT * FROM tblUser $whereClause ORDER BY userID DESC LIMIT $perPage OFFSET $offset");
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Pastimes Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <h3>Admin Panel</h3>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php" class="active">Manage Users</a></li>
                <li><a href="verify-users.php">Verify Users</a></li>
                <li><a href="sellers.php">Seller Requests</a></li>
                <li><a href="clothing.php">Manage Clothing</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="../index.php">View Shop</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </aside>
        
        <div class="dashboard-content">
            <div class="dashboard-header">
                <h1>Manage Users</h1>
                <button class="btn btn-primary" onclick="showAddForm()">Add New User</button>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <!-- Search Form -->
            <form method="GET" class="mb-3">
                <div class="form-group" style="display: flex; gap: 1rem;">
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search users..." style="flex: 1;">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="users.php" class="btn btn-secondary">Clear</a>
                </div>
            </form>
            
            <!-- User Form Modal -->
            <div id="userModal" class="modal-overlay <?php echo $editUser ? 'active' : ''; ?>">
                <div class="modal">
                    <div class="modal-header">
                        <h3><?php echo $editUser ? 'Edit User' : 'Add New User'; ?></h3>
                        <button class="modal-close" onclick="closeModal()">&times;</button>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="userID" value="<?php echo $editUser['userID'] ?? 0; ?>">
                        
                        <div class="form-group">
                            <label>Name *</label>
                            <input type="text" name="name" value="<?php echo htmlspecialchars($editUser['name'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Email *</label>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($editUser['email'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Username *</label>
                            <input type="text" name="username" value="<?php echo htmlspecialchars($editUser['username'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label><?php echo $editUser ? 'New Password (leave blank to keep current)' : 'Password *'; ?></label>
                            <input type="password" name="newPassword" <?php echo $editUser ? '' : 'required'; ?> minlength="8">
                        </div>
                        
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" value="<?php echo htmlspecialchars($editUser['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address"><?php echo htmlspecialchars($editUser['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="grid grid-2">
                            <div class="form-group">
                                <label>City</label>
                                <input type="text" name="city" value="<?php echo htmlspecialchars($editUser['city'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>Postal Code</label>
                                <input type="text" name="postalCode" value="<?php echo htmlspecialchars($editUser['postalCode'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="grid grid-2">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status">
                                    <option value="pending" <?php echo ($editUser['status'] ?? '') === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="verified" <?php echo ($editUser['status'] ?? '') === 'verified' ? 'selected' : ''; ?>>Verified</option>
                                    <option value="suspended" <?php echo ($editUser['status'] ?? '') === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>User Type</label>
                                <select name="userType">
                                    <option value="buyer" <?php echo ($editUser['userType'] ?? '') === 'buyer' ? 'selected' : ''; ?>>Buyer</option>
                                    <option value="seller" <?php echo ($editUser['userType'] ?? '') === 'seller' ? 'selected' : ''; ?>>Seller</option>
                                    <option value="admin" <?php echo ($editUser['userType'] ?? '') === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" name="saveUser" class="btn btn-primary btn-block">Save User</button>
                    </form>
                </div>
            </div>
            
            <!-- Users Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['userID']; ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo ucfirst($user['userType']); ?></td>
                                <td><span class="status-badge status-<?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                                <td>
                                    <a href="?edit=<?php echo $user['userID']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <a href="?delete=<?php echo $user['userID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this user?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="mt-3 text-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo $search; ?>" 
                           class="btn <?php echo $i === $page ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function showAddForm() {
            document.getElementById('userModal').classList.add('active');
        }
        
        function closeModal() {
            document.getElementById('userModal').classList.remove('active');
            window.location.href = 'users.php';
        }
    </script>
</body>
</html>
<?php $connection->close(); ?>