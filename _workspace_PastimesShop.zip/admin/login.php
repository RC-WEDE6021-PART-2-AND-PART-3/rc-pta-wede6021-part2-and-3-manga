<?php
/**
 * admin/login.php - Administrator Login Page
 * Pastimes Online Shop
 * 
 * Separate login portal for administrators
 */

session_start();
require_once '../includes/DBConn.php';

// Redirect if already logged in as admin
if (isset($_SESSION['userID']) && $_SESSION['userType'] === 'admin') {
    header('Location: dashboard.php');
    exit();
}

$errors = [];
$stickyData = ['username' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stickyData['username'] = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($stickyData['username'])) {
        $errors[] = "Username is required";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    }
    
    if (empty($errors)) {
        $username = sanitizeInput($stickyData['username']);
        $hashedPassword = hashPassword($password);
        $hashedPasswordSHA = hashPasswordSHA($password);
        
        // Check admin credentials
        $sql = "SELECT u.*, a.adminLevel FROM tblUser u 
                JOIN tblAdmin a ON u.userID = a.userID 
                WHERE u.username = '$username' AND u.userType = 'admin'";
        $result = $connection->query($sql);
        
        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            
            if ($admin['password'] === $hashedPassword || $admin['password'] === $hashedPasswordSHA) {
                $_SESSION['userID'] = $admin['userID'];
                $_SESSION['name'] = $admin['name'];
                $_SESSION['email'] = $admin['email'];
                $_SESSION['username'] = $admin['username'];
                $_SESSION['userType'] = 'admin';
                $_SESSION['adminLevel'] = $admin['adminLevel'];
                $_SESSION['isLoggedIn'] = true;
                
                $connection->query("UPDATE tblUser SET lastLogin = NOW() WHERE userID = " . $admin['userID']);
                
                header('Location: dashboard.php');
                exit();
            } else {
                $errors[] = "Invalid password";
            }
        } else {
            $errors[] = "Invalid admin username";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Pastimes Online Shop</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">
                <a href="../index.php"><h1>Past<span>i</span>mes Shop</h1></a>
            </div>
            <div class="user-nav">
                <a href="../login.php" class="btn btn-outline btn-sm">User Login</a>
            </div>
        </div>
    </header>

    <main>
        <div class="form-container">
            <h2>Administrator Login</h2>
            <p class="text-center text-light">Restricted access for administrators only</p>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul style="margin: 0; padding-left: 20px;">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" novalidate>
                <div class="form-group">
                    <label for="username">Admin Username *</label>
                    <input type="text" 
                           id="username" 
                           name="username" 
                           value="<?php echo htmlspecialchars($stickyData['username']); ?>" 
                           placeholder="Enter admin username"
                           required
                           class="<?php echo !empty($stickyData['username']) ? 'sticky' : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password *</label>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           placeholder="Enter admin password"
                           required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Login as Admin</button>
            </form>
            
            <p class="mt-3 text-center">
                Default admin: <strong>admin</strong> / <strong>admin123</strong>
            </p>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Pastimes Online Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php $connection->close(); ?>