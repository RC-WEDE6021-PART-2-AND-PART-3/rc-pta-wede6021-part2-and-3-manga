<?php
$pageTitle = 'My Dashboard';
require_once 'includes/session.php';
requireUserLogin();
require_once 'includes/DBConn.php';
$base = '/pastimes_poe';
$user = getLoggedInUser();
$uid  = (int)$user['id'];

$myItems  = in_array($user['role'],['seller','both'])
    ? mysqli_query($conn,"SELECT * FROM tblClothes WHERE SellerID=$uid ORDER BY CreatedAt DESC")
    : null;
$myOrders = mysqli_query($conn,"SELECT o.*,c.Title,c.Brand,c.Price FROM tblAorder o JOIN tblClothes c ON o.ClothesID=c.ClothesID WHERE o.BuyerID=$uid ORDER BY o.OrderDate DESC LIMIT 10");
$unread   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tblMessage WHERE ReceiverID=$uid AND IsRead=0"))['c'];
$spent    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(TotalPrice),0) s FROM tblAorder WHERE BuyerID=$uid AND Status='delivered'"))['s'];
$listings = $myItems ? mysqli_num_rows($myItems) : 0;

require_once 'includes/header.php';
?>
<div class="page-header">
    <div class="page-header-inner flex justify-between items-center flex-wrap" style="gap:1rem;">
        <div>
            <h1>My Dashboard</h1>
            <p>
                Welcome, <?= htmlspecialchars($user['name']) ?> &nbsp;
                <span class="badge badge-<?= $user['status'] ?>"><?= ucfirst($user['status']) ?></span>
                <span class="badge" style="background:#e9e9e9;color:#333;"><?= ucfirst($user['role']) ?></span>
            </p>
        </div>
        <?php if (in_array($user['role'],['seller','both']) && !$user['seller_verified']): ?>
        <div class="info-box" style="border-left:3px solid var(--warning);">
            &#9888; Your <strong>seller account</strong> is pending admin approval.
        </div>
        <?php endif; ?>
    </div>
</div>

<div style="padding:2rem 1.5rem;">
<div class="dashboard-layout">

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="sidebar-title">Navigation</div>
        <nav class="sidebar-nav">
            <a href="<?= $base ?>/dashboard.php" class="active">&#128100; Dashboard</a>
            <a href="<?= $base ?>/shop.php">&#128722; Browse Shop</a>
            <a href="<?= $base ?>/cart.php">&#128717; Shopping Cart <?= $unread>0?"" : "" ?></a>
            <a href="<?= $base ?>/messages.php">&#9993; Messages <?= $unread>0?"($unread)":'' ?></a>
            <?php if (in_array($user['role'],['seller','both']) && $user['seller_verified']): ?>
            <a href="<?= $base ?>/sell.php">&#43; List New Item</a>
            <?php endif; ?>
            <a href="<?= $base ?>/logout.php" style="color:rgba(255,255,255,0.4);margin-top:1rem;">&#128682; Logout</a>
        </nav>
    </aside>

    <!-- MAIN -->
    <main>
        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-number"><?= $listings ?></div><div class="stat-label">My Listings</div></div>
            <div class="stat-card"><div class="stat-number"><?= mysqli_num_rows($myOrders) ?></div><div class="stat-label">Orders Placed</div></div>
            <div class="stat-card"><div class="stat-number">R<?= number_format($spent,0) ?></div><div class="stat-label">Total Spent</div></div>
            <div class="stat-card"><div class="stat-number"><?= $unread ?></div><div class="stat-label">Unread Messages</div></div>
        </div>

        <div class="grid-2" style="gap:1.5rem;align-items:start;">
            <!-- Account Info -->
            <div class="card">
                <div class="card-title">Account Details</div>
                <dl style="display:grid;grid-template-columns:110px 1fr;gap:0.6rem;font-size:0.88rem;">
                    <dt style="color:var(--muted);">Name</dt><dd><?= htmlspecialchars($user['name']) ?></dd>
                    <dt style="color:var(--muted);">Username</dt><dd>@<?= htmlspecialchars($user['username']) ?></dd>
                    <dt style="color:var(--muted);">Email</dt><dd><?= htmlspecialchars($user['email']) ?></dd>
                    <dt style="color:var(--muted);">Role</dt><dd><?= ucfirst($user['role']) ?></dd>
                    <dt style="color:var(--muted);">Status</dt><dd><span class="badge badge-<?= $user['status'] ?>"><?= ucfirst($user['status']) ?></span></dd>
                    <dt style="color:var(--muted);">Seller</dt><dd><?= $user['seller_verified'] ? '<span class="badge badge-verified">Approved</span>' : '<span class="badge badge-pending">Pending</span>' ?></dd>
                </dl>
                <div style="margin-top:1.2rem;display:flex;flex-direction:column;gap:0.6rem;">
                    <a href="<?= $base ?>/shop.php" class="btn btn-outline btn-sm">&#128722; Browse Shop</a>
                    <a href="<?= $base ?>/messages.php" class="btn btn-outline btn-sm">&#9993; Messages <?= $unread>0?"($unread)":'' ?></a>
                    <?php if (in_array($user['role'],['seller','both']) && $user['seller_verified']): ?>
                    <a href="<?= $base ?>/sell.php" class="btn btn-primary btn-sm">&#43; List New Item</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- My Orders -->
            <div class="card">
                <div class="card-title">My Orders</div>
                <?php if (mysqli_num_rows($myOrders) === 0): ?>
                <div class="empty-state" style="padding:2rem;">
                    <div class="empty-icon" style="font-size:2rem;">📦</div>
                    <p>No orders yet. <a href="<?= $base ?>/shop.php" style="color:var(--gold);">Start shopping!</a></p>
                </div>
                <?php else: ?>
                <div class="table-wrap">
                <table>
                    <thead><tr><th>#</th><th>Item</th><th>Total</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php while ($ord = mysqli_fetch_assoc($myOrders)): ?>
                    <tr>
                        <td><?= $ord['OrderID'] ?></td>
                        <td>
                            <div style="font-weight:500;"><?= htmlspecialchars($ord['Title']) ?></div>
                            <div style="font-size:0.75rem;color:var(--muted);"><?= htmlspecialchars($ord['Brand']) ?></div>
                        </td>
                        <td>R<?= number_format($ord['TotalPrice'],2) ?></td>
                        <td><span class="badge badge-<?= $ord['Status']==='delivered'?'approved':($ord['Status']==='cancelled'?'removed':'pending') ?>"><?= ucfirst($ord['Status']) ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- My Listings -->
        <?php if ($myItems && mysqli_num_rows($myItems) > 0): ?>
        <div class="card mt-3">
            <div class="flex justify-between items-center mb-2">
                <div class="card-title" style="margin-bottom:0;">My Listings</div>
                <?php if ($user['seller_verified']): ?>
                <a href="<?= $base ?>/sell.php" class="btn btn-primary btn-sm">+ Add New</a>
                <?php endif; ?>
            </div>
            <div class="table-wrap">
            <table>
                <thead><tr><th>Title</th><th>Brand</th><th>Price</th><th>Size</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php mysqli_data_seek($myItems,0); while ($it=mysqli_fetch_assoc($myItems)): ?>
                <tr>
                    <td><?= htmlspecialchars($it['Title']) ?></td>
                    <td><?= htmlspecialchars($it['Brand']) ?></td>
                    <td>R<?= number_format($it['Price'],2) ?></td>
                    <td><?= htmlspecialchars($it['Size']??'N/A') ?></td>
                    <td><span class="badge badge-<?= $it['Status'] ?>"><?= ucfirst($it['Status']) ?></span></td>
                    <td>
                        <?php if ($it['Status']==='approved'): ?>
                        <a href="<?= $base ?>/product.php?id=<?= $it['ClothesID'] ?>" class="btn btn-sm btn-outline">View</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            </div>
        </div>
        <?php endif; ?>

    </main>
</div>
</div>

<?php require_once 'includes/footer.php'; ?>
