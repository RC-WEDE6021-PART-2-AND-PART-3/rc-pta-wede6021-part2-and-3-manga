<?php
$pageTitle = 'Messages';
require_once 'includes/session.php';
requireUserLogin();
require_once 'includes/DBConn.php';
$base = '/pastimes_poe';
$user = getLoggedInUser();
$uid  = (int)$user['id'];

// Send message
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to      = (int)($_POST['to']      ?? 0);
    $subject = mysqli_real_escape_string($conn, trim($_POST['subject'] ?? ''));
    $body    = mysqli_real_escape_string($conn, trim($_POST['body']    ?? ''));
    $clothes = (int)($_POST['clothes'] ?? 0);
    $cv      = $clothes > 0 ? $clothes : 'NULL';

    if ($to && $body) {
        mysqli_query($conn, "INSERT INTO tblMessage (SenderID,ReceiverID,ClothesID,Subject,Body)
            VALUES ($uid,$to,$cv,'$subject','$body')");
        flashMessage('success', 'Message sent successfully!');
        header("Location: $base/messages.php");
        exit;
    } else {
        flashMessage('danger', 'Please select a recipient and write a message body.');
    }
}

// Mark received messages as read
mysqli_query($conn, "UPDATE tblMessage SET IsRead=1 WHERE ReceiverID=$uid AND IsRead=0");

// Inbox
$inbox = mysqli_query($conn,
    "SELECT m.*, u.Name AS SenderName, u.Username AS SenderUsername,
            c.Title AS ClothesTitle, c.Brand AS ClothesBrand
     FROM tblMessage m
     JOIN tblUser u ON m.SenderID = u.UserID
     LEFT JOIN tblClothes c ON m.ClothesID = c.ClothesID
     WHERE m.ReceiverID = $uid
     ORDER BY m.SentAt DESC");

// Pre-fill To/Clothes from URL params
$toUser    = (int)($_GET['to']      ?? 0);
$clothesId = (int)($_GET['clothes'] ?? 0);
$clothesInfo = null;
$toUserInfo  = null;

if ($clothesId) {
    $r = mysqli_query($conn, "SELECT Title,Brand FROM tblClothes WHERE ClothesID=$clothesId LIMIT 1");
    if ($r && mysqli_num_rows($r)) $clothesInfo = mysqli_fetch_assoc($r);
}
if ($toUser) {
    $r = mysqli_query($conn, "SELECT Name,Username FROM tblUser WHERE UserID=$toUser LIMIT 1");
    if ($r && mysqli_num_rows($r)) $toUserInfo = mysqli_fetch_assoc($r);
}

// Users list for recipient dropdown
$users = mysqli_query($conn,
    "SELECT UserID,Name,Username FROM tblUser
     WHERE UserID != $uid AND Status='verified'
     ORDER BY Name");

require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner">
        <div class="breadcrumb"><a href="<?= $base ?>">Home</a> &rsaquo; <span>Messages</span></div>
        <h1>Messages</h1>
        <p>Communicate with buyers and sellers regarding clothing items</p>
    </div>
</div>

<section style="padding:2rem 1.5rem;">
<div style="max-width:1100px;margin:0 auto;">
<div class="grid-2" style="gap:2rem;align-items:start;">

    <!-- COMPOSE PANEL -->
    <div class="card">
        <div class="card-title">Compose Message</div>

        <?php if ($clothesInfo): ?>
        <div class="info-box mb-2">
            📦 Enquiring about: <strong><?= htmlspecialchars($clothesInfo['Title']) ?></strong>
            (<?= htmlspecialchars($clothesInfo['Brand']) ?>)
        </div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="clothes" value="<?= $clothesId ?>">

            <div class="form-group">
                <label>Send To *</label>
                <select name="to" class="form-control" required>
                    <option value="">Select a user...</option>
                    <?php while ($u = mysqli_fetch_assoc($users)): ?>
                    <option value="<?= $u['UserID'] ?>" <?= $u['UserID'] == $toUser ? 'selected' : '' ?>>
                        <?= htmlspecialchars($u['Name']) ?> (@<?= htmlspecialchars($u['Username']) ?>)
                    </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Subject</label>
                <input type="text" name="subject" class="form-control"
                       value="<?= $clothesInfo ? 'Enquiry: ' . htmlspecialchars($clothesInfo['Title']) : '' ?>"
                       placeholder="e.g. Question about the jeans listing">
            </div>

            <div class="form-group">
                <label>Message *</label>
                <textarea name="body" class="form-control" rows="6"
                          placeholder="Type your message here..." required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">&#9993; Send Message</button>
        </form>
    </div>

    <!-- INBOX -->
    <div>
        <div class="card-title" style="padding:0 0 1rem 0;">Inbox</div>
        <div class="card" style="padding:0;overflow:hidden;">
            <?php if (!$inbox || mysqli_num_rows($inbox) === 0): ?>
            <div class="empty-state" style="padding:3rem;">
                <div class="empty-icon" style="font-size:2.5rem;">✉️</div>
                <h3>No Messages Yet</h3>
                <p>When buyers or sellers message you, they'll appear here.</p>
            </div>
            <?php else: ?>
            <?php while ($msg = mysqli_fetch_assoc($inbox)): ?>
            <div class="msg-item">
                <div class="msg-avatar">
                    <?= strtoupper(substr($msg['SenderName'], 0, 1)) ?>
                </div>
                <div class="msg-body">
                    <div class="msg-from">
                        <?= htmlspecialchars($msg['SenderName']) ?>
                        <span style="color:var(--muted);font-weight:400;font-size:0.8rem;">
                            @<?= htmlspecialchars($msg['SenderUsername']) ?>
                        </span>
                    </div>
                    <?php if ($msg['Subject']): ?>
                    <div style="font-size:0.82rem;font-weight:500;color:var(--primary);">
                        <?= htmlspecialchars($msg['Subject']) ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($msg['ClothesTitle']): ?>
                    <div style="font-size:0.72rem;color:var(--gold);">
                        📦 <?= htmlspecialchars($msg['ClothesTitle']) ?> — <?= htmlspecialchars($msg['ClothesBrand']) ?>
                    </div>
                    <?php endif; ?>
                    <div class="msg-preview"><?= htmlspecialchars(substr($msg['Body'], 0, 100)) ?>...</div>
                </div>
                <div class="msg-time"><?= date('d M', strtotime($msg['SentAt'])) ?></div>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>

</div>
</div>
</section>

<?php require_once 'includes/footer.php'; ?>
