<?php
/*
 * Student Name: [DUMISA]
 * Student Number: [ST10445334]
 * Declaration: This code is my own work where not referenced.
 *
 * loadClothingStore.php
 * Creates all tables in the ClothingStore database.
 * All tables are dropped first for a clean state.
 * Uses MySQLi for database interaction.
 */

require_once 'includes/DBConn.php';

$log = [];
$ok  = true;

function runSQL($conn, $sql, &$log, $label) {
    if (mysqli_query($conn, $sql)) {
        $log[] = ['ok', "✓ $label"];
    } else {
        $log[] = ['err', "✗ $label — " . mysqli_error($conn)];
    }
}

// ── STEP 1: DROP ALL TABLES (reverse FK order) ────────────────
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");
$tables = ['tblMessage','tblCartItem','tblCart','tblAorder','tblClothes','tblAdmin','tblUser'];
foreach ($tables as $t) {
    runSQL($conn, "DROP TABLE IF EXISTS `$t`", $log, "Dropped $t");
}
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");

// ── STEP 2: CREATE tblUser ─────────────────────────────────────
runSQL($conn, "CREATE TABLE IF NOT EXISTS tblUser (
    UserID         INT          AUTO_INCREMENT PRIMARY KEY,
    Name           VARCHAR(100) NOT NULL,
    Email          VARCHAR(150) NOT NULL UNIQUE,
    Username       VARCHAR(50)  NOT NULL UNIQUE,
    PasswordHash   VARCHAR(255) NOT NULL,
    Role           ENUM('buyer','seller','both') DEFAULT 'buyer',
    Status         ENUM('pending','verified','suspended') DEFAULT 'pending',
    SellerVerified TINYINT(1)   DEFAULT 0,
    Address        TEXT,
    ProfileImage   VARCHAR(255),
    CreatedAt      DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", $log, "Created tblUser");

// ── STEP 3: CREATE tblAdmin ────────────────────────────────────
runSQL($conn, "CREATE TABLE IF NOT EXISTS tblAdmin (
    AdminID      INT          AUTO_INCREMENT PRIMARY KEY,
    Name         VARCHAR(100) NOT NULL,
    Email        VARCHAR(150) NOT NULL UNIQUE,
    Username     VARCHAR(50)  NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    CreatedAt    DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", $log, "Created tblAdmin");

// ── STEP 4: CREATE tblClothes ──────────────────────────────────
runSQL($conn, "CREATE TABLE IF NOT EXISTS tblClothes (
    ClothesID   INT            AUTO_INCREMENT PRIMARY KEY,
    SellerID    INT            NOT NULL,
    Title       VARCHAR(150)   NOT NULL,
    Description TEXT,
    Brand       VARCHAR(100)   NOT NULL,
    Size        VARCHAR(20),
    Price       DECIMAL(10,2)  NOT NULL,
    ImagePath   VARCHAR(255),
    Category    VARCHAR(50),
    \`Condition\` ENUM('new','like_new','good','fair') DEFAULT 'good',
    Status      ENUM('pending','approved','sold','removed') DEFAULT 'pending',
    CreatedAt   DATETIME       DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SellerID) REFERENCES tblUser(UserID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", $log, "Created tblClothes");

// ── STEP 5: CREATE tblCart ─────────────────────────────────────
runSQL($conn, "CREATE TABLE IF NOT EXISTS tblCart (
    CartID    INT  AUTO_INCREMENT PRIMARY KEY,
    BuyerID   INT  NOT NULL,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (BuyerID) REFERENCES tblUser(UserID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", $log, "Created tblCart");

// ── STEP 6: CREATE tblCartItem ────────────────────────────────
runSQL($conn, "CREATE TABLE IF NOT EXISTS tblCartItem (
    CartItemID INT AUTO_INCREMENT PRIMARY KEY,
    CartID     INT NOT NULL,
    ClothesID  INT NOT NULL,
    Quantity   INT DEFAULT 1,
    AddedAt    DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (CartID)    REFERENCES tblCart(CartID)       ON DELETE CASCADE,
    FOREIGN KEY (ClothesID) REFERENCES tblClothes(ClothesID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", $log, "Created tblCartItem");

// ── STEP 7: CREATE tblAorder ──────────────────────────────────
runSQL($conn, "CREATE TABLE IF NOT EXISTS tblAorder (
    OrderID         INT           AUTO_INCREMENT PRIMARY KEY,
    BuyerID         INT           NOT NULL,
    ClothesID       INT           NOT NULL,
    SellerID        INT           NOT NULL,
    AdminID         INT,
    Quantity        INT           DEFAULT 1,
    TotalPrice      DECIMAL(10,2) NOT NULL,
    Status          ENUM('pending','confirmed','shipped','delivered','cancelled') DEFAULT 'pending',
    ShippingAddress TEXT,
    Notes           TEXT,
    OrderDate       DATETIME      DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt       DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (BuyerID)   REFERENCES tblUser(UserID),
    FOREIGN KEY (ClothesID) REFERENCES tblClothes(ClothesID),
    FOREIGN KEY (SellerID)  REFERENCES tblUser(UserID),
    FOREIGN KEY (AdminID)   REFERENCES tblAdmin(AdminID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", $log, "Created tblAorder");

// ── STEP 8: CREATE tblMessage ────────────────────────────────
runSQL($conn, "CREATE TABLE IF NOT EXISTS tblMessage (
    MessageID  INT  AUTO_INCREMENT PRIMARY KEY,
    SenderID   INT  NOT NULL,
    ReceiverID INT  NOT NULL,
    ClothesID  INT,
    Subject    VARCHAR(200),
    Body       TEXT NOT NULL,
    IsRead     TINYINT(1) DEFAULT 0,
    SentAt     DATETIME   DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SenderID)   REFERENCES tblUser(UserID),
    FOREIGN KEY (ReceiverID) REFERENCES tblUser(UserID),
    FOREIGN KEY (ClothesID)  REFERENCES tblClothes(ClothesID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", $log, "Created tblMessage");

// ── STEP 9: INSERT DEFAULT ADMINS ────────────────────────────
$p = md5('admin1234');
$sql = "INSERT INTO tblAdmin (Name,Email,Username,PasswordHash) VALUES
    ('Super Admin','admin@pastimes.co.za','superadmin','$p'),
    ('Jane Administrator','jane@pastimes.co.za','janeadmin','$p')
    ON DUPLICATE KEY UPDATE Name=VALUES(Name)";
runSQL($conn, $sql, $log, "Inserted default admin accounts (password: admin1234)");

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ClothingStore DB Setup — Pastimes</title>
    <style>
        body { font-family: monospace; background: #0d1117; color: #c9d1d9; padding: 2rem; }
        h1 { color: #f0b429; font-family: Georgia, serif; margin-bottom: 1.5rem; }
        .log-item { padding: 4px 0; font-size: 0.9rem; }
        .ok  { color: #3fb950; }
        .err { color: #f85149; }
        .done { margin-top: 2rem; padding: 1rem; background: #161b22; border-radius: 8px; border-left: 4px solid #3fb950; }
        .done a { color: #f0b429; }
        .done h3 { color: #3fb950; margin-bottom: 0.5rem; }
    </style>
</head>
<body>
<h1>🗄️ ClothingStore Database Setup</h1>
<?php foreach ($log as [$type, $msg]): ?>
    <div class="log-item <?= $type ?>"><?= htmlspecialchars($msg) ?></div>
<?php endforeach; ?>
<div class="done">
    <h3>✅ Setup Complete!</h3>
    <p>Next steps:</p>
    <p>1. <a href="createTable.php">→ Load Users from userData.txt</a></p>
    <p>2. <a href="index.php">→ Go to Pastimes Homepage</a></p>
    <p>3. <a href="admin/login.php">→ Admin Login</a> (superadmin / admin1234)</p>
</div>
</body>
</html>
