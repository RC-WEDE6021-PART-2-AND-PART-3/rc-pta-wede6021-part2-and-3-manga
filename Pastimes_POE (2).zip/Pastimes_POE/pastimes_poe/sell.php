<?php
$pageTitle = 'Sell an Item';
require_once 'includes/session.php';
requireUserLogin();
require_once 'includes/DBConn.php';
$base = '/pastimes_poe';
$user = getLoggedInUser();

if (!in_array($user['role'],['seller','both']) || !$user['seller_verified']) {
    flashMessage('warning','Your seller account must be verified by an admin before you can list items.');
    header("Location: $base/dashboard.php"); exit;
}

$errors = []; $sticky = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sticky['title']       = trim($_POST['title']       ?? '');
    $sticky['description'] = trim($_POST['description'] ?? '');
    $sticky['brand']       = trim($_POST['brand']       ?? '');
    $sticky['size']        = trim($_POST['size']        ?? '');
    $sticky['price']       = trim($_POST['price']       ?? '');
    $sticky['category']    = trim($_POST['category']    ?? '');
    $sticky['condition']   = $_POST['condition']        ?? 'good';

    if (empty($sticky['title']))       $errors['title']       = 'Title is required.';
    if (empty($sticky['brand']))       $errors['brand']       = 'Brand is required.';
    if (empty($sticky['description'])) $errors['description'] = 'Description is required.';
    if (!is_numeric($sticky['price']) || (float)$sticky['price'] <= 0)
                                       $errors['price']       = 'Please enter a valid price.';

    $imagePath = null;
    if (!empty($_FILES['image']['name'])) {
        $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
        if (!in_array($_FILES['image']['type'],$allowed)) $errors['image'] = 'Only JPG, PNG, WEBP or GIF images allowed.';
        elseif ($_FILES['image']['size'] > 5*1024*1024) $errors['image'] = 'Image must be under 5MB.';
        else {
            $uploadDir = __DIR__ . '/images/';
            if (!is_dir($uploadDir)) mkdir($uploadDir,0755,true);
            $ext = strtolower(pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION));
            $filename = 'item_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'],$uploadDir.$filename)) {
                $imagePath = 'images/' . $filename;
            } else {
                $errors['image'] = 'Upload failed. Check folder permissions (images/ must be writable).';
            }
        }
    }

    if (empty($errors)) {
        $uid  = (int)$user['id'];
        $t    = mysqli_real_escape_string($conn, $sticky['title']);
        $desc = mysqli_real_escape_string($conn, $sticky['description']);
        $br   = mysqli_real_escape_string($conn, $sticky['brand']);
        $sz   = mysqli_real_escape_string($conn, $sticky['size']);
        $pr   = (float)$sticky['price'];
        $cat  = mysqli_real_escape_string($conn, $sticky['category']);
        $cond = mysqli_real_escape_string($conn, $sticky['condition']);
        $img  = $imagePath ? "'" . mysqli_real_escape_string($conn,$imagePath) . "'" : 'NULL';

        $sql = "INSERT INTO tblClothes (SellerID,Title,Description,Brand,Size,Price,ImagePath,Category,\`Condition\`,Status)
                VALUES ($uid,'$t','$desc','$br','$sz',$pr,$img,'$cat','$cond','pending')";
        if (mysqli_query($conn,$sql)) {
            flashMessage('success','Item submitted! An admin will review and approve it shortly — then it will appear in the shop.');
            header("Location: $base/dashboard.php"); exit;
        } else {
            $errors['general'] = 'Failed to submit: ' . mysqli_error($conn);
        }
    }
}
require_once 'includes/header.php';
?>
<div class="page-header">
    <div class="page-header-inner">
        <div class="breadcrumb"><a href="<?= $base ?>">Home</a> &rsaquo; <a href="<?= $base ?>/dashboard.php">Dashboard</a> &rsaquo; <span>List Item</span></div>
        <h1>List an Item for Sale</h1>
        <p>Submit your branded second-hand clothing for admin review and approval.</p>
    </div>
</div>
<section style="background:var(--cream);padding:2rem 1.5rem;">
<div class="form-card" style="max-width:620px;">
    <?php if (!empty($errors['general'])): ?>
    <div class="flash flash-danger" style="border-radius:8px;margin-bottom:1.5rem;"><span><?= htmlspecialchars($errors['general']) ?></span></div>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Item Title *</label>
            <input type="text" name="title" class="form-control <?= isset($errors['title'])?'error':'' ?>" value="<?= htmlspecialchars($sticky['title']??'') ?>" placeholder="e.g. Blue Levi's 501 Jeans" required>
            <?php if (isset($errors['title'])): ?><div class="form-error">&#10005; <?= $errors['title'] ?></div><?php endif; ?>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Brand *</label>
                <input type="text" name="brand" class="form-control <?= isset($errors['brand'])?'error':'' ?>" value="<?= htmlspecialchars($sticky['brand']??'') ?>" placeholder="e.g. Levi's, Zara, Nike" required>
                <?php if (isset($errors['brand'])): ?><div class="form-error">&#10005; <?= $errors['brand'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
                <label>Price (ZAR) *</label>
                <input type="number" name="price" class="form-control <?= isset($errors['price'])?'error':'' ?>" value="<?= htmlspecialchars($sticky['price']??'') ?>" placeholder="250.00" min="1" step="0.01" required>
                <?php if (isset($errors['price'])): ?><div class="form-error">&#10005; <?= $errors['price'] ?></div><?php endif; ?>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Size</label>
                <select name="size" class="form-control">
                    <?php foreach (['XS','S','M','L','XL','XXL','XXXL','28','30','32','34','36','38','40','42','One Size'] as $sz): ?>
                    <option value="<?= $sz ?>" <?= ($sticky['size']??'')===$sz?'selected':'' ?>><?= $sz ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category" class="form-control">
                    <option value="">Select...</option>
                    <?php foreach (['tops','bottoms','dresses','outerwear','shoes','accessories','sportswear','formal'] as $cat): ?>
                    <option value="<?= $cat ?>" <?= ($sticky['category']??'')===$cat?'selected':'' ?>><?= ucfirst($cat) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>Condition</label>
            <select name="condition" class="form-control">
                <option value="new"      <?= ($sticky['condition']??'')==='new'      ?'selected':'' ?>>New with tags</option>
                <option value="like_new" <?= ($sticky['condition']??'like_new')==='like_new'?'selected':'' ?>>Like new</option>
                <option value="good"     <?= ($sticky['condition']??'')==='good'     ?'selected':'' ?>>Good</option>
                <option value="fair"     <?= ($sticky['condition']??'')==='fair'     ?'selected':'' ?>>Fair (minor wear)</option>
            </select>
        </div>
        <div class="form-group">
            <label>Description *</label>
            <textarea name="description" class="form-control <?= isset($errors['description'])?'error':'' ?>" rows="4" placeholder="Describe the item — measurements, brand story, any flaws, original retail price..." required><?= htmlspecialchars($sticky['description']??'') ?></textarea>
            <?php if (isset($errors['description'])): ?><div class="form-error">&#10005; <?= $errors['description'] ?></div><?php endif; ?>
        </div>
        <div class="form-group">
            <label>Item Photo</label>
            <input type="file" id="image" name="image" class="form-control <?= isset($errors['image'])?'error':'' ?>" accept="image/jpeg,image/png,image/webp,image/gif">
            <div class="form-hint">JPG, PNG, WEBP or GIF. Max 5MB. Sellers can upload pictures of clothes.</div>
            <?php if (isset($errors['image'])): ?><div class="form-error">&#10005; <?= $errors['image'] ?></div><?php endif; ?>
            <img id="img-preview" src="" style="display:none;margin-top:0.75rem;max-height:220px;border-radius:8px;object-fit:cover;">
        </div>
        <div class="info-box mb-3">
            &#9432; Your listing will be <strong>reviewed by an admin</strong> before going live in the shop. This usually takes 24–48 hours.
        </div>
        <div style="display:flex;gap:1rem;">
            <button type="submit" class="btn btn-primary">Submit Listing</button>
            <a href="<?= $base ?>/dashboard.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>
</section>
<?php require_once 'includes/footer.php'; ?>
