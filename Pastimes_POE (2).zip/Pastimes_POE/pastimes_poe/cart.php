<?php
$pageTitle = 'Shopping Cart';
require_once 'includes/session.php';
requireUserLogin();
require_once 'includes/DBConn.php';
$base = '/pastimes_poe';
$user = getLoggedInUser();
$uid  = (int)$user['id'];

$cartRes = mysqli_query($conn,"SELECT CartID FROM tblCart WHERE BuyerID=$uid LIMIT 1");
if (mysqli_num_rows($cartRes)===0) { mysqli_query($conn,"INSERT INTO tblCart (BuyerID) VALUES ($uid)"); $cartId=mysqli_insert_id($conn); }
else $cartId = mysqli_fetch_assoc($cartRes)['CartID'];

// Remove item
if (isset($_GET['remove'])) {
    $rm = (int)$_GET['remove'];
    mysqli_query($conn,"DELETE FROM tblCartItem WHERE CartItemID=$rm AND CartID=$cartId");
    flashMessage('info','Item removed from cart.');
    header("Location: $base/cart.php"); exit;
}

// Checkout
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['checkout'])) {
    if ($user['status']!=='verified') {
        flashMessage('danger','Your account must be verified before purchasing.');
    } else {
        $address = mysqli_real_escape_string($conn, trim($_POST['address']??''));
        if (empty($address)) {
            flashMessage('warning','Please enter a delivery address.');
        } else {
            $items = mysqli_query($conn,"SELECT ci.*,c.Price,c.SellerID FROM tblCartItem ci JOIN tblClothes c ON ci.ClothesID=c.ClothesID WHERE ci.CartID=$cartId AND c.Status='approved'");
            $n = 0;
            while ($it = mysqli_fetch_assoc($items)) {
                $total = $it['Price'] * $it['Quantity'];
                mysqli_query($conn,"INSERT INTO tblAorder (BuyerID,ClothesID,SellerID,TotalPrice,ShippingAddress) VALUES ($uid,{$it['ClothesID']},{$it['SellerID']},$total,'$address')");
                mysqli_query($conn,"UPDATE tblClothes SET Status='sold' WHERE ClothesID={$it['ClothesID']}");
                $n++;
            }
            mysqli_query($conn,"DELETE FROM tblCartItem WHERE CartID=$cartId");
            flashMessage('success',"Order placed for $n item(s)! Our admin team will coordinate delivery with the seller.");
            header("Location: $base/dashboard.php"); exit;
        }
    }
}

// Continue shopping - just redirect to shop
if (isset($_POST['continue_shopping'])) {
    header("Location: $base/shop.php"); exit;
}

$cartItems = mysqli_query($conn,"SELECT ci.*,c.Title,c.Brand,c.Price,c.ImagePath,c.Size,c.Status AS ItemStatus FROM tblCartItem ci JOIN tblClothes c ON ci.ClothesID=c.ClothesID WHERE ci.CartID=$cartId");
$total = 0;
$allItems = [];
while ($it = mysqli_fetch_assoc($cartItems)) { $total += $it['Price']; $allItems[] = $it; }

require_once 'includes/header.php';
?>
<div class="page-header">
    <div class="page-header-inner">
        <div class="breadcrumb"><a href="<?= $base ?>">Home</a> &rsaquo; <span>Shopping Cart</span></div>
        <h1>Shopping Cart</h1>
        <p><?= count($allItems) ?> item<?= count($allItems)!==1?'s':'' ?> in your cart</p>
    </div>
</div>

<section style="padding:2rem 1.5rem;">
<div style="max-width:960px;margin:0 auto;">

<?php if (empty($allItems)): ?>
<div class="empty-state card">
    <div class="empty-icon">🛒</div>
    <h3>Your Cart is Empty</h3>
    <p>Discover amazing second-hand fashion in our shop.</p>
    <a href="<?= $base ?>/shop.php" class="btn btn-primary mt-2">Browse Shop</a>
</div>
<?php else: ?>
<div class="grid-2" style="gap:2rem;align-items:start;">

    <!-- Cart Items -->
    <div style="grid-column:1/-1;" class="card" id="cart-items">
        <?php foreach ($allItems as $it): ?>
        <div class="cart-item">
            <div style="width:80px;height:80px;background:var(--cream);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;">
                <?php if ($it['ImagePath'] && file_exists(__DIR__.'/'.$it['ImagePath'])): ?>
                    <img src="<?= $base ?>/<?= htmlspecialchars($it['ImagePath']) ?>" style="width:80px;height:80px;object-fit:cover;" alt="">
                <?php else: ?>
                    <span style="font-size:2.2rem;">👗</span>
                <?php endif; ?>
            </div>
            <div class="cart-info">
                <div style="font-weight:600;"><?= htmlspecialchars($it['Title']) ?></div>
                <div style="font-size:0.8rem;color:var(--muted);"><?= htmlspecialchars($it['Brand']) ?> &bull; Size <?= htmlspecialchars($it['Size']??'N/A') ?></div>
                <?php if ($it['ItemStatus']==='sold'): ?>
                <div style="font-size:0.75rem;color:var(--danger);margin-top:4px;">&#9888; This item has been sold — remove it to continue.</div>
                <?php endif; ?>
            </div>
            <div style="text-align:right;flex-shrink:0;">
                <div style="font-weight:700;font-size:1.05rem;">R<?= number_format($it['Price'],2) ?></div>
                <a href="<?= $base ?>/cart.php?remove=<?= $it['CartItemID'] ?>"
                   class="btn btn-sm btn-danger mt-1"
                   onclick="return confirm('Remove this item from cart?')">Remove</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Order Summary -->
    <div>
        <div class="cart-summary-box">
            <h3 style="font-family:'Playfair Display',serif;margin-bottom:1rem;">Order Summary</h3>
            <div class="flex justify-between mb-1"><span>Subtotal (<?= count($allItems) ?> items)</span><span>R<?= number_format($total,2) ?></span></div>
            <div class="flex justify-between mb-1" style="color:var(--muted);font-size:0.85rem;"><span>Delivery</span><span>TBD by admin</span></div>
            <hr class="divider">
            <div class="flex justify-between" style="margin-bottom:1.5rem;">
                <strong>Total</strong>
                <span class="cart-total">R<?= number_format($total,2) ?></span>
            </div>

            <?php if ($user['status']==='verified'): ?>
            <form method="POST">
                <div class="form-group">
                    <label>Delivery Address *</label>
                    <textarea name="address" class="form-control" rows="3"
                        placeholder="Enter your full delivery address (residential or work)..."
                        required><?= htmlspecialchars($_SESSION['user_address'] ?? '') ?></textarea>
                    <div class="form-hint">Admin will coordinate delivery with the seller.</div>
                </div>
                <button type="submit" name="checkout" class="btn btn-primary btn-full mb-1">
                    &#128722; Place Order
                </button>
                <button type="submit" name="continue_shopping" class="btn btn-outline btn-full">
                    &#8592; Continue Shopping
                </button>
            </form>
            <?php else: ?>
            <div class="flash flash-warning" style="border-radius:8px;margin-bottom:1rem;">
                &#9888; Your account must be verified before placing orders.
            </div>
            <a href="<?= $base ?>/shop.php" class="btn btn-outline btn-full">&#8592; Continue Shopping</a>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php endif; ?>
</div>
</section>

<?php require_once 'includes/footer.php'; ?>
