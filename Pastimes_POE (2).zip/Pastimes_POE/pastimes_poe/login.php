<?php
/*
 * Student Name: [DUMISA]
 * Student Number: [ST10445334]
 * Declaration: This code is my own work where not referenced.
 *
 * login.php - User Login Page
 * - Accepts username and email address
 * - Compares password against MD5/SHA hash in tblUser
 * - HTML5 validation on form fields
 * - Sticky form: retains username & email on failed login (NOT password)
 * - On success: displays "User [Name] is logged in" banner
 */

$pageTitle = 'Login';
require_once 'includes/session.php';
require_once 'includes/DBConn.php';

$base = '/pastimes_poe';

// Redirect if already logged in
if (isUserLoggedIn()) {
    header("Location: $base/dashboard.php");
    exit;
}

$errors          = [];
$sticky_username = '';  // Sticky form values
$sticky_email    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Read POST values
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password']      ?? '';

    // ── STICKY VALUES (retain on failure, except password) ────
    $sticky_username = $username;
    $sticky_email    = $email;

    // ── SERVER-SIDE VALIDATION (HTML5 mirrors these) ──────────
    if (empty($username)) {
        $errors['username'] = 'Username is required.';
    }
    if (empty($email)) {
        $errors['email'] = 'Email address is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (empty($password)) {
        $errors['password'] = 'Password is required.';
    }

    if (empty($errors)) {
        // ── MD5 HASH THE PASSWORD ─────────────────────────────
        $passHash = md5($password);

        $u = mysqli_real_escape_string($conn, $username);
        $e = mysqli_real_escape_string($conn, $email);

        // ── QUERY tblUser using associative fetch ─────────────
        $sql = "SELECT * FROM tblUser
                WHERE Username = '$u'
                  AND Email    = '$e'
                  AND PasswordHash = '$passHash'
                LIMIT 1";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) === 1) {
            // Fetch as associative array (column names as keys)
            $user = mysqli_fetch_assoc($result);

            // ── SET SESSION VARIABLES ─────────────────────────
            $_SESSION['user_id']         = $user['UserID'];
            $_SESSION['user_name']       = $user['Name'];
            $_SESSION['user_username']   = $user['Username'];
            $_SESSION['user_email']      = $user['Email'];
            $_SESSION['user_role']       = $user['Role'];
            $_SESSION['user_status']     = $user['Status'];
            $_SESSION['seller_verified'] = $user['SellerVerified'];

            flashMessage('success', 'Welcome back, ' . $user['Name'] . '! You are now logged in.');

            // Redirect
            $redirect = $_GET['redirect'] ?? "$base/dashboard.php";
            header("Location: $redirect");
            exit;

        } else {
            // ── INVALID CREDENTIALS ───────────────────────────
            $errors['general'] = 'Invalid username, email or password. Please try again.';
        }
    }
}

require_once 'includes/header.php';
?>

<div style="min-height:70vh;background:var(--cream);display:flex;align-items:center;padding:2rem 1rem;">
<div class="form-card" style="width:100%;">

    <h2>Welcome Back</h2>
    <p class="form-subtitle">Sign in to your Pastimes account</p>

    <?php if (!empty($errors['general'])): ?>
    <div class="flash flash-danger" style="border-radius:8px;margin-bottom:1.5rem;">
        <span>&#10005; <?= htmlspecialchars($errors['general']) ?></span>
    </div>
    <?php endif; ?>

    <!-- ── LOGIN FORM (HTML5 validation + sticky) ─────────── -->
    <form method="POST" action="" novalidate>

        <div class="form-group">
            <label for="username">Username <span style="color:var(--danger)">*</span></label>
            <input
                type="text"
                id="username"
                name="username"
                class="form-control <?= isset($errors['username']) ? 'error' : '' ?>"
                value="<?= htmlspecialchars($sticky_username) ?>"
                placeholder="your_username"
                required
                autocomplete="username"
                minlength="3">
            <?php if (isset($errors['username'])): ?>
                <div class="form-error">&#10005; <?= $errors['username'] ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email Address <span style="color:var(--danger)">*</span></label>
            <input
                type="email"
                id="email"
                name="email"
                class="form-control <?= isset($errors['email']) ? 'error' : '' ?>"
                value="<?= htmlspecialchars($sticky_email) ?>"
                placeholder="you@example.com"
                required
                autocomplete="email">
            <?php if (isset($errors['email'])): ?>
                <div class="form-error">&#10005; <?= $errors['email'] ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="password">Password <span style="color:var(--danger)">*</span></label>
            <!-- Password NOT sticky — security requirement -->
            <input
                type="password"
                id="password"
                name="password"
                class="form-control <?= isset($errors['password']) ? 'error' : '' ?>"
                placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;"
                required
                minlength="8"
                autocomplete="current-password">
            <?php if (isset($errors['password'])): ?>
                <div class="form-error">&#10005; <?= $errors['password'] ?></div>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary btn-full" style="margin-top:1.2rem;border-radius:8px;">
            Sign In to Pastimes
        </button>

    </form>

    <hr class="divider" style="margin:1.5rem 0;">

    <p class="text-center" style="font-size:0.88rem;color:var(--muted);">
        Don't have an account?
        <a href="<?= $base ?>/register.php" style="color:var(--gold);font-weight:600;">Register here</a>
    </p>
    <p class="text-center mt-1" style="font-size:0.8rem;">
        <a href="<?= $base ?>/admin/login.php" style="color:var(--muted);">Admin Login Portal &#8594;</a>
    </p>

    <!-- Test credentials hint -->
    <div class="info-box mt-3">
        <strong>Test credentials (after DB setup):</strong><br>
        Username: <code>amelia_d</code> &bull; Email: <code>amelia.dlamini@email.com</code> &bull; Password: <code>Password1</code>
    </div>

</div>
</div>

<?php require_once 'includes/footer.php'; ?>
