<?php $base = '/pastimes_poe'; ?>
<!-- ======= FOOTER ======= -->
<footer class="site-footer">
    <div class="footer-grid">
        <div class="footer-col">
            <div class="footer-brand">
                <div class="brand-logo" style="width:40px;height:40px;font-size:1.1rem;">P</div>
                <div>
                    <div style="font-family:'Playfair Display',serif;font-size:1.3rem;color:#fff;font-weight:700;">Pastimes</div>
                    <div style="font-size:0.75rem;color:rgba(255,255,255,0.5);">Second-Hand Fashion</div>
                </div>
            </div>
            <p style="color:rgba(255,255,255,0.55);font-size:0.85rem;margin-top:1rem;line-height:1.7;">
                South Africa's most trusted platform for buying and selling premium second-hand branded clothing. Sustainable fashion for everyone.
            </p>
        </div>
        <div class="footer-col">
            <h4>Shop</h4>
            <a href="<?= $base ?>/shop.php">Browse All</a>
            <a href="<?= $base ?>/shop.php?category=tops">Tops</a>
            <a href="<?= $base ?>/shop.php?category=bottoms">Bottoms</a>
            <a href="<?= $base ?>/shop.php?category=dresses">Dresses</a>
            <a href="<?= $base ?>/shop.php?category=shoes">Shoes</a>
            <a href="<?= $base ?>/shop.php?category=accessories">Accessories</a>
        </div>
        <div class="footer-col">
            <h4>My Account</h4>
            <a href="<?= $base ?>/login.php">Login</a>
            <a href="<?= $base ?>/register.php">Register</a>
            <a href="<?= $base ?>/dashboard.php">Dashboard</a>
            <a href="<?= $base ?>/cart.php">Shopping Cart</a>
            <a href="<?= $base ?>/messages.php">Messages</a>
            <a href="<?= $base ?>/sell.php">Sell Clothing</a>
        </div>
        <div class="footer-col">
            <h4>Administration</h4>
            <a href="<?= $base ?>/admin/login.php">Admin Login</a>
            <a href="<?= $base ?>/admin/dashboard.php">Admin Dashboard</a>
            <a href="<?= $base ?>/admin/users.php">Manage Users</a>
            <a href="<?= $base ?>/admin/clothes.php">Manage Listings</a>
            <hr style="border-color:rgba(255,255,255,0.1);margin:0.75rem 0;">
            <a href="<?= $base ?>/loadClothingStore.php" style="color:#ffc107;">&#9888; Setup Database</a>
            <a href="<?= $base ?>/createTable.php" style="color:#ffc107;">&#9888; Reload Users</a>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> Pastimes &mdash; Second-Hand Clothing Store &mdash; WEDE6021/w Assignment &mdash; ClothingStore Database</p>
    </div>
</footer>

<script src="<?= $base ?>/js/main.js"></script>
</body>
</html>
