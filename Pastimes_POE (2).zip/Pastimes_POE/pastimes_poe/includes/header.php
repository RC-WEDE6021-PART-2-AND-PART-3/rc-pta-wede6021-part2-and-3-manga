<?php
/*
 * Student Name: [Your Name]
 * Student Number: [Your Student Number]
 * Declaration: This code is my own work where not referenced.
 *
 * header.php - Site-wide header and navigation partial
 */

require_once __DIR__ . '/session.php';
$user  = getLoggedInUser();
$flash = getFlash();
$base  = '/pastimes_poe';

// Count cart items for badge
$cartCount = 0;
if ($user) {
    require_once __DIR__ . '/DBConn.php';
    $uid = (int)$user['id'];
    $r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM tblCartItem ci
         JOIN tblCart ca ON ci.CartID = ca.CartID
         WHERE ca.BuyerID = $uid");
    if ($r) $cartCount = mysqli_fetch_assoc($r)['c'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | Pastimes' : 'Pastimes — Premium Second-Hand Fashion' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= $base ?>/css/style.css">
</head>
<body>

<!-- ======= NAVBAR ======= -->
<header class="site-header">
    <div class="header-top">
        <span>Free delivery on orders over R500 &nbsp;|&nbsp; Verified sellers only</span>
    </div>
    <nav class="navbar">
        <div class="nav-container">
            <!-- BRAND -->
            <a href="<?= $base ?>/index.php" class="brand">
                <div class="brand-logo">P</div>
                <div>
                    <div class="brand-name">Pastimes</div>
                    <div class="brand-tagline">Second-Hand Fashion</div>
                </div>
            </a>

            <!-- SEARCH -->
            <form action="<?= $base ?>/shop.php" method="GET" class="nav-search">
                <input type="text" name="q" placeholder="Search brands, items..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
                <button type="submit">&#128269;</button>
            </form>

            <!-- NAV LINKS -->
            <div class="nav-actions">
                <?php if ($user): ?>
                    <a href="<?= $base ?>/cart.php" class="nav-icon-btn" title="Cart">
                        &#128722;
                        <?php if ($cartCount > 0): ?>
                            <span class="nav-badge"><?= $cartCount ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="<?= $base ?>/messages.php" class="nav-icon-btn" title="Messages">&#9993;</a>
                    <div class="nav-user-menu">
                        <button class="nav-user-btn" onclick="this.parentElement.classList.toggle('open')">
                            <span class="user-avatar"><?= strtoupper(substr($user['name'],0,1)) ?></span>
                            <?= htmlspecialchars(explode(' ',$user['name'])[0]) ?> &#9660;
                        </button>
                        <div class="nav-dropdown">
                            <a href="<?= $base ?>/dashboard.php">&#128100; My Dashboard</a>
                            <?php if (in_array($user['role'],['seller','both']) && $user['seller_verified']): ?>
                            <a href="<?= $base ?>/sell.php">&#43; List an Item</a>
                            <?php endif; ?>
                            <a href="<?= $base ?>/cart.php">&#128722; Shopping Cart <?= $cartCount > 0 ? "($cartCount)" : '' ?></a>
                            <a href="<?= $base ?>/messages.php">&#9993; Messages</a>
                            <hr style="border-color:#eee;margin:4px 0;">
                            <a href="<?= $base ?>/logout.php" style="color:#dc3545;">&#128682; Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= $base ?>/login.php" class="btn-nav-login">Login</a>
                    <a href="<?= $base ?>/register.php" class="btn-nav-register">Register</a>
                <?php endif; ?>
                <a href="<?= $base ?>/admin/login.php" class="btn-admin-nav" title="Admin Portal">Admin</a>
                <button class="hamburger" id="hamburger" onclick="document.getElementById('mobile-nav').classList.toggle('open')">&#9776;</button>
            </div>
        </div>

        <!-- CATEGORY NAV -->
        <div class="cat-nav">
            <div class="cat-nav-inner">
                <a href="<?= $base ?>/shop.php">All Items</a>
                <a href="<?= $base ?>/shop.php?category=tops">Tops</a>
                <a href="<?= $base ?>/shop.php?category=bottoms">Bottoms</a>
                <a href="<?= $base ?>/shop.php?category=dresses">Dresses</a>
                <a href="<?= $base ?>/shop.php?category=outerwear">Outerwear</a>
                <a href="<?= $base ?>/shop.php?category=shoes">Shoes</a>
                <a href="<?= $base ?>/shop.php?category=accessories">Accessories</a>
                <a href="<?= $base ?>/shop.php?category=sportswear">Sportswear</a>
                <a href="<?= $base ?>/shop.php?category=formal">Formal</a>
            </div>
        </div>
    </nav>

    <!-- MOBILE NAV -->
    <div class="mobile-nav" id="mobile-nav">
        <a href="<?= $base ?>/shop.php">Shop</a>
        <?php if ($user): ?>
            <a href="<?= $base ?>/dashboard.php">My Dashboard</a>
            <a href="<?= $base ?>/cart.php">Cart <?= $cartCount > 0 ? "($cartCount)" : '' ?></a>
            <a href="<?= $base ?>/messages.php">Messages</a>
            <?php if (in_array($user['role'],['seller','both']) && $user['seller_verified']): ?>
            <a href="<?= $base ?>/sell.php">Sell an Item</a>
            <?php endif; ?>
            <a href="<?= $base ?>/logout.php">Logout</a>
        <?php else: ?>
            <a href="<?= $base ?>/login.php">Login</a>
            <a href="<?= $base ?>/register.php">Register</a>
        <?php endif; ?>
        <a href="<?= $base ?>/admin/login.php">Admin Portal</a>
    </div>
</header>

<!-- ======= FLASH MESSAGE ======= -->
<?php if ($flash): ?>
<div class="flash flash-<?= htmlspecialchars($flash['type']) ?>">
    <span><?= htmlspecialchars($flash['message']) ?></span>
    <button onclick="this.parentElement.remove()" class="flash-close">&#10005;</button>
</div>
<?php endif; ?>

<!-- ======= LOGGED-IN BANNER ======= -->
<?php if ($user): ?>
<div class="logged-in-bar">
    &#10003; User <strong><?= htmlspecialchars($user['name']) ?></strong> is logged in
    <?php if ($user['status'] === 'pending'): ?>
    &nbsp;&mdash;&nbsp; <span style="color:#ffc107;">&#9888; Account pending admin verification</span>
    <?php endif; ?>
</div>
<?php endif; ?>
