<?php
/*
 * Student Name: [Your Name]
 * Student Number: [Your Student Number]
 * Module: Web Development (Intermediate) - WEDE6021/w
 * Declaration: This code is my own work where not referenced.
 *
 * DBConn.php - Establishes connection to the ClothingStore database
 * This file must be included in all scripts that require database access.
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // Change if your MySQL username differs
define('DB_PASS', '');           // Change if your MySQL password differs
define('DB_NAME', 'ClothingStore');

// Establish MySQLi connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if (!$conn) {
    die('
    <!DOCTYPE html>
    <html>
    <head><title>Connection Error</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f8f9fa; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
        .error-box { background:#fff; border:2px solid #dc3545; border-radius:10px; padding:2rem; max-width:500px; text-align:center; }
        h2 { color:#dc3545; }
        code { background:#f8f9fa; padding:4px 8px; border-radius:4px; font-size:0.85rem; }
        .steps { text-align:left; margin-top:1rem; }
        .steps li { margin:8px 0; }
        a { color:#007bff; }
    </style>
    </head>
    <body>
    <div class="error-box">
        <h2>&#10060; Database Connection Failed</h2>
        <p><strong>Error:</strong> ' . mysqli_connect_error() . '</p>
        <div class="steps">
            <p><strong>To fix this:</strong></p>
            <ol>
                <li>Open <strong>XAMPP Control Panel</strong></li>
                <li>Start <strong>Apache</strong> and <strong>MySQL</strong></li>
                <li>Open <a href="http://localhost/phpmyadmin">phpMyAdmin</a></li>
                <li>Create database named <code>ClothingStore</code></li>
                <li>Import <code>myClothingStore.sql</code></li>
                <li>Or visit <a href="/pastimes_poe/loadClothingStore.php">Setup Database</a></li>
            </ol>
        </div>
    </div>
    </body></html>');
}

// Set character encoding
mysqli_set_charset($conn, 'utf8mb4');
?>
