<?php
/*
 * Student Name: [Your Name]
 * Student Number: [Your Student Number]
 * Declaration: This code is my own work where not referenced.
 *
 * session.php - Manages user sessions and authentication helpers
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ─── USER AUTH ───────────────────────────────────────────────
function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function requireUserLogin() {
    if (!isUserLoggedIn()) {
        header('Location: /pastimes_poe/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        header('Location: /pastimes_poe/admin/login.php');
        exit;
    }
}

function getLoggedInUser() {
    if (!isUserLoggedIn()) return null;
    return [
        'id'              => $_SESSION['user_id'],
        'name'            => $_SESSION['user_name'],
        'username'        => $_SESSION['user_username'],
        'email'           => $_SESSION['user_email'],
        'role'            => $_SESSION['user_role'],
        'status'          => $_SESSION['user_status'],
        'seller_verified' => $_SESSION['seller_verified'] ?? 0,
    ];
}

// ─── FLASH MESSAGES ──────────────────────────────────────────
function flashMessage($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $msg];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// ─── INPUT HELPERS ───────────────────────────────────────────
function sanitize($conn, $value) {
    return mysqli_real_escape_string($conn, htmlspecialchars(strip_tags(trim($value))));
}

function hashPassword($password) {
    return md5($password); // MD5 hash as required by POE spec
}
?>
