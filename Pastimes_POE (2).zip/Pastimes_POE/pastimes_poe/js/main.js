/*
 * main.js — Pastimes Frontend JavaScript
 * WEDE6021/w POE
 */

document.addEventListener('DOMContentLoaded', function () {

    // ── AUTO-DISMISS FLASH MESSAGES ──────────────────────────
    const flashes = document.querySelectorAll('.flash');
    flashes.forEach(function (el) {
        setTimeout(function () {
            el.style.transition = 'opacity 0.5s';
            el.style.opacity = '0';
            setTimeout(function () { el.remove(); }, 500);
        }, 5000);
    });

    // ── CLOSE DROPDOWNS ON OUTSIDE CLICK ────────────────────
    document.addEventListener('click', function (e) {
        const menus = document.querySelectorAll('.nav-user-menu.open');
        menus.forEach(function (m) {
            if (!m.contains(e.target)) m.classList.remove('open');
        });
    });

    // ── PASSWORD STRENGTH METER ───────────────────────────────
    const passInput = document.getElementById('password');
    const strengthEl = document.getElementById('pass-strength');
    if (passInput && strengthEl) {
        passInput.addEventListener('input', function () {
            const v = passInput.value;
            let score = 0;
            if (v.length >= 8) score++;
            if (/[A-Z]/.test(v)) score++;
            if (/[0-9]/.test(v)) score++;
            if (/[^A-Za-z0-9]/.test(v)) score++;
            const labels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
            const colors = ['', '#dc3545', '#ffc107', '#17a2b8', '#28a745'];
            strengthEl.textContent = v.length > 0 ? '— ' + labels[score] : '';
            strengthEl.style.color = colors[score];
        });
    }

    // ── CONFIRM PASSWORD MATCH ────────────────────────────────
    const confirmInput = document.getElementById('confirm_password');
    if (passInput && confirmInput) {
        function checkMatch() {
            if (confirmInput.value && confirmInput.value !== passInput.value) {
                confirmInput.classList.add('error');
                let err = document.getElementById('confirm-error');
                if (!err) {
                    err = document.createElement('div');
                    err.id = 'confirm-error';
                    err.className = 'form-error';
                    err.textContent = '✗ Passwords do not match';
                    confirmInput.parentElement.appendChild(err);
                }
            } else {
                confirmInput.classList.remove('error');
                const err = document.getElementById('confirm-error');
                if (err) err.remove();
            }
        }
        confirmInput.addEventListener('input', checkMatch);
        passInput.addEventListener('input', checkMatch);
    }

    // ── IMAGE PREVIEW ─────────────────────────────────────────
    const imgInput = document.getElementById('image');
    const preview = document.getElementById('img-preview');
    if (imgInput && preview) {
        imgInput.addEventListener('change', function () {
            const file = imgInput.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // ── MODAL HELPERS ─────────────────────────────────────────
    window.openModal = function (id) {
        document.getElementById(id).classList.add('open');
    };
    window.closeModal = function (id) {
        document.getElementById(id).classList.remove('open');
    };
    // Close modal on overlay click
    document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) overlay.classList.remove('open');
        });
    });

    // ── CONFIRM DIALOGS ───────────────────────────────────────
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!confirm(el.dataset.confirm)) e.preventDefault();
        });
    });
});
