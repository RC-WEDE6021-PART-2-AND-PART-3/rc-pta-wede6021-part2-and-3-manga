-- ============================================================
-- myClothingStore.sql
-- Pastimes — Second-Hand Clothing Store
-- WEDE6021/w POE Assignment
-- Student Name: [Your Name]
-- Student Number: [Your Student Number]
-- Declaration: This code is my own work where not referenced.
--
-- Full DDL statements + 30 entries per base table
-- Import this file into phpMyAdmin or run via MySQL console
-- ============================================================

-- Create and select database
CREATE DATABASE IF NOT EXISTS ClothingStore
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE ClothingStore;

-- Drop all tables in reverse FK order
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS tblMessage;
DROP TABLE IF EXISTS tblCartItem;
DROP TABLE IF EXISTS tblCart;
DROP TABLE IF EXISTS tblAorder;
DROP TABLE IF EXISTS tblClothes;
DROP TABLE IF EXISTS tblAdmin;
DROP TABLE IF EXISTS tblUser;
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- TABLE: tblUser
-- Stores all registered customers (buyers and sellers)
-- ============================================================
CREATE TABLE tblUser (
    UserID         INT           NOT NULL AUTO_INCREMENT,
    Name           VARCHAR(100)  NOT NULL,
    Email          VARCHAR(150)  NOT NULL,
    Username       VARCHAR(50)   NOT NULL,
    PasswordHash   VARCHAR(255)  NOT NULL COMMENT 'MD5 hashed password',
    Role           ENUM('buyer','seller','both') NOT NULL DEFAULT 'buyer',
    Status         ENUM('pending','verified','suspended') NOT NULL DEFAULT 'pending',
    SellerVerified TINYINT(1)    NOT NULL DEFAULT 0,
    Address        TEXT,
    ProfileImage   VARCHAR(255),
    CreatedAt      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (UserID),
    UNIQUE KEY uk_email    (Email),
    UNIQUE KEY uk_username (Username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Registered users — buyers and sellers';

-- ============================================================
-- TABLE: tblAdmin
-- Stores administrator accounts
-- ============================================================
CREATE TABLE tblAdmin (
    AdminID      INT          NOT NULL AUTO_INCREMENT,
    Name         VARCHAR(100) NOT NULL,
    Email        VARCHAR(150) NOT NULL,
    Username     VARCHAR(50)  NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL COMMENT 'MD5 hashed password',
    CreatedAt    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (AdminID),
    UNIQUE KEY uk_admin_email    (Email),
    UNIQUE KEY uk_admin_username (Username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Administrator accounts';

-- ============================================================
-- TABLE: tblClothes
-- Stores clothing listings submitted by sellers
-- ============================================================
CREATE TABLE tblClothes (
    ClothesID   INT            NOT NULL AUTO_INCREMENT,
    SellerID    INT            NOT NULL,
    Title       VARCHAR(150)   NOT NULL,
    Description TEXT,
    Brand       VARCHAR(100)   NOT NULL,
    Size        VARCHAR(20),
    Price       DECIMAL(10,2)  NOT NULL,
    ImagePath   VARCHAR(255),
    Category    VARCHAR(50),
    `Condition` ENUM('new','like_new','good','fair') NOT NULL DEFAULT 'good',
    Status      ENUM('pending','approved','sold','removed') NOT NULL DEFAULT 'pending',
    CreatedAt   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (ClothesID),
    CONSTRAINT fk_clothes_seller FOREIGN KEY (SellerID)
        REFERENCES tblUser(UserID) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Clothing listings';

-- ============================================================
-- TABLE: tblCart
-- One cart per buyer user
-- ============================================================
CREATE TABLE tblCart (
    CartID    INT      NOT NULL AUTO_INCREMENT,
    BuyerID   INT      NOT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (CartID),
    CONSTRAINT fk_cart_buyer FOREIGN KEY (BuyerID)
        REFERENCES tblUser(UserID) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Shopping carts';

-- ============================================================
-- TABLE: tblCartItem
-- Items inside a cart
-- ============================================================
CREATE TABLE tblCartItem (
    CartItemID INT      NOT NULL AUTO_INCREMENT,
    CartID     INT      NOT NULL,
    ClothesID  INT      NOT NULL,
    Quantity   INT      NOT NULL DEFAULT 1,
    AddedAt    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (CartItemID),
    CONSTRAINT fk_cartitem_cart FOREIGN KEY (CartID)
        REFERENCES tblCart(CartID) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_cartitem_clothes FOREIGN KEY (ClothesID)
        REFERENCES tblClothes(ClothesID) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Items in shopping carts';

-- ============================================================
-- TABLE: tblAorder
-- Purchase orders placed by buyers
-- ============================================================
CREATE TABLE tblAorder (
    OrderID         INT           NOT NULL AUTO_INCREMENT,
    BuyerID         INT           NOT NULL,
    ClothesID       INT           NOT NULL,
    SellerID        INT           NOT NULL,
    AdminID         INT,
    Quantity        INT           NOT NULL DEFAULT 1,
    TotalPrice      DECIMAL(10,2) NOT NULL,
    Status          ENUM('pending','confirmed','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
    ShippingAddress TEXT,
    Notes           TEXT          COMMENT 'Admin liaison notes between buyer and seller',
    OrderDate       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (OrderID),
    CONSTRAINT fk_order_buyer   FOREIGN KEY (BuyerID)   REFERENCES tblUser(UserID),
    CONSTRAINT fk_order_clothes FOREIGN KEY (ClothesID) REFERENCES tblClothes(ClothesID),
    CONSTRAINT fk_order_seller  FOREIGN KEY (SellerID)  REFERENCES tblUser(UserID),
    CONSTRAINT fk_order_admin   FOREIGN KEY (AdminID)   REFERENCES tblAdmin(AdminID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Purchase orders';

-- ============================================================
-- TABLE: tblMessage
-- Messages between buyers and sellers
-- ============================================================
CREATE TABLE tblMessage (
    MessageID  INT      NOT NULL AUTO_INCREMENT,
    SenderID   INT      NOT NULL,
    ReceiverID INT      NOT NULL,
    ClothesID  INT,
    Subject    VARCHAR(200),
    Body       TEXT     NOT NULL,
    IsRead     TINYINT(1) NOT NULL DEFAULT 0,
    SentAt     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (MessageID),
    CONSTRAINT fk_msg_sender   FOREIGN KEY (SenderID)   REFERENCES tblUser(UserID),
    CONSTRAINT fk_msg_receiver FOREIGN KEY (ReceiverID) REFERENCES tblUser(UserID),
    CONSTRAINT fk_msg_clothes  FOREIGN KEY (ClothesID)  REFERENCES tblClothes(ClothesID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Buyer-seller messaging';

-- ============================================================
-- SEED DATA: tblAdmin (5 entries)
-- All passwords = admin1234
-- ============================================================
INSERT INTO tblAdmin (Name, Email, Username, PasswordHash) VALUES
('Super Admin',        'admin@pastimes.co.za',        'superadmin',   MD5('admin1234')),
('Jane Administrator', 'jane@pastimes.co.za',          'janeadmin',    MD5('admin1234')),
('Sipho Modise',       'sipho.admin@pastimes.co.za',   'sipho_admin',  MD5('admin1234')),
('Nomvula Dlamini',    'nomvula.admin@pastimes.co.za', 'nomvula_admin',MD5('admin1234')),
('Thabo Mkhize',       'thabo.admin@pastimes.co.za',   'thabo_admin',  MD5('admin1234'));

-- ============================================================
-- SEED DATA: tblUser (30 entries)
-- All passwords = Password1
-- MD5('Password1') = 7c6a180b36896a0a8c02787eeafb0e4c
-- ============================================================
INSERT INTO tblUser (Name, Email, Username, PasswordHash, Role, Status, SellerVerified) VALUES
('Amelia Dlamini',    'amelia.dlamini@email.com',      'amelia_d',    MD5('Password1'), 'buyer',  'verified', 0),
('Sipho Nkosi',       'sipho.nkosi@gmail.com',          'sipho_n',     MD5('Password1'), 'seller', 'verified', 1),
('Zanele Mokoena',    'zanele.m@webmail.co.za',         'zanele_m',    MD5('Password1'), 'buyer',  'verified', 0),
('Lethiwe Khumalo',   'lethiwe.k@outlook.com',          'lethiwe_k',   MD5('Password1'), 'both',   'verified', 1),
('Rethabile Sithole', 'rethi.sithole@yahoo.com',        'rethi_s',     MD5('Password1'), 'seller', 'verified', 1),
('Kagiso Mahlangu',   'kagiso.m@gmail.com',             'kagiso_m',    MD5('Password1'), 'buyer',  'pending',  0),
('Nomsa Zwane',       'nomsa.zwane@email.com',          'nomsa_z',     MD5('Password1'), 'buyer',  'verified', 0),
('Thabo Radebe',      'thabo.r@icloud.com',             'thabo_r',     MD5('Password1'), 'seller', 'pending',  0),
('Palesa Ntuli',      'palesa.ntuli@live.com',          'palesa_n',    MD5('Password1'), 'buyer',  'verified', 0),
('Bongani Cele',      'bongani.cele@gmail.com',         'bongani_c',   MD5('Password1'), 'both',   'verified', 1),
('Lungelo Mthembu',   'lungelo.m@gmail.com',            'lungelo_m',   MD5('Password1'), 'buyer',  'verified', 0),
('Ayanda Zulu',       'ayanda.z@hotmail.com',           'ayanda_z',    MD5('Password1'), 'seller', 'verified', 1),
('Precious Molefe',   'precious.mol@gmail.com',         'precious_m',  MD5('Password1'), 'buyer',  'verified', 0),
('Sandile Khumalo',   'sandile.k@outlook.com',          'sandile_k',   MD5('Password1'), 'both',   'verified', 1),
('Nokuthula Mhlongo', 'nokuthula.m@gmail.com',          'nokuthula_m', MD5('Password1'), 'buyer',  'verified', 0),
('Mbali Nzama',       'mbali.nzama@webmail.co.za',      'mbali_n',     MD5('Password1'), 'seller', 'verified', 1),
('Sifiso Shabalala',  'sifiso.s@gmail.com',             'sifiso_s',    MD5('Password1'), 'buyer',  'pending',  0),
('Nandi Gumbi',       'nandi.g@email.com',              'nandi_g',     MD5('Password1'), 'buyer',  'verified', 0),
('Lwazi Ndlovu',      'lwazi.nd@gmail.com',             'lwazi_nd',    MD5('Password1'), 'seller', 'verified', 1),
('Hlengiwe Majola',   'hlengiwe.maj@yahoo.com',         'hlengiwe_m',  MD5('Password1'), 'buyer',  'verified', 0),
('Mpendulo Cele',     'mpendulo.c@gmail.com',           'mpendulo_c',  MD5('Password1'), 'both',   'verified', 1),
('Nokukhanya Dube',   'nokukhanya.d@gmail.com',         'nokukhanya',  MD5('Password1'), 'buyer',  'verified', 0),
('Sfiso Mthethwa',    'sfiso.mt@email.com',             'sfiso_mt',    MD5('Password1'), 'seller', 'pending',  0),
('Thandeka Mthembu',  'thandeka.mt@live.com',           'thandeka_mt', MD5('Password1'), 'buyer',  'verified', 0),
('Buhle Mhlongo',     'buhle.mhl@gmail.com',            'buhle_mhl',   MD5('Password1'), 'both',   'verified', 1),
('Ntokozo Mkhize',    'ntokozo.mk@gmail.com',           'ntokozo_mk',  MD5('Password1'), 'buyer',  'verified', 0),
('Simphiwe Gumede',   'simphiwe.g@webmail.co.za',       'simphiwe_g',  MD5('Password1'), 'seller', 'verified', 1),
('Zanele Dlamini',    'zanele.dl@outlook.com',          'zanele_dl',   MD5('Password1'), 'buyer',  'pending',  0),
('Mthokozisi Ngema',  'mthokozisi.n@gmail.com',         'mthokozisi',  MD5('Password1'), 'seller', 'verified', 1),
('Khanyisile Mabaso', 'khanyisile.m@yahoo.com',         'khanyisile',  MD5('Password1'), 'buyer',  'verified', 0);

-- ============================================================
-- SEED DATA: tblClothes (30 entries)
-- SellerIDs reference verified sellers in tblUser
-- ============================================================
INSERT INTO tblClothes (SellerID,Title,Description,Brand,Size,Price,Category,`Condition`,Status) VALUES
(2,  'Blue Slim-Fit Chinos',        'Barely worn slim chinos, no marks or fading.',                'Polo',            '32',      450.00,  'bottoms',     'like_new', 'approved'),
(2,  'White Linen Button Shirt',    'Classic summer linen shirt, worn twice.',                     'H&M',             'M',       180.00,  'tops',        'good',     'approved'),
(4,  'Black Leather Biker Jacket',  'Genuine leather jacket with silver zip detail.',              'Zara',            'S',      1200.00,  'outerwear',   'like_new', 'approved'),
(4,  'Floral Wrap Midi Dress',      'Beautiful floral wrap dress, feminine and elegant.',          'Woolworths',      'M',       350.00,  'dresses',     'like_new', 'approved'),
(5,  'Nike Air Max 90 Sneakers',    'White and grey. Size 9. Minimal wear on soles.',              'Nike',            '9',       950.00,  'shoes',       'good',     'approved'),
(5,  'Adidas Grey Pullover Hoodie', 'Cosy fleece hoodie, great for casual or gym use.',            'Adidas',          'L',       280.00,  'tops',        'good',     'approved'),
(10, 'Vintage Levi 501 Jeans',      'Classic straight-cut 501s with authentic vintage wash.',     'Levi\'s',         '30',      680.00,  'bottoms',     'good',     'approved'),
(10, 'Red North Face Puffer',       'Warm red puffer jacket, perfect for Cape Town winters.',     'The North Face',  'L',      1500.00,  'outerwear',   'like_new', 'approved'),
(12, 'Gold Hoop Earrings Set',      'Three pairs of elegant gold-toned hoops.',                   'Foschini',        'One Size', 120.00, 'accessories', 'new',      'approved'),
(12, 'Navy Striped Blazer',         'Structured navy and white striped blazer.',                  'Truworths',       'M',       550.00,  'formal',      'like_new', 'approved'),
(14, 'Nike High-Waist Running Tights','Compression tights with hidden phone pocket.',             'Nike',            'S',       320.00,  'sportswear',  'good',     'approved'),
(14, 'Classic Denim Mini Skirt',    'Blue denim mini, size 10. Versatile and timeless.',          'Mr Price',        '10',      190.00,  'bottoms',     'good',     'approved'),
(16, 'Cream Chunky Knit Sweater',   'Oversized chunky knit in warm cream, very cosy.',            'Zara',            'L',       380.00,  'tops',        'like_new', 'approved'),
(16, 'Black Block Heel Ankle Boots','Faux leather ankle boots, 5cm heel. Size 6, worn twice.',   'Edgars',          '6',       420.00,  'shoes',       'like_new', 'approved'),
(19, 'White Slim Formal Shirt',     'Smart slim-fit formal shirt, perfect for work.',             'Markham',         'L',       200.00,  'formal',      'new',      'approved'),
(19, 'Gymshark High-Waist Leggings','Four-way stretch seamless leggings. Very supportive.',      'Gymshark',        'M',       450.00,  'sportswear',  'like_new', 'approved'),
(21, 'Natural Canvas Tote Bag',     'Large beige canvas tote with long handles.',                 'Cotton On',       'One Size', 80.00,  'accessories', 'good',     'approved'),
(21, 'Olive Army Cargo Pants',      'Relaxed fit olive cargo pants with multiple pockets.',      'H&M',             '34',      360.00,  'bottoms',     'good',     'approved'),
(25, 'Blush Silk Slip Dress',       'Stunning blush silk slip dress, midi length. Pure luxury.', 'Zara',            'S',       750.00,  'dresses',     'like_new', 'approved'),
(25, 'Vintage Graphic Oversized Tee','Washed vintage-look print tee in faded black.',            'Urban Outfitters','L',       220.00,  'tops',        'good',     'approved'),
(27, 'Camel Double-Breasted Trench','Classic camel trench coat, timeless style.',                'Polo',            'M',      1100.00,  'outerwear',   'good',     'approved'),
(27, 'White Leather Reebok Classics','Clean white leather sneakers, barely worn.',               'Reebok',          '8',       580.00,  'shoes',       'like_new', 'approved'),
(29, 'Black Pleated Midi Skirt',    'Elegant black pleated midi, versatile office-to-evening.',  'Woolworths',      '12',      310.00,  'bottoms',     'new',      'approved'),
(29, 'Woven Leather Belt',          'Brown woven genuine leather belt. Waist 28-34 inches.',     'Markham',         'One Size', 140.00, 'accessories', 'good',     'approved'),
(2,  'Forest Green Polo Neck',      'Fine-knit polo neck jumper in a rich forest green.',        'Polo',            'M',       290.00,  'tops',        'good',     'pending'),
(4,  'Dusty Rose Palazzo Pants',    'Flowy wide-leg palazzo trousers, very flattering cut.',     'Zara',            'S',       420.00,  'bottoms',     'like_new', 'pending'),
(5,  'Olive Green Bomber Jacket',   'Classic bomber with ribbed cuffs and hem.',                 'H&M',             'L',       480.00,  'outerwear',   'good',     'pending'),
(10, 'Black Platform Sandals',      'Black faux-leather platforms, 5cm heel. Size 5.',           'Edgars',          '5',       260.00,  'shoes',       'good',     'pending'),
(12, 'Coral Nike Sports Bra',       'High-support sports bra in coral. Worn a few times.',      'Nike',            'S',       200.00,  'sportswear',  'good',     'pending'),
(14, 'Colourful Boho Bead Necklace','Statement beaded necklace in mixed earthy tones.',         'Lovisa',          'One Size', 95.00,  'accessories', 'new',      'pending');

-- ============================================================
-- SEED DATA: tblCart (30 entries)
-- ============================================================
INSERT INTO tblCart (BuyerID) VALUES
(1),(3),(6),(7),(9),(11),(13),(15),(18),(20),
(22),(24),(26),(28),(30),(1),(3),(7),(9),(11),
(13),(15),(18),(20),(22),(24),(26),(28),(30),(6);

-- ============================================================
-- SEED DATA: tblAorder (30 entries)
-- ============================================================
INSERT INTO tblAorder (BuyerID,ClothesID,SellerID,AdminID,Quantity,TotalPrice,Status,ShippingAddress,Notes) VALUES
(1,  1,  2,  1, 1,  450.00, 'delivered',  '12 Oak Street, Sandton, GP 2196',          'Delivered on time. Buyer confirmed receipt.'),
(3,  3,  4,  1, 1, 1200.00, 'delivered',  '45 Jacaranda Ave, Pretoria, GP 0002',       'Item in excellent condition as described.'),
(7,  5,  5,  2, 1,  950.00, 'shipped',    '88 Long Street, Cape Town, WC 8001',        'Shipped via Courier Guy. Tracking: CG123456.'),
(9,  7,  10, 1, 1,  680.00, 'confirmed',  '3 Rosebank Mall, JHB, GP 2196',             'Order confirmed. Arranging pickup from seller.'),
(11, 9,  12, 2, 1,  120.00, 'delivered',  '7 Beach Road, Durban, KZN 4001',            'Fast delivery. Buyer very happy with earrings.'),
(13, 11, 14, 1, 1,  320.00, 'pending',    '102 Smith St, Pietermaritzburg, KZN 3201',  NULL),
(15, 13, 16, 2, 1,  380.00, 'shipped',    '5 Berea Road, Durban, KZN 4001',            'Dispatched via PostNet. ETA 2 days.'),
(18, 15, 19, 1, 1,  200.00, 'delivered',  '21 Church St, Pretoria CBD, GP 0002',       'Formal shirt in perfect condition.'),
(20, 17, 21, 2, 1,   80.00, 'delivered',  '33 Soweto Highway, Soweto, GP 1804',        'Tote bag delivered, buyer satisfied.'),
(22, 19, 25, 1, 1,  750.00, 'confirmed',  '9 V&A Waterfront, Cape Town, WC 8002',      'Silk dress confirmed. Packaging carefully.'),
(24, 21, 27, 2, 1, 1100.00, 'pending',    '17 Main Road, Paarl, WC 7646',              NULL),
(26, 23, 29, 1, 1,  310.00, 'delivered',  '55 Kruger St, Polokwane, LP 0700',          'Skirt delivered in perfect condition.'),
(28, 2,  2,  2, 1,  180.00, 'shipped',    '4 Boom St, Bloemfontein, FS 9301',          'Sent via Aramex. Buyer notified.'),
(30, 4,  4,  1, 1,  350.00, 'delivered',  '11 Marine Parade, East London, EC 5241',    'Buyer confirmed floral dress received.'),
(1,  6,  5,  2, 1,  280.00, 'delivered',  '12 Oak Street, Sandton, GP 2196',           'Second order from this buyer. Smooth transaction.'),
(3,  8,  10, 1, 1, 1500.00, 'confirmed',  '45 Jacaranda Ave, Pretoria, GP 0002',       'North Face puffer confirmed.'),
(7,  10, 12, 2, 1,  550.00, 'shipped',    '88 Long Street, Cape Town, WC 8001',        'Blazer dispatched via Courier Guy.'),
(9,  12, 14, 1, 1,  190.00, 'delivered',  '3 Rosebank Mall, JHB, GP 2196',             'Denim skirt received, fits perfectly.'),
(11, 14, 16, 2, 1,  420.00, 'pending',    '7 Beach Road, Durban, KZN 4001',            NULL),
(13, 16, 19, 1, 1,  450.00, 'delivered',  '102 Smith St, Pietermaritzburg, KZN 3201',  'Gymshark leggings. Buyer very happy.'),
(15, 18, 21, 2, 1,  360.00, 'shipped',    '5 Berea Road, Durban, KZN 4001',            'Cargo pants on the way.'),
(18, 20, 25, 1, 1,  220.00, 'delivered',  '21 Church St, Pretoria CBD, GP 0002',       'Graphic tee delivered. Smooth.'),
(20, 22, 27, 2, 1,  580.00, 'cancelled',  '33 Soweto Highway, Soweto, GP 1804',        'Buyer cancelled — size issue. Refund processed.'),
(22, 24, 29, 1, 1,  140.00, 'delivered',  '9 V&A Waterfront, Cape Town, WC 8002',      'Belt delivered, fits perfectly.'),
(24, 1,  2,  2, 1,  450.00, 'pending',    '17 Main Road, Paarl, WC 7646',              NULL),
(26, 3,  4,  1, 1, 1200.00, 'confirmed',  '55 Kruger St, Polokwane, LP 0700',          'Second jacket sale confirmed.'),
(28, 5,  5,  2, 1,  950.00, 'shipped',    '4 Boom St, Bloemfontein, FS 9301',          'Nike shoes shipped. Buyer tracking.'),
(30, 7,  10, 1, 1,  680.00, 'delivered',  '11 Marine Parade, East London, EC 5241',    'Levi\'s jeans. Excellent condition confirmed.'),
(1,  9,  12, 2, 1,  120.00, 'delivered',  '12 Oak Street, Sandton, GP 2196',           'Earrings. Third order from this buyer.'),
(3,  11, 14, 1, 1,  320.00, 'shipped',    '45 Jacaranda Ave, Pretoria, GP 0002',       'Running tights shipped today.');

-- ============================================================
-- SEED DATA: tblMessage (30 entries)
-- ============================================================
INSERT INTO tblMessage (SenderID,ReceiverID,ClothesID,Subject,Body,IsRead) VALUES
(1,  2,  1,  'Question about chinos',          'Hi, are the chinos still available? Would you accept R400?', 1),
(3,  4,  3,  'Leather jacket condition',        'Is the leather jacket in good condition? Any scratches or marks?', 0),
(7,  5,  5,  'Nike Air Max size query',         'Do these Nikes run true to size? I normally wear size 9.', 1),
(9,  10, 7,  'Levi jeans availability',         'Hi, are the Levi 501s still available for purchase?', 1),
(11, 12, 9,  'Earring material query',          'Are these earrings real gold or gold-toned? I have sensitive ears.', 0),
(13, 14, 11, 'Running tights offer',            'Would you accept R280 for the running tights?', 1),
(15, 16, 13, 'Sweater colour question',         'Is the colour exactly cream or more of an off-white?', 0),
(18, 19, 15, 'Shirt fit question',              'Is this shirt slim fit or regular fit? I need exact measurements.', 1),
(20, 21, 17, 'Tote bag washable',               'Can this tote bag be machine washed?', 1),
(22, 25, 19, 'Silk dress sizing',               'The silk dress looks beautiful! Is it true to a size small?', 0),
(24, 27, 21, 'Trench coat lining',              'Is the lining intact? Any missing buttons on the trench coat?', 1),
(26, 29, 23, 'Pleated skirt hold request',      'I love this skirt! Can you hold it for me until Friday?', 0),
(28, 2,  2,  'White linen shirt condition',     'Does the linen shirt have any stains or wear marks?', 1),
(30, 4,  4,  'Floral dress size query',         'Is the floral wrap dress true to a medium? I am usually an M.', 0),
(1,  5,  6,  'Hoodie washing info',             'Is the grey hoodie washed and ready to ship?', 1),
(3,  10, 8,  'Puffer jacket filling',           'Is the filling still fluffy or has it compressed over time?', 0),
(7,  12, 10, 'Blazer pockets question',         'Does the striped blazer have pockets? Pockets are important!', 1),
(9,  14, 12, 'Denim skirt sizing',              'Is a size 10 in this brand equivalent to a medium?', 1),
(11, 16, 14, 'Boot size guide',                 'Size 6 — does Edgars run small or true to size?', 0),
(13, 19, 16, 'Leggings waistband',              'Is the waistband high-rise or mid-rise on the Gymshark leggings?', 1),
(15, 21, 18, 'Cargo pants inseam',              'What is the inseam measurement on the cargo pants please?', 0),
(18, 25, 20, 'Graphic tee print quality',       'Is the print cracking at all or still sharp and clear?', 1),
(20, 27, 22, 'Reebok sole yellowing',           'Any yellowing on the soles of the Reeboks?', 1),
(22, 29, 24, 'Belt waist measurement',          'Does the woven leather belt fit a 32 inch waist comfortably?', 0),
(24, 2,  1,  'Chinos colour after washing',     'Have the chinos faded at all after being washed?', 1),
(26, 4,  3,  'Jacket storage smell',            'Has the jacket been stored? Does it have any musty smell?', 0),
(28, 5,  5,  'Nike box and accessories',        'Do the Nike shoes come with the original box and laces?', 1),
(30, 10, 7,  'Jeans waist measurement cm',      'What is the actual waist measurement in centimetres?', 0),
(1,  12, 9,  'Earrings hypoallergenic',         'Are the gold hoop earrings hypoallergenic? Sensitive ears.', 1),
(3,  14, 11, 'Tights compression level',        'What compression level are the running tights — light or firm?', 0);
