<?php
/*
 * Student Name: [DUMISA]
 * Student Number: [ST10445334]
 * Declaration: This code is my own work where not referenced.
 * shop.php - Browse clothing listings
 */

$pageTitle = 'Shop';
require_once 'includes/session.php';
require_once 'includes/DBConn.php';

$base = '/pastimes_poe';

$category = $_GET['category'] ?? '';
$brand    = $_GET['brand']    ?? '';
$search   = $_GET['q']        ?? '';
$sort     = $_GET['sort']     ?? 'newest';
$minPrice = $_GET['min']      ?? '';
$maxPrice = $_GET['max']      ?? '';

// Build WHERE clause
$where = ["c.Status = 'approved'"];
if ($category) $where[] = "c.Category = '" . mysqli_real_escape_string($conn, $category) . "'";
if ($brand)    $where[] = "c.Brand LIKE '%" . mysqli_real_escape_string($conn, $brand) . "%'";
if ($search)   $where[] = "(c.Title LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'
                          OR c.Brand LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'
                          OR c.Description LIKE '%" . mysqli_real_escape_string($conn, $search) . "%')";
if ($minPrice) $where[] = "c.Price >= " . (float)$minPrice;
if ($maxPrice) $where[] = "c.Price <= " . (float)$maxPrice;

$orderBy = match($sort) {
    'price_asc'  => 'c.Price ASC',
    'price_desc' => 'c.Price DESC',
    'oldest'     => 'c.CreatedAt ASC',
    default      => 'c.CreatedAt DESC'
};

$whereStr = implode(' AND ', $where);
$result = mysqli_query($conn,
    "SELECT c.*, u.Name AS SellerName
     FROM tblClothes c
     JOIN tblUser u ON c.SellerID = u.UserID
     WHERE $whereStr
     ORDER BY $orderBy");

$total  = $result ? mysqli_num_rows($result) : 0;
$cats   = mysqli_query($conn, "SELECT DISTINCT Category FROM tblClothes WHERE Status='approved' AND Category != '' ORDER BY Category");
$brands = mysqli_query($conn, "SELECT DISTINCT Brand FROM tblClothes WHERE Status='approved' ORDER BY Brand");

require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner flex justify-between items-center flex-wrap" style="gap:1rem;">
        <div>
            <div class="breadcrumb"><a href="<?= $base ?>">Home</a> &rsaquo; Shop</div>
            <h1>
                <?= $category ? ucfirst($category) : ($search ? "Search: \"$search\"" : 'All Clothing') ?>
            </h1>
            <p><?= $total ?> item<?= $total !== 1 ? 's' : '' ?> found</p>
        </div>
    </div>
</div>

<!-- FILTER BAR -->
<div class="filter-bar">
<form method="GET" class="filter-form" id="filter-form">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
           placeholder="Search brands, items..." style="flex:1;min-width:160px;">

    <select name="category" onchange="document.getElementById('filter-form').submit()">
        <option value="">All Categories</option>
        <?php while ($c = mysqli_fetch_assoc($cats)): ?>
        <option value="<?= htmlspecialchars($c['Category']) ?>" <?= $category === $c['Category'] ? 'selected' : '' ?>>
            <?= ucfirst($c['Category']) ?>
        </option>
        <?php endwhile; ?>
    </select>

    <select name="brand" onchange="document.getElementById('filter-form').submit()">
        <option value="">All Brands</option>
        <?php while ($b = mysqli_fetch_assoc($brands)): ?>
        <option value="<?= htmlspecialchars($b['Brand']) ?>" <?= $brand === $b['Brand'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($b['Brand']) ?>
        </option>
        <?php endwhile; ?>
    </select>

    <select name="sort" onchange="document.getElementById('filter-form').submit()">
        <option value="newest"     <?= $sort === 'newest'     ? 'selected' : '' ?>>Newest First</option>
        <option value="price_asc"  <?= $sort === 'price_asc'  ? 'selected' : '' ?>>Price: Low &#8594; High</option>
        <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High &#8594; Low</option>
        <option value="oldest"     <?= $sort === 'oldest'     ? 'selected' : '' ?>>Oldest First</option>
    </select>

    <input type="number" name="min" value="<?= htmlspecialchars($minPrice) ?>" placeholder="Min R" style="width:90px;" min="0">
    <input type="number" name="max" value="<?= htmlspecialchars($maxPrice) ?>" placeholder="Max R" style="width:90px;" min="0">

    <button type="submit" class="btn btn-dark btn-sm">Filter</button>
    <?php if ($search || $category || $brand || $minPrice || $maxPrice): ?>
    <a href="<?= $base ?>/shop.php" class="btn btn-outline btn-sm">Clear</a>
    <?php endif; ?>
</form>
</div>

<!-- ITEMS GRID -->
<section class="section">
<div class="section-inner">
<?php if ($total === 0): ?>
    <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>No Items Found</h3>
        <p>Try adjusting your filters or search term.</p>
        <a href="<?= $base ?>/shop.php" class="btn btn-outline mt-2">Browse All</a>
    </div>
<?php else: ?>
    <div class="grid-4">
    <?php while ($item = mysqli_fetch_assoc($result)): ?>
        <a href="<?= $base ?>/product.php?id=<?= $item['ClothesID'] ?>" class="product-card">
            <div class="product-img">
                <?php if ($item['ImagePath'] && file_exists(__DIR__ . '/' . $item['ImagePath'])): ?>
                    <img src="<?= $base ?>/<?= htmlspecialchars($item['ImagePath']) ?>" alt="<?= htmlspecialchars($item['Title']) ?>">
                <?php else: ?>
                    <span class="product-img-placeholder">👗</span>
                <?php endif; ?>
                <span class="product-badge"><?= htmlspecialchars($item['Brand']) ?></span>
            </div>
            <div class="product-body">
                <div class="product-brand"><?= htmlspecialchars($item['Brand']) ?></div>
                <div class="product-title"><?= htmlspecialchars($item['Title']) ?></div>
                <div class="product-meta">
                    <?= htmlspecialchars($item['Category'] ? ucfirst($item['Category']) : '') ?>
                    &bull; Size <?= htmlspecialchars($item['Size'] ?? 'N/A') ?>
                    &bull; <?= ucwords(str_replace('_',' ', $item['Condition'])) ?>
                </div>
                <div class="product-footer">
                    <span class="product-price">R<?= number_format($item['Price'], 2) ?></span>
                    <span style="font-size:0.72rem;color:var(--muted);">by <?= htmlspecialchars($item['SellerName']) ?></span>
                </div>
            </div>
        </a>
    <?php endwhile; ?>
    </div>
<?php endif; ?>
</div>
</section>

<?php require_once 'includes/footer.php'; ?>
