<?php $base = '/pastimes_poe'; ?>
<footer style="background:#0f0700;color:rgba(255,255,255,0.3);text-align:center;padding:1rem;font-size:0.75rem;margin-top:auto;border-top:1px solid rgba(200,169,81,0.2);">
    Pastimes Admin Panel &mdash; ClothingStore Database &mdash; WEDE6021/w &mdash; <?= date('Y') ?>
</footer>
<script src="<?= $base ?>/js/main.js"></script>
</body>
</html>
