<?php
$pageTitle = 'Manage Listings';
require_once 'admin_header.php';
require_once '../includes/DBConn.php';
$base = '/pastimes_poe';
$adminId = (int)$_SESSION['admin_id'];

if (isset($_GET['approve'])) { $id=(int)$_GET['approve']; mysqli_query($conn,"UPDATE tblClothes SET Status='approved' WHERE ClothesID=$id"); flashMessage('success','Listing approved and is now live!'); header("Location: $base/admin/clothes.php"); exit; }
if (isset($_GET['remove']))  { $id=(int)$_GET['remove'];  mysqli_query($conn,"UPDATE tblClothes SET Status='removed' WHERE ClothesID=$id"); flashMessage('warning','Listing removed from shop.'); header("Location: $base/admin/clothes.php"); exit; }
if (isset($_GET['sold']))    { $id=(int)$_GET['sold'];    mysqli_query($conn,"UPDATE tblClothes SET Status='sold' WHERE ClothesID=$id"); flashMessage('info','Item marked as sold and removed from shop.'); header("Location: $base/admin/clothes.php"); exit; }
if (isset($_GET['delete']))  { $id=(int)$_GET['delete'];  mysqli_query($conn,"DELETE FROM tblClothes WHERE ClothesID=$id"); flashMessage('danger','Listing permanently deleted.'); header("Location: $base/admin/clothes.php"); exit; }

// Admin adds clothing on behalf of seller
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add_item') {
    $sid  = (int)$_POST['seller_id'];
    $t    = mysqli_real_escape_string($conn, trim($_POST['title']));
    $desc = mysqli_real_escape_string($conn, trim($_POST['description']));
    $br   = mysqli_real_escape_string($conn, trim($_POST['brand']));
    $sz   = mysqli_real_escape_string($conn, trim($_POST['size']));
    $pr   = (float)$_POST['price'];
    $cat  = mysqli_real_escape_string($conn, $_POST['category']);
    $cond = mysqli_real_escape_string($conn, $_POST['condition']);
    $st   = mysqli_real_escape_string($conn, $_POST['status'] ?? 'approved');
    mysqli_query($conn, "INSERT INTO tblClothes (SellerID,Title,Description,Brand,Size,Price,Category,\`Condition\`,Status) VALUES ($sid,'$t','$desc','$br','$sz',$pr,'$cat','$cond','$st')");
    flashMessage('success', 'Clothing item added successfully!');
    header("Location: $base/admin/clothes.php"); exit;
}

$filter = $_GET['filter'] ?? '';
$search = $_GET['q'] ?? '';
$where = ['1=1'];
if ($filter) $where[] = "c.Status='" . mysqli_real_escape_string($conn,$filter) . "'";
if ($search) { $s=mysqli_real_escape_string($conn,$search); $where[] = "(c.Title LIKE '%$s%' OR c.Brand LIKE '%$s%')"; }

$items   = mysqli_query($conn,"SELECT c.*,u.Name AS SellerName FROM tblClothes c JOIN tblUser u ON c.SellerID=u.UserID WHERE ".implode(' AND ',$where)." ORDER BY c.CreatedAt DESC");
$sellers = mysqli_query($conn,"SELECT UserID,Name,Username FROM tblUser WHERE Role IN ('seller','both') AND Status='verified' ORDER BY Name");
$total   = mysqli_num_rows($items);
?>

<section style="padding:2rem 1.5rem;">
<div style="max-width:1200px;margin:0 auto;">

    <div class="flex justify-between items-center flex-wrap" style="gap:1rem;margin-bottom:1.5rem;">
        <div>
            <h2 style="font-family:'Playfair Display',serif;font-size:1.8rem;">Manage Listings</h2>
            <p style="color:var(--muted);"><?= $total ?> listings found</p>
        </div>
        <button class="btn btn-primary" onclick="openModal('add-item-modal')">+ Add Clothing Item</button>
    </div>

    <form method="GET" style="display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.5rem;">
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search title or brand..." class="form-control" style="flex:1;min-width:200px;max-width:300px;">
        <select name="filter" class="form-control" style="width:auto;" onchange="this.form.submit()">
            <option value="">All Statuses</option>
            <option value="pending"  <?= $filter==='pending' ?'selected':'' ?>>Pending Review</option>
            <option value="approved" <?= $filter==='approved'?'selected':'' ?>>Approved</option>
            <option value="sold"     <?= $filter==='sold'    ?'selected':'' ?>>Sold</option>
            <option value="removed"  <?= $filter==='removed' ?'selected':'' ?>>Removed</option>
        </select>
        <button type="submit" class="btn btn-dark btn-sm">Filter</button>
        <a href="<?= $base ?>/admin/clothes.php" class="btn btn-outline btn-sm">Clear</a>
    </form>

    <div class="card" style="padding:0;">
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Image</th><th>Title</th><th>Brand</th><th>Price</th><th>Size</th><th>Seller</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if ($total===0): ?>
        <tr><td colspan="10" style="text-align:center;padding:2rem;color:var(--muted);">No listings found.</td></tr>
        <?php else: while ($item = mysqli_fetch_assoc($items)): ?>
        <tr>
            <td style="color:var(--muted);"><?= $item['ClothesID'] ?></td>
            <td>
                <div style="width:50px;height:50px;background:var(--cream);border-radius:6px;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                    <?php if ($item['ImagePath'] && file_exists('../'.$item['ImagePath'])): ?>
                        <img src="<?= $base ?>/<?= htmlspecialchars($item['ImagePath']) ?>" style="width:50px;height:50px;object-fit:cover;" alt="">
                    <?php else: ?>
                        <span style="font-size:1.5rem;">👗</span>
                    <?php endif; ?>
                </div>
            </td>
            <td style="max-width:160px;">
                <div style="font-weight:600;"><?= htmlspecialchars($item['Title']) ?></div>
                <div style="font-size:0.72rem;color:var(--muted);"><?= ucwords(str_replace('_',' ',$item['Condition'])) ?> &bull; <?= ucfirst($item['Category']??'') ?></div>
            </td>
            <td><?= htmlspecialchars($item['Brand']) ?></td>
            <td>R<?= number_format($item['Price'],2) ?></td>
            <td><?= htmlspecialchars($item['Size']??'—') ?></td>
            <td style="font-size:0.82rem;"><?= htmlspecialchars($item['SellerName']) ?></td>
            <td><span class="badge badge-<?= $item['Status'] ?>"><?= ucfirst($item['Status']) ?></span></td>
            <td style="font-size:0.75rem;color:var(--muted);"><?= date('d M Y',strtotime($item['CreatedAt'])) ?></td>
            <td>
                <div class="table-actions" style="flex-wrap:wrap;">
                    <?php if ($item['Status']==='pending'): ?>
                    <a href="<?= $base ?>/admin/clothes.php?approve=<?= $item['ClothesID'] ?>"
                       class="btn btn-sm btn-success" data-confirm="Approve this listing?">Approve</a>
                    <?php endif; ?>
                    <?php if ($item['Status']==='approved'): ?>
                    <a href="<?= $base ?>/product.php?id=<?= $item['ClothesID'] ?>" class="btn btn-sm btn-outline" target="_blank">View</a>
                    <a href="<?= $base ?>/admin/clothes.php?sold=<?= $item['ClothesID'] ?>"
                       class="btn btn-sm btn-outline" data-confirm="Mark as sold?">Sold</a>
                    <?php endif; ?>
                    <?php if (!in_array($item['Status'],['removed','sold'])): ?>
                    <a href="<?= $base ?>/admin/clothes.php?remove=<?= $item['ClothesID'] ?>"
                       class="btn btn-sm btn-outline" data-confirm="Remove this listing?">Remove</a>
                    <?php endif; ?>
                    <a href="<?= $base ?>/admin/clothes.php?delete=<?= $item['ClothesID'] ?>"
                       class="btn btn-sm btn-danger" data-confirm="Permanently delete this listing?">Delete</a>
                </div>
            </td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
    </div>

</div>
</section>

<!-- ADD ITEM MODAL -->
<div class="modal-overlay" id="add-item-modal">
<div class="modal-box" style="max-width:580px;">
    <div class="modal-header">
        <h3 style="font-family:'Playfair Display',serif;">Add Clothing Item</h3>
        <button class="modal-close" onclick="closeModal('add-item-modal')">&#10005;</button>
    </div>
    <form method="POST">
        <input type="hidden" name="action" value="add_item">
        <div class="form-group">
            <label>Seller *</label>
            <select name="seller_id" class="form-control" required>
                <option value="">Select seller...</option>
                <?php mysqli_data_seek($sellers,0); while ($s=mysqli_fetch_assoc($sellers)): ?>
                <option value="<?= $s['UserID'] ?>"><?= htmlspecialchars($s['Name']) ?> (@<?= htmlspecialchars($s['Username']) ?>)</option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group"><label>Title *</label><input type="text" name="title" class="form-control" required placeholder="e.g. Blue Zara blazer"></div>
        <div class="form-row">
            <div class="form-group"><label>Brand *</label><input type="text" name="brand" class="form-control" required></div>
            <div class="form-group"><label>Price (ZAR) *</label><input type="number" name="price" class="form-control" required min="1" step="0.01"></div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Size</label>
                <select name="size" class="form-control">
                    <?php foreach (['XS','S','M','L','XL','XXL','28','30','32','34','36','38','40','One Size'] as $sz): ?>
                    <option value="<?= $sz ?>"><?= $sz ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category" class="form-control">
                    <?php foreach (['tops','bottoms','dresses','outerwear','shoes','accessories','sportswear','formal'] as $cat): ?>
                    <option value="<?= $cat ?>"><?= ucfirst($cat) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Condition</label>
                <select name="condition" class="form-control">
                    <option value="new">New with tags</option>
                    <option value="like_new" selected>Like new</option>
                    <option value="good">Good</option>
                    <option value="fair">Fair</option>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="approved">Approved (Live)</option>
                    <option value="pending">Pending Review</option>
                </select>
            </div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="3" placeholder="Item description..."></textarea></div>
        <button type="submit" class="btn btn-primary btn-full">Add Clothing Item</button>
    </form>
</div>
</div>

<?php require_once 'admin_footer.php'; ?>
