<?php
/*
 * admin_header.php - Admin panel header/nav
 * WEDE6021/w POE
 */
require_once '../includes/session.php';
requireAdminLogin();
$flash     = getFlash();
$adminName = $_SESSION['admin_name'] ?? 'Admin';
$base      = '/pastimes_poe';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle).' — Admin | Pastimes' : 'Admin — Pastimes' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= $base ?>/css/style.css">
</head>
<body>

<header class="site-header admin-top-bar" style="position:sticky;top:0;z-index:200;">
    <div style="background:#0f0700;padding:4px 1.5rem;font-size:0.72rem;color:rgba(255,255,255,0.4);text-align:center;letter-spacing:0.1em;">
        PASTIMES ADMINISTRATION PORTAL &mdash; WEDE6021/w
    </div>
    <nav style="background:#1a0e00;border-bottom:2px solid var(--gold);">
        <div class="nav-container" style="height:56px;">
            <a href="<?= $base ?>/admin/dashboard.php" class="brand">
                <div class="brand-logo" style="width:36px;height:36px;font-size:1rem;">P</div>
                <div>
                    <div class="brand-name" style="font-size:1.1rem;">Pastimes</div>
                    <div class="brand-tagline">Administrator</div>
                </div>
                <span class="admin-badge" style="margin-left:8px;">Admin</span>
            </a>
            <div class="nav-actions" style="gap:0.5rem;">
                <a href="<?= $base ?>/admin/dashboard.php" style="color:rgba(255,255,255,0.7);font-size:0.82rem;padding:6px 10px;text-decoration:none;transition:color 0.2s;" onmouseover="this.style.color='#c8a951'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Dashboard</a>
                <a href="<?= $base ?>/admin/users.php"    style="color:rgba(255,255,255,0.7);font-size:0.82rem;padding:6px 10px;text-decoration:none;" onmouseover="this.style.color='#c8a951'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Users</a>
                <a href="<?= $base ?>/admin/clothes.php"  style="color:rgba(255,255,255,0.7);font-size:0.82rem;padding:6px 10px;text-decoration:none;" onmouseover="this.style.color='#c8a951'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Listings</a>
                <a href="<?= $base ?>/admin/orders.php"   style="color:rgba(255,255,255,0.7);font-size:0.82rem;padding:6px 10px;text-decoration:none;" onmouseover="this.style.color='#c8a951'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Orders</a>
                <a href="<?= $base ?>/index.php"          style="color:rgba(255,255,255,0.5);font-size:0.8rem;padding:6px 10px;text-decoration:none;">View Site</a>
                <a href="<?= $base ?>/admin/logout.php"   style="background:rgba(220,53,69,0.2);color:#f87171;font-size:0.8rem;padding:6px 12px;border-radius:6px;text-decoration:none;border:1px solid rgba(220,53,69,0.3);">Logout</a>
            </div>
        </div>
    </nav>
    <div style="background:#2a1500;color:rgba(255,255,255,0.5);padding:5px 1.5rem;font-size:0.75rem;display:flex;justify-content:space-between;">
        <span>Logged in as <strong style="color:var(--gold);"><?= htmlspecialchars($adminName) ?></strong> &mdash; Full Administrator Access</span>
        <span><?= date('D, d M Y H:i') ?></span>
    </div>
</header>

<?php if ($flash): ?>
<div class="flash flash-<?= $flash['type'] ?>">
    <span><?= htmlspecialchars($flash['message']) ?></span>
    <button onclick="this.parentElement.remove()" class="flash-close">&#10005;</button>
</div>
<?php endif; ?>
