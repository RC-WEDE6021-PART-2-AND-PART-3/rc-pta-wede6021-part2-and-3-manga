<?php
$pageTitle = 'Manage Orders';
require_once 'admin_header.php';
require_once '../includes/DBConn.php';
$base    = '/pastimes_poe';
$adminId = (int)$_SESSION['admin_id'];

// Update order status
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_order'])) {
    $oid    = (int)$_POST['order_id'];
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $notes  = mysqli_real_escape_string($conn, trim($_POST['notes'] ?? ''));
    mysqli_query($conn, "UPDATE tblAorder SET Status='$status', Notes='$notes', AdminID=$adminId WHERE OrderID=$oid");
    flashMessage('success', "Order #$oid updated to " . ucfirst($status) . ".");
    header("Location: $base/admin/orders.php"); exit;
}

$filter = $_GET['filter'] ?? '';
$where  = ['1=1'];
if ($filter) $where[] = "o.Status='" . mysqli_real_escape_string($conn,$filter) . "'";

$orders = mysqli_query($conn,
    "SELECT o.*,
            buyer.Name AS BuyerName, buyer.Email AS BuyerEmail, buyer.Username AS BuyerUsername,
            seller.Name AS SellerName, seller.Email AS SellerEmail,
            c.Title AS ItemTitle, c.Brand, c.Price AS ItemPrice
     FROM tblAorder o
     JOIN tblUser buyer  ON o.BuyerID  = buyer.UserID
     JOIN tblUser seller ON o.SellerID = seller.UserID
     JOIN tblClothes c   ON o.ClothesID = c.ClothesID
     WHERE " . implode(' AND ',$where) . "
     ORDER BY o.OrderDate DESC");

$total   = mysqli_num_rows($orders);
$revenue = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(TotalPrice),0) s FROM tblAorder WHERE Status='delivered'"))['s'];
?>

<section style="padding:2rem 1.5rem;">
<div style="max-width:1200px;margin:0 auto;">

    <div class="flex justify-between items-center flex-wrap" style="gap:1rem;margin-bottom:1.5rem;">
        <div>
            <h2 style="font-family:'Playfair Display',serif;font-size:1.8rem;">Manage Orders</h2>
            <p style="color:var(--muted);"><?= $total ?> orders &mdash; Total delivered revenue: <strong>R<?= number_format($revenue,2) ?></strong></p>
        </div>
    </div>

    <form method="GET" style="display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.5rem;">
        <select name="filter" class="form-control" style="width:auto;" onchange="this.form.submit()">
            <option value="">All Orders</option>
            <option value="pending"   <?= $filter==='pending'  ?'selected':'' ?>>Pending</option>
            <option value="confirmed" <?= $filter==='confirmed'?'selected':'' ?>>Confirmed</option>
            <option value="shipped"   <?= $filter==='shipped'  ?'selected':'' ?>>Shipped</option>
            <option value="delivered" <?= $filter==='delivered'?'selected':'' ?>>Delivered</option>
            <option value="cancelled" <?= $filter==='cancelled'?'selected':'' ?>>Cancelled</option>
        </select>
        <a href="<?= $base ?>/admin/orders.php" class="btn btn-outline btn-sm">Show All</a>
    </form>

    <div class="card" style="padding:0;">
    <div class="table-wrap">
    <table>
        <thead><tr><th>Order #</th><th>Item</th><th>Buyer</th><th>Seller</th><th>Total</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if ($total===0): ?>
        <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--muted);">No orders found.</td></tr>
        <?php else: while ($ord = mysqli_fetch_assoc($orders)): ?>
        <tr>
            <td style="font-weight:700;">#<?= $ord['OrderID'] ?></td>
            <td>
                <div style="font-weight:500;"><?= htmlspecialchars($ord['ItemTitle']) ?></div>
                <div style="font-size:0.72rem;color:var(--muted);"><?= htmlspecialchars($ord['Brand']) ?></div>
            </td>
            <td>
                <div><?= htmlspecialchars($ord['BuyerName']) ?></div>
                <div style="font-size:0.72rem;color:var(--muted);"><?= htmlspecialchars($ord['BuyerEmail']) ?></div>
            </td>
            <td>
                <div><?= htmlspecialchars($ord['SellerName']) ?></div>
                <div style="font-size:0.72rem;color:var(--muted);"><?= htmlspecialchars($ord['SellerEmail']) ?></div>
            </td>
            <td style="font-weight:700;">R<?= number_format($ord['TotalPrice'],2) ?></td>
            <td>
                <span class="badge badge-<?= in_array($ord['Status'],['delivered'])?'approved':($ord['Status']==='cancelled'?'removed':'pending') ?>">
                    <?= ucfirst($ord['Status']) ?>
                </span>
            </td>
            <td style="font-size:0.75rem;color:var(--muted);"><?= date('d M Y',strtotime($ord['OrderDate'])) ?></td>
            <td>
                <button class="btn btn-sm btn-outline"
                        onclick="openOrderModal(<?= htmlspecialchars(json_encode($ord)) ?>)">Manage</button>
            </td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
    </div>

</div>
</section>

<!-- ORDER MODAL -->
<div class="modal-overlay" id="order-modal">
<div class="modal-box">
    <div class="modal-header">
        <h3 id="order-modal-title" style="font-family:'Playfair Display',serif;">Order Details</h3>
        <button class="modal-close" onclick="closeModal('order-modal')">&#10005;</button>
    </div>
    <div id="order-modal-info" style="background:var(--cream);padding:1rem;border-radius:8px;margin-bottom:1rem;font-size:0.85rem;line-height:1.8;"></div>
    <form method="POST">
        <input type="hidden" name="update_order" value="1">
        <input type="hidden" name="order_id" id="modal-order-id">
        <div class="form-group">
            <label>Update Status</label>
            <select name="status" id="modal-status" class="form-control">
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
            </select>
        </div>
        <div class="form-group">
            <label>Admin Notes (Delivery / Quality Liaison)</label>
            <textarea name="notes" id="modal-notes" class="form-control" rows="3"
                      placeholder="Notes about delivery, quality check, liaison between buyer and seller..."></textarea>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Update Order</button>
    </form>
</div>
</div>

<script>
function openOrderModal(ord) {
    document.getElementById('order-modal-title').textContent = 'Order #' + ord.OrderID;
    document.getElementById('modal-order-id').value = ord.OrderID;
    document.getElementById('modal-status').value   = ord.Status;
    document.getElementById('modal-notes').value    = ord.Notes || '';
    document.getElementById('order-modal-info').innerHTML =
        '<strong>Item:</strong> ' + ord.ItemTitle + ' (' + ord.Brand + ')<br>' +
        '<strong>Buyer:</strong> ' + ord.BuyerName + ' &lt;' + ord.BuyerEmail + '&gt;<br>' +
        '<strong>Seller:</strong> ' + ord.SellerName + ' &lt;' + ord.SellerEmail + '&gt;<br>' +
        '<strong>Total:</strong> R' + parseFloat(ord.TotalPrice).toFixed(2) + '<br>' +
        (ord.ShippingAddress ? '<strong>Deliver to:</strong> ' + ord.ShippingAddress : '');
    openModal('order-modal');
}
</script>

<?php require_once 'admin_footer.php'; ?>
