<?php
/*
 * Student Name: [Your Name]
 * Student Number: [Your Student Number]
 * Declaration: This code is my own work where not referenced.
 *
 * admin/login.php - Administrator Login Portal
 * When user clicks "Admin" button, they are prompted to login with admin rights.
 */
require_once '../includes/session.php';
require_once '../includes/DBConn.php';
$base = '/pastimes_poe';

if (isAdminLoggedIn()) { header("Location: $base/admin/dashboard.php"); exit; }

$errors = [];
$sticky_username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $sticky_username = $username;

    if (empty($username)) $errors['username'] = 'Admin username is required.';
    if (empty($password)) $errors['password'] = 'Password is required.';

    if (empty($errors)) {
        $passHash = md5($password);
        $u = mysqli_real_escape_string($conn, $username);
        $res = mysqli_query($conn, "SELECT * FROM tblAdmin WHERE Username='$u' AND PasswordHash='$passHash' LIMIT 1");
        if ($res && mysqli_num_rows($res) === 1) {
            $admin = mysqli_fetch_assoc($res);
            $_SESSION['admin_id']       = $admin['AdminID'];
            $_SESSION['admin_name']     = $admin['Name'];
            $_SESSION['admin_username'] = $admin['Username'];
            $_SESSION['admin_email']    = $admin['Email'];
            header("Location: $base/admin/dashboard.php"); exit;
        } else {
            $errors['general'] = 'Invalid admin credentials.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — Pastimes</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= $base ?>/css/style.css">
    <style>
        body { background: #0d0700; display:flex; align-items:center; justify-content:center; min-height:100vh; padding:1rem; }
        .admin-login-box { background:#fff; border-radius:16px; padding:3rem; width:100%; max-width:420px; box-shadow:0 24px 80px rgba(0,0,0,0.6); }
        .admin-logo { text-align:center; margin-bottom:2rem; }
        .admin-logo-circle { width:64px;height:64px;border-radius:50%;background:var(--gold);color:#1a1a1a;display:flex;align-items:center;justify-content:center;font-family:'Playfair Display',serif;font-size:1.8rem;font-weight:700;margin:0 auto 0.75rem; }
    </style>
</head>
<body>
<div class="admin-login-box">
    <div class="admin-logo">
        <div class="admin-logo-circle">P</div>
        <div style="font-family:'Playfair Display',serif;font-size:1.5rem;font-weight:700;">Pastimes</div>
        <div style="font-size:0.75rem;letter-spacing:0.15em;text-transform:uppercase;color:var(--muted);margin-top:2px;">Administrator Login</div>
    </div>

    <?php if (!empty($errors['general'])): ?>
    <div class="flash flash-danger" style="border-radius:8px;margin-bottom:1.5rem;">
        <span>&#10005; <?= htmlspecialchars($errors['general']) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" novalidate>
        <div class="form-group">
            <label for="username">Admin Username</label>
            <input type="text" id="username" name="username"
                   class="form-control <?= isset($errors['username'])?'error':'' ?>"
                   value="<?= htmlspecialchars($sticky_username) ?>"
                   placeholder="admin_username" required autocomplete="username">
            <?php if (isset($errors['username'])): ?><div class="form-error">&#10005; <?= $errors['username'] ?></div><?php endif; ?>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                   class="form-control <?= isset($errors['password'])?'error':'' ?>"
                   placeholder="••••••••" required autocomplete="current-password">
            <?php if (isset($errors['password'])): ?><div class="form-error">&#10005; <?= $errors['password'] ?></div><?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary btn-full" style="margin-top:1rem;border-radius:8px;">
            Sign In as Administrator
        </button>
    </form>

    <hr class="divider" style="margin:1.5rem 0;">
    <p class="text-center" style="font-size:0.8rem;color:var(--muted);">
        <a href="<?= $base ?>/login.php">&#8592; Back to User Login</a>
    </p>
    <div class="info-box mt-2" style="font-size:0.78rem;">
        Default admin: <code>superadmin</code> / <code>admin1234</code>
    </div>
</div>
</body>
</html>
