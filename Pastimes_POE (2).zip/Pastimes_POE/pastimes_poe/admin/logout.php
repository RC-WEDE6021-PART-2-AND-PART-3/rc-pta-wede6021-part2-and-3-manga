<?php
require_once '../includes/session.php';
unset($_SESSION['admin_id'],$_SESSION['admin_name'],$_SESSION['admin_username'],$_SESSION['admin_email']);
header('Location: /pastimes_poe/admin/login.php');
exit;
