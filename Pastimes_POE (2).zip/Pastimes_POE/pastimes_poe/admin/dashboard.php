<?php
$pageTitle = 'Admin Dashboard';
require_once 'admin_header.php';
require_once '../includes/DBConn.php';
$base = '/pastimes_poe';

// Quick stats
$totalUsers    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tblUser"))['c'];
$pendingUsers  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tblUser WHERE Status='pending'"))['c'];
$totalItems    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tblClothes"))['c'];
$pendingItems  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tblClothes WHERE Status='pending'"))['c'];
$totalOrders   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tblAorder"))['c'];
$pendingOrders = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM tblAorder WHERE Status='pending'"))['c'];
$totalRevenue  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(TotalPrice),0) s FROM tblAorder WHERE Status='delivered'"))['s'];

$recentUsers = mysqli_query($conn,"SELECT * FROM tblUser ORDER BY CreatedAt DESC LIMIT 6");
$recentItems = mysqli_query($conn,"SELECT c.*,u.Name AS SellerName FROM tblClothes c JOIN tblUser u ON c.SellerID=u.UserID ORDER BY c.CreatedAt DESC LIMIT 6");
?>

<section style="padding:2rem 1.5rem;">
<div style="max-width:1200px;margin:0 auto;">

    <div style="margin-bottom:1.5rem;">
        <h2 style="font-family:'Playfair Display',serif;font-size:1.8rem;">Admin Dashboard</h2>
        <p style="color:var(--muted);">Overview of the ClothingStore system</p>
    </div>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));margin-bottom:2rem;">
        <div class="stat-card"><div class="stat-number"><?= $totalUsers ?></div><div class="stat-label">Total Users</div></div>
        <div class="stat-card" style="border-left-color:<?= $pendingUsers>0?'var(--warning)':'var(--gold)' ?>;">
            <div class="stat-number" style="color:<?= $pendingUsers>0?'var(--warning)':'var(--gold)' ?>;"><?= $pendingUsers ?></div>
            <div class="stat-label">Pending Verification</div>
        </div>
        <div class="stat-card"><div class="stat-number"><?= $totalItems ?></div><div class="stat-label">Total Listings</div></div>
        <div class="stat-card" style="border-left-color:<?= $pendingItems>0?'var(--warning)':'var(--gold)' ?>;">
            <div class="stat-number" style="color:<?= $pendingItems>0?'var(--warning)':'var(--gold)' ?>;"><?= $pendingItems ?></div>
            <div class="stat-label">Pending Listings</div>
        </div>
        <div class="stat-card"><div class="stat-number"><?= $totalOrders ?></div><div class="stat-label">Total Orders</div></div>
        <div class="stat-card"><div class="stat-number">R<?= number_format($totalRevenue,0) ?></div><div class="stat-label">Revenue (Delivered)</div></div>
    </div>

    <!-- Alerts -->
    <?php if ($pendingUsers > 0): ?>
    <div class="flash flash-warning" style="border-radius:8px;margin-bottom:1rem;">
        <span>&#9888; <strong><?= $pendingUsers ?></strong> user(s) are awaiting account verification.</span>
        <a href="<?= $base ?>/admin/users.php?filter=pending" style="color:#856404;font-weight:700;margin-left:1rem;">Verify Now &rarr;</a>
    </div>
    <?php endif; ?>
    <?php if ($pendingItems > 0): ?>
    <div class="flash flash-warning" style="border-radius:8px;margin-bottom:1.5rem;">
        <span>&#9888; <strong><?= $pendingItems ?></strong> listing(s) are awaiting admin approval.</span>
        <a href="<?= $base ?>/admin/clothes.php?filter=pending" style="color:#856404;font-weight:700;margin-left:1rem;">Review Now &rarr;</a>
    </div>
    <?php endif; ?>

    <div class="grid-2" style="gap:2rem;align-items:start;">

        <!-- Recent Users -->
        <div class="card">
            <div class="flex justify-between items-center mb-2">
                <div class="card-title" style="margin-bottom:0;">Recent Registrations</div>
                <a href="<?= $base ?>/admin/users.php" class="btn btn-sm btn-outline">View All</a>
            </div>
            <div class="table-wrap">
            <table>
                <thead><tr><th>Name</th><th>Role</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php while ($u = mysqli_fetch_assoc($recentUsers)): ?>
                <tr>
                    <td>
                        <div style="font-weight:500;"><?= htmlspecialchars($u['Name']) ?></div>
                        <div style="font-size:0.72rem;color:var(--muted);">@<?= htmlspecialchars($u['Username']) ?></div>
                    </td>
                    <td><?= ucfirst($u['Role']) ?></td>
                    <td><span class="badge badge-<?= $u['Status'] ?>"><?= ucfirst($u['Status']) ?></span></td>
                    <td>
                        <?php if ($u['Status']==='pending'): ?>
                        <a href="<?= $base ?>/admin/users.php?verify=<?= $u['UserID'] ?>"
                           class="btn btn-sm btn-success"
                           data-confirm="Verify user <?= htmlspecialchars($u['Name']) ?>?">Verify</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            </div>
        </div>

        <!-- Recent Listings -->
        <div class="card">
            <div class="flex justify-between items-center mb-2">
                <div class="card-title" style="margin-bottom:0;">Recent Listings</div>
                <a href="<?= $base ?>/admin/clothes.php" class="btn btn-sm btn-outline">View All</a>
            </div>
            <div class="table-wrap">
            <table>
                <thead><tr><th>Item</th><th>Price</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php while ($item = mysqli_fetch_assoc($recentItems)): ?>
                <tr>
                    <td>
                        <div style="font-weight:500;"><?= htmlspecialchars($item['Title']) ?></div>
                        <div style="font-size:0.72rem;color:var(--muted);"><?= htmlspecialchars($item['Brand']) ?> by <?= htmlspecialchars($item['SellerName']) ?></div>
                    </td>
                    <td>R<?= number_format($item['Price'],2) ?></td>
                    <td><span class="badge badge-<?= $item['Status'] ?>"><?= ucfirst($item['Status']) ?></span></td>
                    <td>
                        <?php if ($item['Status']==='pending'): ?>
                        <a href="<?= $base ?>/admin/clothes.php?approve=<?= $item['ClothesID'] ?>"
                           class="btn btn-sm btn-success"
                           data-confirm="Approve this listing?">Approve</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            </div>
        </div>

    </div>

    <!-- Quick Actions -->
    <div style="margin-top:2rem;display:flex;gap:1rem;flex-wrap:wrap;">
        <a href="<?= $base ?>/admin/users.php?filter=pending" class="btn btn-dark">&#10003; Verify Pending Users</a>
        <a href="<?= $base ?>/admin/clothes.php?filter=pending" class="btn btn-dark">&#10003; Approve Listings</a>
        <a href="<?= $base ?>/admin/orders.php" class="btn btn-outline">&#128666; Manage Orders</a>
        <a href="<?= $base ?>/loadClothingStore.php" class="btn btn-outline"
           data-confirm="This will DROP and rebuild ALL tables. Continue?">&#9888; Rebuild DB</a>
        <a href="<?= $base ?>/createTable.php" class="btn btn-outline"
           data-confirm="This will drop and recreate tblUser. Continue?">&#9888; Reload Users</a>
    </div>

</div>
</section>

<?php require_once 'admin_footer.php'; ?>
