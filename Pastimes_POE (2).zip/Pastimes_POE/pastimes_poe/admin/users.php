<?php
$pageTitle = 'Manage Users';
require_once 'admin_header.php';
require_once '../includes/DBConn.php';
$base = '/pastimes_poe';

// ── QUICK ACTIONS ─────────────────────────────────────────────
if (isset($_GET['verify'])) {
    $id = (int)$_GET['verify'];
    mysqli_query($conn, "UPDATE tblUser SET Status='verified' WHERE UserID=$id");
    flashMessage('success', 'User verified successfully. They can now log in.');
    header("Location: $base/admin/users.php"); exit;
}
if (isset($_GET['verify_seller'])) {
    $id = (int)$_GET['verify_seller'];
    mysqli_query($conn, "UPDATE tblUser SET SellerVerified=1, Status='verified' WHERE UserID=$id");
    flashMessage('success', 'Seller approved. They can now list clothing items.');
    header("Location: $base/admin/users.php"); exit;
}
if (isset($_GET['suspend'])) {
    $id = (int)$_GET['suspend'];
    mysqli_query($conn, "UPDATE tblUser SET Status='suspended' WHERE UserID=$id");
    flashMessage('warning', 'User account suspended.');
    header("Location: $base/admin/users.php"); exit;
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=0");
    mysqli_query($conn, "DELETE FROM tblUser WHERE UserID=$id");
    mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=1");
    flashMessage('danger', 'User deleted permanently.');
    header("Location: $base/admin/users.php"); exit;
}

// ── ADD USER ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add') {
    $name    = mysqli_real_escape_string($conn, trim($_POST['name']));
    $email   = mysqli_real_escape_string($conn, trim($_POST['email']));
    $uname   = mysqli_real_escape_string($conn, trim($_POST['username']));
    $role    = mysqli_real_escape_string($conn, $_POST['role']   ?? 'buyer');
    $status  = mysqli_real_escape_string($conn, $_POST['status'] ?? 'verified');
    $pass    = md5(trim($_POST['password'] ?? 'Password1'));
    $sv      = isset($_POST['seller_verified']) ? 1 : 0;
    mysqli_query($conn,
        "INSERT INTO tblUser (Name,Email,Username,PasswordHash,Role,Status,SellerVerified)
         VALUES ('$name','$email','$uname','$pass','$role','$status',$sv)");
    flashMessage('success', 'User added successfully.');
    header("Location: $base/admin/users.php"); exit;
}

// ── UPDATE USER ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='update') {
    $id     = (int)$_POST['user_id'];
    $name   = mysqli_real_escape_string($conn, trim($_POST['name']));
    $email  = mysqli_real_escape_string($conn, trim($_POST['email']));
    $role   = mysqli_real_escape_string($conn, $_POST['role']   ?? 'buyer');
    $status = mysqli_real_escape_string($conn, $_POST['status'] ?? 'pending');
    $sv     = isset($_POST['seller_verified']) ? 1 : 0;
    mysqli_query($conn,
        "UPDATE tblUser SET Name='$name',Email='$email',Role='$role',Status='$status',SellerVerified=$sv
         WHERE UserID=$id");
    flashMessage('success', 'User updated successfully.');
    header("Location: $base/admin/users.php"); exit;
}

// ── FILTERS ───────────────────────────────────────────────────
$filter = $_GET['filter'] ?? '';
$search = $_GET['q']      ?? '';
$where  = ['1=1'];
if ($filter) $where[] = "Status='" . mysqli_real_escape_string($conn,$filter) . "'";
if ($search) {
    $s = mysqli_real_escape_string($conn,$search);
    $where[] = "(Name LIKE '%$s%' OR Email LIKE '%$s%' OR Username LIKE '%$s%')";
}
$users = mysqli_query($conn, "SELECT * FROM tblUser WHERE " . implode(' AND ',$where) . " ORDER BY CreatedAt DESC");
$totalCount = mysqli_num_rows($users);
?>

<section style="padding:2rem 1.5rem;">
<div style="max-width:1200px;margin:0 auto;">

    <div class="flex justify-between items-center flex-wrap" style="gap:1rem;margin-bottom:1.5rem;">
        <div>
            <h2 style="font-family:'Playfair Display',serif;font-size:1.8rem;">Manage Users</h2>
            <p style="color:var(--muted);"><?= $totalCount ?> users found</p>
        </div>
        <button class="btn btn-primary" onclick="openModal('add-modal')">+ Add New User</button>
    </div>

    <!-- Filters -->
    <form method="GET" style="display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.5rem;">
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
               placeholder="Search name, email, username..." class="form-control" style="flex:1;min-width:200px;max-width:320px;">
        <select name="filter" class="form-control" style="width:auto;" onchange="this.form.submit()">
            <option value="">All Statuses</option>
            <option value="pending"   <?= $filter==='pending'  ?'selected':'' ?>>Pending</option>
            <option value="verified"  <?= $filter==='verified' ?'selected':'' ?>>Verified</option>
            <option value="suspended" <?= $filter==='suspended'?'selected':'' ?>>Suspended</option>
        </select>
        <button type="submit" class="btn btn-dark btn-sm">Search</button>
        <a href="<?= $base ?>/admin/users.php" class="btn btn-outline btn-sm">Clear</a>
    </form>

    <div class="card" style="padding:0;">
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>#</th><th>Name &amp; Username</th><th>Email</th><th>Role</th><th>Status</th><th>Seller</th><th>Joined</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php if ($totalCount === 0): ?>
        <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--muted);">No users found.</td></tr>
        <?php else: while ($u = mysqli_fetch_assoc($users)): ?>
        <tr>
            <td style="color:var(--muted);"><?= $u['UserID'] ?></td>
            <td>
                <div style="font-weight:600;"><?= htmlspecialchars($u['Name']) ?></div>
                <div style="font-size:0.72rem;color:var(--muted);">@<?= htmlspecialchars($u['Username']) ?></div>
            </td>
            <td style="font-size:0.84rem;"><?= htmlspecialchars($u['Email']) ?></td>
            <td><span style="font-size:0.82rem;"><?= ucfirst($u['Role']) ?></span></td>
            <td><span class="badge badge-<?= $u['Status'] ?>"><?= ucfirst($u['Status']) ?></span></td>
            <td>
                <?php if ($u['SellerVerified']): ?>
                    <span class="badge badge-approved">&#10003; Yes</span>
                <?php else: ?>
                    <span style="color:var(--muted);font-size:0.8rem;">No</span>
                <?php endif; ?>
            </td>
            <td style="font-size:0.78rem;color:var(--muted);"><?= date('d M Y', strtotime($u['CreatedAt'])) ?></td>
            <td>
                <div class="table-actions">
                    <?php if ($u['Status']==='pending'): ?>
                    <a href="<?= $base ?>/admin/users.php?verify=<?= $u['UserID'] ?>"
                       class="btn btn-sm btn-success" data-confirm="Verify this user?">Verify</a>
                    <?php endif; ?>
                    <?php if (in_array($u['Role'],['seller','both']) && !$u['SellerVerified']): ?>
                    <a href="<?= $base ?>/admin/users.php?verify_seller=<?= $u['UserID'] ?>"
                       class="btn btn-sm btn-success" data-confirm="Approve as verified seller?">&#10003; Seller</a>
                    <?php endif; ?>
                    <?php if ($u['Status']!=='suspended'): ?>
                    <a href="<?= $base ?>/admin/users.php?suspend=<?= $u['UserID'] ?>"
                       class="btn btn-sm btn-outline" data-confirm="Suspend this user?">Suspend</a>
                    <?php endif; ?>
                    <button class="btn btn-sm btn-outline"
                            onclick="editUser(<?= htmlspecialchars(json_encode($u)) ?>)">Edit</button>
                    <a href="<?= $base ?>/admin/users.php?delete=<?= $u['UserID'] ?>"
                       class="btn btn-sm btn-danger" data-confirm="Permanently delete this user?">Delete</a>
                </div>
            </td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
    </div>

</div>
</section>

<!-- ── ADD MODAL ───────────────────────────────────────────── -->
<div class="modal-overlay" id="add-modal">
<div class="modal-box">
    <div class="modal-header">
        <h3 style="font-family:'Playfair Display',serif;">Add New User</h3>
        <button class="modal-close" onclick="closeModal('add-modal')">&#10005;</button>
    </div>
    <form method="POST">
        <input type="hidden" name="action" value="add">
        <div class="form-group"><label>Full Name *</label><input type="text" name="name" class="form-control" required></div>
        <div class="form-group"><label>Email *</label><input type="email" name="email" class="form-control" required></div>
        <div class="form-group"><label>Username *</label><input type="text" name="username" class="form-control" required></div>
        <div class="form-group"><label>Password (will be MD5 hashed)</label><input type="text" name="password" class="form-control" value="Password1"></div>
        <div class="form-row">
            <div class="form-group">
                <label>Role</label>
                <select name="role" class="form-control">
                    <option value="buyer">Buyer</option>
                    <option value="seller">Seller</option>
                    <option value="both">Both</option>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="verified">Verified</option>
                    <option value="pending">Pending</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label><input type="checkbox" name="seller_verified"> Seller Verified</label>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Add User</button>
    </form>
</div>
</div>

<!-- ── EDIT MODAL ──────────────────────────────────────────── -->
<div class="modal-overlay" id="edit-modal">
<div class="modal-box">
    <div class="modal-header">
        <h3 style="font-family:'Playfair Display',serif;" id="edit-title">Edit User</h3>
        <button class="modal-close" onclick="closeModal('edit-modal')">&#10005;</button>
    </div>
    <form method="POST" id="edit-form">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="user_id" id="edit-uid">
        <div class="form-group"><label>Full Name *</label><input type="text" name="name" id="edit-name" class="form-control" required></div>
        <div class="form-group"><label>Email *</label><input type="email" name="email" id="edit-email" class="form-control" required></div>
        <div class="form-row">
            <div class="form-group">
                <label>Role</label>
                <select name="role" id="edit-role" class="form-control">
                    <option value="buyer">Buyer</option>
                    <option value="seller">Seller</option>
                    <option value="both">Both</option>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" id="edit-status" class="form-control">
                    <option value="pending">Pending</option>
                    <option value="verified">Verified</option>
                    <option value="suspended">Suspended</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label><input type="checkbox" name="seller_verified" id="edit-sv"> Seller Verified</label>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Save Changes</button>
    </form>
</div>
</div>

<script>
function editUser(u) {
    document.getElementById('edit-title').textContent = 'Edit: ' + u.Name;
    document.getElementById('edit-uid').value    = u.UserID;
    document.getElementById('edit-name').value   = u.Name;
    document.getElementById('edit-email').value  = u.Email;
    document.getElementById('edit-role').value   = u.Role;
    document.getElementById('edit-status').value = u.Status;
    document.getElementById('edit-sv').checked   = u.SellerVerified == 1;
    openModal('edit-modal');
}
</script>

<?php require_once 'admin_footer.php'; ?>
