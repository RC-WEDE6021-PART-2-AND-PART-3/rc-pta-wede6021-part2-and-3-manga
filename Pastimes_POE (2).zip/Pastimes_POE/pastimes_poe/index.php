<?php
/*
 * Student Name: [DUMISA]
 * Student Number: [ST10445334]
 * Declaration: This code is my own work where not referenced.
 * index.php - Pastimes Homepage
 */

$pageTitle = 'Home';
require_once 'includes/header.php';
require_once 'includes/DBConn.php';

$base = '/pastimes_poe';

// Fetch featured approved clothes
$featured = mysqli_query($conn,
    "SELECT c.*, u.Name AS SellerName
     FROM tblClothes c
     JOIN tblUser u ON c.SellerID = u.UserID
     WHERE c.Status = 'approved'
     ORDER BY c.CreatedAt DESC
     LIMIT 8");

// Stats for homepage
$totalItems = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM tblClothes WHERE Status='approved'"))['c'];
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM tblUser WHERE Status='verified'"))['c'];
$totalSold  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM tblClothes WHERE Status='sold'"))['c'];
$totalBrands= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT Brand) c FROM tblClothes WHERE Status='approved'"))['c'];
?>

<!-- ══ HERO ══════════════════════════════════════════ -->
<section class="hero">
    <div class="hero-content">
        <p class="hero-eyebrow">South Africa's #1 Second-Hand Fashion Platform</p>
        <h1>Pre-Loved Fashion.<br><em>Perfectly Priced.</em></h1>
        <p>Discover premium branded second-hand clothing from verified sellers across South Africa. Buy smart, sell easy, dress brilliantly.</p>
        <div class="hero-btns">
            <a href="<?= $base ?>/shop.php" class="btn btn-primary btn-lg">Browse Collection</a>
            <a href="<?= $base ?>/register.php" class="btn btn-outline-white btn-lg">Start Selling</a>
        </div>
    </div>
</section>

<!-- ══ STATS STRIP ═══════════════════════════════════ -->
<section style="background:#fff;border-bottom:1px solid var(--border);padding:1.5rem;">
    <div style="max-width:900px;margin:0 auto;display:grid;grid-template-columns:repeat(4,1fr);text-align:center;gap:1rem;">
        <div><div style="font-family:'Playfair Display',serif;font-size:2rem;color:var(--gold);font-weight:700;"><?= $totalItems ?>+</div><div style="font-size:0.72rem;letter-spacing:0.1em;text-transform:uppercase;color:var(--muted);">Items Available</div></div>
        <div><div style="font-family:'Playfair Display',serif;font-size:2rem;color:var(--gold);font-weight:700;"><?= $totalUsers ?>+</div><div style="font-size:0.72rem;letter-spacing:0.1em;text-transform:uppercase;color:var(--muted);">Verified Members</div></div>
        <div><div style="font-family:'Playfair Display',serif;font-size:2rem;color:var(--gold);font-weight:700;"><?= $totalSold ?>+</div><div style="font-size:0.72rem;letter-spacing:0.1em;text-transform:uppercase;color:var(--muted);">Items Sold</div></div>
        <div><div style="font-family:'Playfair Display',serif;font-size:2rem;color:var(--gold);font-weight:700;"><?= $totalBrands ?>+</div><div style="font-size:0.72rem;letter-spacing:0.1em;text-transform:uppercase;color:var(--muted);">Brands Listed</div></div>
    </div>
</section>

<!-- ══ CATEGORIES ════════════════════════════════════ -->
<section class="section" style="background:var(--cream);">
<div class="section-inner">
    <div class="section-heading">
        <h2>Shop by Category</h2>
        <div class="gold-line"></div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:1rem;">
        <?php
        $categories = [
            ['tops','👕','Tops'],['bottoms','👖','Bottoms'],['dresses','👗','Dresses'],
            ['outerwear','🧥','Outerwear'],['shoes','👟','Shoes'],['accessories','👜','Accessories'],
            ['sportswear','🏃','Sportswear'],['formal','👔','Formal']
        ];
        foreach ($categories as [$slug,$icon,$label]):
        ?>
        <a href="<?= $base ?>/shop.php?category=<?= $slug ?>" style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:1.5rem 0.5rem;text-align:center;transition:all 0.2s;text-decoration:none;color:inherit;display:block;" onmouseover="this.style.borderColor='var(--gold)';this.style.boxShadow='0 4px 16px rgba(0,0,0,0.1)'" onmouseout="this.style.borderColor='var(--border)';this.style.boxShadow='none'">
            <div style="font-size:2rem;margin-bottom:0.5rem;"><?= $icon ?></div>
            <div style="font-size:0.8rem;font-weight:600;letter-spacing:0.04em;"><?= $label ?></div>
        </a>
        <?php endforeach; ?>
    </div>
</div>
</section>

<!-- ══ FEATURED ITEMS ════════════════════════════════ -->
<section class="section">
<div class="section-inner">
    <div class="section-heading">
        <h2>New Arrivals</h2>
        <div class="gold-line"></div>
        <p>Freshly listed, admin-approved pieces from trusted sellers</p>
    </div>

    <?php if (!$featured || mysqli_num_rows($featured) === 0): ?>
    <div class="empty-state">
        <div class="empty-icon">👗</div>
        <h3>No Items Listed Yet</h3>
        <p>Set up the database and import seed data to see items here.</p>
        <a href="<?= $base ?>/loadClothingStore.php" class="btn btn-dark mt-2">Setup Database</a>
    </div>
    <?php else: ?>
    <div class="grid-4">
        <?php while ($item = mysqli_fetch_assoc($featured)): ?>
        <a href="<?= $base ?>/product.php?id=<?= $item['ClothesID'] ?>" class="product-card">
            <div class="product-img">
                <?php if ($item['ImagePath'] && file_exists(__DIR__ . '/' . $item['ImagePath'])): ?>
                    <img src="<?= $base ?>/<?= htmlspecialchars($item['ImagePath']) ?>" alt="<?= htmlspecialchars($item['Title']) ?>">
                <?php else: ?>
                    <span class="product-img-placeholder">👗</span>
                <?php endif; ?>
                <span class="product-badge"><?= htmlspecialchars($item['Brand']) ?></span>
            </div>
            <div class="product-body">
                <div class="product-brand"><?= htmlspecialchars($item['Brand']) ?></div>
                <div class="product-title"><?= htmlspecialchars($item['Title']) ?></div>
                <div class="product-meta">
                    Size: <?= htmlspecialchars($item['Size'] ?? 'N/A') ?> &bull;
                    <?= ucwords(str_replace('_',' ', $item['Condition'])) ?>
                </div>
                <div class="product-footer">
                    <span class="product-price">R<?= number_format($item['Price'], 2) ?></span>
                    <span style="font-size:0.72rem;color:var(--muted);">by <?= htmlspecialchars($item['SellerName']) ?></span>
                </div>
            </div>
        </a>
        <?php endwhile; ?>
    </div>
    <div class="text-center mt-4">
        <a href="<?= $base ?>/shop.php" class="btn btn-outline btn-lg">View All Items</a>
    </div>
    <?php endif; ?>
</div>
</section>

<!-- ══ HOW IT WORKS ══════════════════════════════════ -->
<section class="section" style="background:var(--primary);color:#fff;">
<div class="section-inner">
    <div class="section-heading">
        <h2 style="color:#fff;">How Pastimes Works</h2>
        <div class="gold-line"></div>
    </div>
    <div class="grid-3" style="text-align:center;gap:2rem;">
        <div style="padding:2rem;">
            <div style="font-size:3rem;margin-bottom:1rem;">📝</div>
            <h3 style="color:var(--gold);font-family:'Playfair Display',serif;margin-bottom:0.75rem;">1. Register</h3>
            <p style="color:rgba(255,255,255,0.6);font-size:0.9rem;">Create your account with name, email, username and password. An admin verifies you before you get full access.</p>
        </div>
        <div style="padding:2rem;">
            <div style="font-size:3rem;margin-bottom:1rem;">🛍️</div>
            <h3 style="color:var(--gold);font-family:'Playfair Display',serif;margin-bottom:0.75rem;">2. Browse &amp; Buy</h3>
            <p style="color:rgba(255,255,255,0.6);font-size:0.9rem;">Browse thousands of branded pieces, message sellers, add items to your cart and checkout with delivery details.</p>
        </div>
        <div style="padding:2rem;">
            <div style="font-size:3rem;margin-bottom:1rem;">💰</div>
            <h3 style="color:var(--gold);font-family:'Playfair Display',serif;margin-bottom:0.75rem;">3. Sell</h3>
            <p style="color:rgba(255,255,255,0.6);font-size:0.9rem;">Once approved as a seller, list your branded items with photos, descriptions and pricing. Admin handles delivery.</p>
        </div>
    </div>
</div>
</section>

<!-- ══ CTA BAND ═══════════════════════════════════════ -->
<section class="section" style="background:var(--gold);text-align:center;">
<div class="section-inner" style="max-width:600px;">
    <h2 style="font-family:'Playfair Display',serif;font-size:2rem;margin-bottom:0.5rem;">Ready to get started?</h2>
    <p style="margin-bottom:2rem;opacity:0.75;">Join the growing Pastimes community today.</p>
    <div class="hero-btns">
        <a href="<?= $base ?>/register.php" class="btn btn-dark btn-lg">Create Account</a>
        <a href="<?= $base ?>/shop.php" class="btn btn-outline btn-lg">Shop Now</a>
    </div>
</div>
</section>

<?php require_once 'includes/footer.php'; ?>
