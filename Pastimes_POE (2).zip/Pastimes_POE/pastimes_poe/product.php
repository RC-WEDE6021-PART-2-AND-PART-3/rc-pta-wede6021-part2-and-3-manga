<?php
$pageTitle = 'Product';
require_once 'includes/session.php';
require_once 'includes/DBConn.php';
$base = '/pastimes_poe';
$id = (int)($_GET['id'] ?? 0);
if (!$id) { header("Location: $base/shop.php"); exit; }
$res = mysqli_query($conn, "SELECT c.*, u.Name AS SellerName, u.UserID AS SellerUID, u.Email AS SellerEmail FROM tblClothes c JOIN tblUser u ON c.SellerID=u.UserID WHERE c.ClothesID=$id AND c.Status='approved' LIMIT 1");
if (!$res || mysqli_num_rows($res) === 0) { flashMessage('danger','Item not found or no longer available.'); header("Location: $base/shop.php"); exit; }
$item = mysqli_fetch_assoc($res);
$pageTitle = $item['Title'];
$user = getLoggedInUser();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    if (!$user) { flashMessage('warning','Please login to add items to your cart.'); header("Location: $base/login.php"); exit; }
    if ($user['status'] !== 'verified') { flashMessage('warning','Your account must be verified before purchasing.'); }
    else {
        $uid = (int)$user['id'];
        $cartRes = mysqli_query($conn, "SELECT CartID FROM tblCart WHERE BuyerID=$uid LIMIT 1");
        if (mysqli_num_rows($cartRes) === 0) { mysqli_query($conn,"INSERT INTO tblCart (BuyerID) VALUES ($uid)"); $cartId=mysqli_insert_id($conn); }
        else $cartId = mysqli_fetch_assoc($cartRes)['CartID'];
        $exist = mysqli_query($conn, "SELECT CartItemID FROM tblCartItem WHERE CartID=$cartId AND ClothesID=$id");
        if (mysqli_num_rows($exist) > 0) flashMessage('info','This item is already in your cart.');
        else { mysqli_query($conn,"INSERT INTO tblCartItem (CartID,ClothesID) VALUES ($cartId,$id)"); flashMessage('success','Added to cart!'); }
        header("Location: $base/cart.php"); exit;
    }
}
require_once 'includes/header.php';
?>
<div style="background:var(--cream);border-bottom:1px solid var(--border);padding:0.75rem 1.5rem;">
    <div style="max-width:980px;margin:0 auto;" class="breadcrumb">
        <a href="<?= $base ?>">Home</a> &rsaquo; <a href="<?= $base ?>/shop.php">Shop</a> &rsaquo; <span><?= htmlspecialchars($item['Title']) ?></span>
    </div>
</div>
<section style="padding:2rem 1.5rem 4rem;">
<div class="product-detail">
    <div class="product-detail-img">
        <?php if ($item['ImagePath'] && file_exists(__DIR__.'/'.$item['ImagePath'])): ?>
            <img src="<?= $base ?>/<?= htmlspecialchars($item['ImagePath']) ?>" alt="<?= htmlspecialchars($item['Title']) ?>">
        <?php else: ?>
            <span style="font-size:7rem;opacity:0.2;">👗</span>
        <?php endif; ?>
    </div>
    <div class="product-detail-info">
        <div class="product-brand" style="font-size:0.78rem;margin-bottom:0.5rem;"><?= htmlspecialchars($item['Brand']) ?></div>
        <h1><?= htmlspecialchars($item['Title']) ?></h1>
        <div class="product-detail-price">R<?= number_format($item['Price'],2) ?></div>
        <p style="color:var(--muted);margin-bottom:1.5rem;line-height:1.7;"><?= nl2br(htmlspecialchars($item['Description'])) ?></p>
        <dl class="detail-meta">
            <dt>Size</dt><dd><?= htmlspecialchars($item['Size'] ?? 'N/A') ?></dd>
            <dt>Condition</dt><dd><?= ucwords(str_replace('_',' ',$item['Condition'])) ?></dd>
            <dt>Category</dt><dd><?= ucfirst($item['Category'] ?? 'N/A') ?></dd>
            <dt>Seller</dt><dd><?= htmlspecialchars($item['SellerName']) ?></dd>
        </dl>
        <div style="margin-top:2rem;display:flex;gap:1rem;flex-wrap:wrap;">
            <?php if ($user && $user['id'] != $item['SellerUID']): ?>
            <form method="POST"><button type="submit" name="add_to_cart" class="btn btn-primary btn-lg">Add to Cart</button></form>
            <a href="<?= $base ?>/messages.php?to=<?= $item['SellerUID'] ?>&clothes=<?= $id ?>" class="btn btn-outline btn-lg">Message Seller</a>
            <?php elseif (!$user): ?>
            <a href="<?= $base ?>/login.php?redirect=<?= urlencode($_SERVER['REQUEST_URI']) ?>" class="btn btn-primary btn-lg">Login to Buy</a>
            <?php else: ?><p class="text-muted italic">This is your listing.</p><?php endif; ?>
        </div>
    </div>
</div>
</section>
<?php require_once 'includes/footer.php'; ?>
