<?php
/*
 * Student Name: [DUMISA]
 * Student Number: [ST10445334
 * Declaration: This code is my own work where not referenced.
 *
 * register.php - User Registration
 * - Fields: name, email, username, password (8-char min), confirm password
 * - Password hashed with MD5 before storing
 * - New user status = 'pending' until admin verifies
 * - All registration data stored in MySQL tblUser
 */

$pageTitle = 'Register';
require_once 'includes/session.php';
require_once 'includes/DBConn.php';

$base = '/pastimes_poe';

if (isUserLoggedIn()) {
    header("Location: $base/dashboard.php");
    exit;
}

$errors = [];
$sticky = [];   // Retain form values on error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sticky['name']     = trim($_POST['name']     ?? '');
    $sticky['email']    = trim($_POST['email']    ?? '');
    $sticky['username'] = trim($_POST['username'] ?? '');
    $sticky['role']     = $_POST['role']          ?? 'buyer';
    $sticky['address']  = trim($_POST['address']  ?? '');
    $password           = $_POST['password']      ?? '';
    $confirm            = $_POST['confirm_password'] ?? '';

    // ── VALIDATION ────────────────────────────────────────────
    if (empty($sticky['name'])) {
        $errors['name'] = 'Full name is required.';
    } elseif (strlen($sticky['name']) < 2) {
        $errors['name'] = 'Name must be at least 2 characters.';
    }

    if (empty($sticky['email'])) {
        $errors['email'] = 'Email address is required.';
    } elseif (!filter_var($sticky['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    }

    if (empty($sticky['username'])) {
        $errors['username'] = 'Username is required.';
    } elseif (strlen($sticky['username']) < 3) {
        $errors['username'] = 'Username must be at least 3 characters.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $sticky['username'])) {
        $errors['username'] = 'Only letters, numbers and underscores allowed.';
    }

    // Password: 8 characters minimum (as per POE spec)
    if (empty($password)) {
        $errors['password'] = 'Password is required.';
    } elseif (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    }

    if ($password !== $confirm) {
        $errors['confirm'] = 'Passwords do not match.';
    }

    if (!in_array($sticky['role'], ['buyer','seller','both'])) {
        $errors['role'] = 'Please select a valid role.';
    }

    // ── UNIQUENESS CHECKS ────────────────────────────────────
    if (empty($errors['email'])) {
        $e = mysqli_real_escape_string($conn, $sticky['email']);
        $chk = mysqli_query($conn, "SELECT UserID FROM tblUser WHERE Email='$e' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            $errors['email'] = 'This email address is already registered.';
        }
    }

    if (empty($errors['username'])) {
        $u = mysqli_real_escape_string($conn, $sticky['username']);
        $chk = mysqli_query($conn, "SELECT UserID FROM tblUser WHERE Username='$u' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            $errors['username'] = 'This username is already taken.';
        }
    }

    // ── INSERT INTO DATABASE ─────────────────────────────────
    if (empty($errors)) {
        $name     = mysqli_real_escape_string($conn, $sticky['name']);
        $email    = mysqli_real_escape_string($conn, $sticky['email']);
        $username = mysqli_real_escape_string($conn, $sticky['username']);
        $role     = mysqli_real_escape_string($conn, $sticky['role']);
        $address  = mysqli_real_escape_string($conn, $sticky['address']);
        $passHash = md5($password);   // MD5 hash as per spec

        $sql = "INSERT INTO tblUser (Name, Email, Username, PasswordHash, Role, Status, SellerVerified, Address)
                VALUES ('$name', '$email', '$username', '$passHash', '$role', 'pending', 0, '$address')";

        if (mysqli_query($conn, $sql)) {
            flashMessage('success',
                'Registration successful! Your account is pending admin verification. You will be able to log in once verified.'
            );
            header("Location: $base/login.php");
            exit;
        } else {
            $errors['general'] = 'Registration failed. Please try again. Error: ' . mysqli_error($conn);
        }
    }
}

require_once 'includes/header.php';
?>

<div style="background:var(--cream);padding:2rem 1rem;">
<div class="form-card" style="max-width:560px;">

    <h2>Create Account</h2>
    <p class="form-subtitle">Join thousands of South Africans on Pastimes</p>

    <?php if (!empty($errors['general'])): ?>
    <div class="flash flash-danger" style="border-radius:8px;margin-bottom:1.5rem;">
        <span>&#10005; <?= htmlspecialchars($errors['general']) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" action="" novalidate>

        <!-- Full Name -->
        <div class="form-group">
            <label for="name">Full Name <span style="color:var(--danger)">*</span></label>
            <input type="text" id="name" name="name"
                   class="form-control <?= isset($errors['name']) ? 'error' : '' ?>"
                   value="<?= htmlspecialchars($sticky['name'] ?? '') ?>"
                   placeholder="e.g. Amelia Dlamini"
                   required minlength="2" autocomplete="name">
            <?php if (isset($errors['name'])): ?><div class="form-error">&#10005; <?= $errors['name'] ?></div><?php endif; ?>
        </div>

        <!-- Email -->
        <div class="form-group">
            <label for="email">Email Address <span style="color:var(--danger)">*</span></label>
            <input type="email" id="email" name="email"
                   class="form-control <?= isset($errors['email']) ? 'error' : '' ?>"
                   value="<?= htmlspecialchars($sticky['email'] ?? '') ?>"
                   placeholder="you@example.com"
                   required autocomplete="email">
            <?php if (isset($errors['email'])): ?><div class="form-error">&#10005; <?= $errors['email'] ?></div><?php endif; ?>
        </div>

        <!-- Username -->
        <div class="form-group">
            <label for="username">Username <span style="color:var(--danger)">*</span></label>
            <input type="text" id="username" name="username"
                   class="form-control <?= isset($errors['username']) ? 'error' : '' ?>"
                   value="<?= htmlspecialchars($sticky['username'] ?? '') ?>"
                   placeholder="your_username"
                   required minlength="3" pattern="[a-zA-Z0-9_]+" autocomplete="username">
            <div class="form-hint">Letters, numbers and underscores only. Min 3 characters.</div>
            <?php if (isset($errors['username'])): ?><div class="form-error">&#10005; <?= $errors['username'] ?></div><?php endif; ?>
        </div>

        <!-- Role -->
        <div class="form-group">
            <label for="role">I want to... <span style="color:var(--danger)">*</span></label>
            <select id="role" name="role" class="form-control" required>
                <option value="buyer"  <?= ($sticky['role'] ?? 'buyer') === 'buyer'  ? 'selected' : '' ?>>Buy clothes only</option>
                <option value="seller" <?= ($sticky['role'] ?? '')       === 'seller' ? 'selected' : '' ?>>Sell clothes only</option>
                <option value="both"   <?= ($sticky['role'] ?? '')       === 'both'   ? 'selected' : '' ?>>Buy and sell</option>
            </select>
            <?php if (isset($errors['role'])): ?><div class="form-error">&#10005; <?= $errors['role'] ?></div><?php endif; ?>
        </div>

        <!-- Delivery Address -->
        <div class="form-group">
            <label for="address">Delivery Address</label>
            <textarea id="address" name="address" class="form-control" rows="2"
                      placeholder="Residential or work address for courier delivery..."><?= htmlspecialchars($sticky['address'] ?? '') ?></textarea>
            <div class="form-hint">Optional. Required before placing orders.</div>
        </div>

        <!-- Password -->
        <div class="form-group">
            <label for="password">
                Password <span style="color:var(--danger)">*</span>
                <span id="pass-strength" style="font-weight:400;text-transform:none;letter-spacing:0;font-size:0.75rem;"></span>
            </label>
            <input type="password" id="password" name="password"
                   class="form-control <?= isset($errors['password']) ? 'error' : '' ?>"
                   placeholder="Minimum 8 characters"
                   required minlength="8" autocomplete="new-password">
            <div class="form-hint">Must be at least <strong>8 characters</strong>.</div>
            <?php if (isset($errors['password'])): ?><div class="form-error">&#10005; <?= $errors['password'] ?></div><?php endif; ?>
        </div>

        <!-- Confirm Password -->
        <div class="form-group">
            <label for="confirm_password">Confirm Password <span style="color:var(--danger)">*</span></label>
            <input type="password" id="confirm_password" name="confirm_password"
                   class="form-control <?= isset($errors['confirm']) ? 'error' : '' ?>"
                   placeholder="Re-enter your password"
                   required minlength="8" autocomplete="new-password">
            <?php if (isset($errors['confirm'])): ?><div class="form-error">&#10005; <?= $errors['confirm'] ?></div><?php endif; ?>
        </div>

        <!-- Notice -->
        <div class="info-box mb-2">
            &#9432; <strong>Account Verification:</strong> New accounts are <strong>pending</strong> until an administrator verifies them.
            Sellers require an additional seller verification step before listing items.
        </div>

        <button type="submit" class="btn btn-primary btn-full" style="border-radius:8px;">
            Create My Account
        </button>
    </form>

    <hr class="divider" style="margin:1.5rem 0;">
    <p class="text-center" style="font-size:0.88rem;color:var(--muted);">
        Already have an account?
        <a href="<?= $base ?>/login.php" style="color:var(--gold);font-weight:600;">Sign in here</a>
    </p>

</div>
</div>

<?php require_once 'includes/footer.php'; ?>
