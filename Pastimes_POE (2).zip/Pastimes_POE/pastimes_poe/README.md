# Pastimes — Second-Hand Clothing Store
## WEDE6021/w POE Assignment

---

## HOW TO RUN IN VISUAL STUDIO

### Step 1 — Install Required Software

| Software | Download |
|----------|----------|
| **Visual Studio 2022** | https://visualstudio.microsoft.com |
| **PHP Tools for Visual Studio** | https://www.devsense.com/en/features#vs |
| **XAMPP** (Apache + MySQL) | https://www.apachefriends.org |

### Step 2 — Start XAMPP
1. Open **XAMPP Control Panel**
2. Click **Start** next to **Apache**
3. Click **Start** next to **MySQL**
4. Both should show green status

### Step 3 — Place Project Files
Copy the `pastimes_poe` folder to:
- **Windows:** `C:\xampp\htdocs\pastimes_poe\`
- **Mac:** `/Applications/XAMPP/htdocs/pastimes_poe/`

### Step 4 — Open in Visual Studio
1. Open Visual Studio 2022
2. **File → Open → Project/Solution**
3. Navigate to `pastimes_poe\` and open **`Pastimes.sln`**
4. The project will load with all PHP files in Solution Explorer

### Step 5 — Set Up the Database
Open your browser and go to:
```
http://localhost/phpmyadmin
```
Then either:

**Option A — Import SQL file (recommended, gives 30 rows of test data):**
1. Click **New** → name database `ClothingStore` → **Create**
2. Click the `ClothingStore` database → **Import** tab
3. Choose `myClothingStore.sql` from the project folder
4. Click **Go**

**Option B — Auto-create via browser:**
```
http://localhost/pastimes_poe/loadClothingStore.php
http://localhost/pastimes_poe/createTable.php
```

### Step 6 — Configure Database Connection (if needed)
Open `includes/DBConn.php` and update if your MySQL settings differ:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');   // your MySQL username
define('DB_PASS', '');       // your MySQL password (blank by default in XAMPP)
define('DB_NAME', 'ClothingStore');
```

### Step 7 — Run the Project
**Option A — Press F5 in Visual Studio** (requires PHP Tools extension)

**Option B — Open in browser directly:**
```
http://localhost/pastimes_poe/
```

---

## SITE URLS

| Page | URL |
|------|-----|
| Homepage | `http://localhost/pastimes_poe/` |
| Register | `http://localhost/pastimes_poe/register.php` |
| Login | `http://localhost/pastimes_poe/login.php` |
| Shop | `http://localhost/pastimes_poe/shop.php` |
| Admin Login | `http://localhost/pastimes_poe/admin/login.php` |
| Setup DB | `http://localhost/pastimes_poe/loadClothingStore.php` |
| Reload Users | `http://localhost/pastimes_poe/createTable.php` |

---

## LOGIN CREDENTIALS

### Administrator
| Field | Value |
|-------|-------|
| Username | `superadmin` |
| Password | `admin1234` |

### Test Buyer (Verified)
| Field | Value |
|-------|-------|
| Username | `amelia_d` |
| Email | `amelia.dlamini@email.com` |
| Password | `Password1` |

### Test Seller (Verified + Seller Approved)
| Field | Value |
|-------|-------|
| Username | `sipho_n` |
| Email | `sipho.nkosi@gmail.com` |
| Password | `Password1` |

### Pending User (for admin verification demo)
| Field | Value |
|-------|-------|
| Username | `kagiso_m` |
| Email | `kagiso.m@gmail.com` |
| Password | `Password1` |

---

## DATABASE TABLES

| Table | Purpose |
|-------|---------|
| `tblUser` | All registered customers (buyers/sellers) |
| `tblAdmin` | Administrator accounts |
| `tblClothes` | Clothing listings (FK → tblUser) |
| `tblCart` | Shopping carts (FK → tblUser) |
| `tblCartItem` | Items in carts (FK → tblCart, tblClothes) |
| `tblAorder` | Purchase orders (FK → tblUser, tblClothes, tblAdmin) |
| `tblMessage` | Buyer-seller messages (FK → tblUser, tblClothes) |

---

## FILE STRUCTURE
```
pastimes_poe/
├── Pastimes.sln              Visual Studio solution
├── Pastimes.phpproj          Visual Studio PHP project
├── index.php                 Homepage
├── login.php                 User login (sticky form, MD5)
├── logout.php                Session logout
├── register.php              User registration
├── shop.php                  Browse clothing
├── product.php               Product detail + add to cart
├── sell.php                  Seller listing form (with image upload)
├── cart.php                  Cart + checkout + continue shopping
├── messages.php              Buyer-seller messaging
├── dashboard.php             User account dashboard
├── loadClothingStore.php     Creates all DB tables (drops first)
├── createTable.php           Drops/recreates tblUser + loads userData.txt
├── myClothingStore.sql       Full DDL + 30 seed records per table
├── userData.txt              User seed data (pipe-delimited)
├── css/
│   └── style.css             Full stylesheet
├── js/
│   └── main.js               Frontend JavaScript
├── images/                   Uploaded clothing images
├── includes/
│   ├── DBConn.php            Database connection (MySQLi)
│   ├── session.php           Session helpers + auth functions
│   ├── header.php            Site header & navigation
│   └── footer.php            Site footer
└── admin/
    ├── login.php             Admin login portal
    ├── logout.php            Admin logout
    ├── dashboard.php         Admin overview + stats
    ├── users.php             User management (Add/Update/Delete/Verify)
    ├── clothes.php           Listing management (Approve/Remove/Delete)
    ├── orders.php            Order management + delivery liaison
    ├── admin_header.php      Admin nav partial
    └── admin_footer.php      Admin footer partial
```

---

## POE CHECKLIST

### Part 2 Requirements
- [x] `DBConn.php` — MySQLi connection file
- [x] `createTable.php` — Checks/drops/recreates `tblUser`, loads `userData.txt`
- [x] `loadClothingStore.php` — Creates all tables (drops first for clean state)
- [x] `userData.txt` — 10 fictitious users with name, email, hashed password
- [x] `myClothingStore.sql` — DDL + 30 entries per base table
- [x] Login page — accepts username + email, MD5 hash, HTML5 validation, sticky form
- [x] Login success — displays "User [Name] is logged in" banner
- [x] Register — stores in MySQL, sets status to 'pending'
- [x] Admin portal — separate login button/page
- [x] Admin verify users — verify new registrations
- [x] Admin Add/Update/Delete customers
- [x] Buyer — view clothing images
- [x] Buyer — message sellers
- [x] Buyer — shopping cart (add/edit items)
- [x] Buyer — purchase clothing + enter delivery address
- [x] Seller — request to sell (description, image, brand)
- [x] Admin — approve/load clothing details, remove sold items
