<?php
/*
 * Student Name: [DUMISA]
 * Student Number: [ST10445334]
 * Declaration: This code is my own work where not referenced.
 *
 * createTable.php
 * - Includes DBConn.php for database connection
 * - Checks if tblUser exists; if so, drops it
 * - Recreates tblUser
 * - Loads data from userData.txt into tblUser
 * - Each execution resets and reloads the table
 */

require_once 'includes/DBConn.php';  // ← DBConn.php included as required

$log = [];

// ── STEP 1: CHECK IF tblUser EXISTS; DROP IF SO ──────────────
$check = mysqli_query($conn, "SHOW TABLES LIKE 'tblUser'");
if (mysqli_num_rows($check) > 0) {
    mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");
    if (mysqli_query($conn, "DROP TABLE IF EXISTS tblUser")) {
        $log[] = ['ok', '✓ Existing tblUser found and dropped.'];
    } else {
        $log[] = ['err', '✗ Failed to drop tblUser: ' . mysqli_error($conn)];
    }
    mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");
} else {
    $log[] = ['info', 'ℹ tblUser did not exist — creating fresh.'];
}

// ── STEP 2: (RE)CREATE tblUser ────────────────────────────────
$createSQL = "CREATE TABLE tblUser (
    UserID         INT          AUTO_INCREMENT PRIMARY KEY,
    Name           VARCHAR(100) NOT NULL,
    Email          VARCHAR(150) NOT NULL UNIQUE,
    Username       VARCHAR(50)  NOT NULL UNIQUE,
    PasswordHash   VARCHAR(255) NOT NULL,
    Role           ENUM('buyer','seller','both') DEFAULT 'buyer',
    Status         ENUM('pending','verified','suspended') DEFAULT 'pending',
    SellerVerified TINYINT(1)   DEFAULT 0,
    Address        TEXT,
    ProfileImage   VARCHAR(255),
    CreatedAt      DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (mysqli_query($conn, $createSQL)) {
    $log[] = ['ok', '✓ tblUser created successfully.'];
} else {
    $log[] = ['err', '✗ Failed to create tblUser: ' . mysqli_error($conn)];
}

// ── STEP 3: LOAD DATA FROM userData.txt ──────────────────────
$txtFile = __DIR__ . '/userData.txt';
if (!file_exists($txtFile)) {
    $log[] = ['err', '✗ userData.txt not found at: ' . $txtFile];
} else {
    $lines   = file($txtFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $loaded  = 0;
    $skipped = 0;
    $errors  = [];

    foreach ($lines as $lineNum => $line) {
        // Skip comment lines
        if (strpos(trim($line), '#') === 0) continue;

        // Expected: name|email|username|hashed_password|role|status|seller_verified
        $parts = explode('|', $line);
        if (count($parts) < 4) {
            $skipped++;
            $errors[] = "Line " . ($lineNum + 1) . " skipped (wrong format)";
            continue;
        }

        $name     = mysqli_real_escape_string($conn, trim($parts[0]));
        $email    = mysqli_real_escape_string($conn, trim($parts[1]));
        $username = mysqli_real_escape_string($conn, trim($parts[2]));
        $passHash = mysqli_real_escape_string($conn, trim($parts[3]));
        $role     = isset($parts[4]) ? mysqli_real_escape_string($conn, trim($parts[4])) : 'buyer';
        $status   = isset($parts[5]) ? mysqli_real_escape_string($conn, trim($parts[5])) : 'pending';
        $sv       = isset($parts[6]) ? (int)trim($parts[6]) : 0;

        $sql = "INSERT INTO tblUser (Name, Email, Username, PasswordHash, Role, Status, SellerVerified)
                VALUES ('$name', '$email', '$username', '$passHash', '$role', '$status', $sv)";

        if (mysqli_query($conn, $sql)) {
            $loaded++;
        } else {
            $skipped++;
            $errors[] = "Line " . ($lineNum + 1) . " failed: " . mysqli_error($conn);
        }
    }

    $log[] = ['ok', "✓ Loaded $loaded users from userData.txt ($skipped skipped)."];
    foreach ($errors as $e) {
        $log[] = ['warn', "⚠ $e"];
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create tblUser — Pastimes</title>
    <style>
        body { font-family: monospace; background: #0d1117; color: #c9d1d9; padding: 2rem; }
        h1 { color: #f0b429; font-family: Georgia, serif; margin-bottom: 1.5rem; }
        .log-item { padding: 4px 0; font-size: 0.9rem; }
        .ok   { color: #3fb950; }
        .err  { color: #f85149; }
        .info { color: #58a6ff; }
        .warn { color: #ffc107; }
        .done { margin-top: 2rem; padding: 1rem; background: #161b22; border-radius: 8px; border-left: 4px solid #3fb950; }
        .done a { color: #f0b429; }
        .done h3 { color: #3fb950; margin-bottom: 0.5rem; }
    </style>
</head>
<body>
<h1>👕 Create tblUser from userData.txt</h1>
<?php foreach ($log as [$type, $msg]): ?>
    <div class="log-item <?= $type ?>"><?= htmlspecialchars($msg) ?></div>
<?php endforeach; ?>
<div class="done">
    <h3>✅ Done!</h3>
    <p><a href="index.php">→ Go to Pastimes</a></p>
    <p><a href="admin/login.php">→ Admin Login</a></p>
    <p style="margin-top:0.5rem;color:#ccc;">Test login: username <code>amelia_d</code> | email <code>amelia.dlamini@email.com</code> | password <code>Password1</code></p>
</div>
</body>
</html>
